package com.powerstones;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;
import java.util.Map;
import java.util.UUID;

import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LightningEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.ProjectileEntity;
import net.minecraft.entity.projectile.WitherSkullEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.Registries;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/** Skill-skill rumit yang tidak muat sebagai lambda pendek. */
public final class Skills {

    private static final Map<UUID, Long> STEALTH = new HashMap<>();
    private static final Map<UUID, Long> WARDEN = new HashMap<>();
    private static final Map<UUID, UUID> HELD = new HashMap<>();
    private static final Map<UUID, Double> HELD_DIST = new HashMap<>();
    private static final Map<UUID, String> PROJECTILE = new HashMap<>();
    private static final Map<UUID, ItemStack[]> STASH = new HashMap<>();
    private static final EquipmentSlot[] ARMOR = {EquipmentSlot.HEAD, EquipmentSlot.CHEST,
            EquipmentSlot.LEGS, EquipmentSlot.FEET};

    private Skills() {}

    // ================================================================ COPPER SURGE

    private static void strike(ServerWorld w, double x, double y, double z, ServerPlayerEntity owner) {
        LightningEntity bolt = EntityType.LIGHTNING_BOLT.create(w, SpawnReason.TRIGGERED);
        if (bolt == null) {
            return;
        }
        bolt.refreshPositionAfterTeleport(x, y, z);
        bolt.setChanneler(owner);
        w.spawnEntity(bolt);
        w.spawnParticles(ParticleTypes.ELECTRIC_SPARK, x, y + 1.0, z, 24, 0.4, 1.0, 0.4, 0.25);
    }

    /** 3 jalur petir menyapu 10 block ke depan; petir di belakang lenyap saat gelombang maju. */
    public static void copperLines(ServerPlayerEntity p, ServerWorld w) {
        Vec3d look = p.getRotationVec(1.0F);
        Vec3d d = new Vec3d(look.x, 0, look.z).normalize();
        Vec3d side = new Vec3d(-d.z, 0, d.x);
        double y = p.getY();
        double px = p.getX();
        double pz = p.getZ();
        for (int step = 0; step < 10; step++) {
            double dist = 3 + step;
            Scheduler.later(1 + step * 2, () -> {
                for (int lane = -1; lane <= 1; lane++) {
                    strike(w, px + d.x * dist + side.x * lane * 3.0, y, pz + d.z * dist + side.z * lane * 3.0, p);
                }
            });
        }
        w.playSound(null, p.getBlockPos(), SoundEvents.ENTITY_LIGHTNING_BOLT_THUNDER, SoundCategory.PLAYERS, 2.0F, 1.0F);
    }

    /** Dua cincin petir bulat di sekeliling pemain. */
    public static void copperRing(ServerPlayerEntity p, ServerWorld w) {
        double y = p.getY();
        double px = p.getX();
        double pz = p.getZ();
        for (int i = 0; i < 12; i++) {
            double a = i * Math.PI * 2 / 12;
            Scheduler.later(1 + i, () -> strike(w, px + Math.cos(a) * 6, y, pz + Math.sin(a) * 6, p));
        }
        for (int i = 0; i < 18; i++) {
            double a = i * Math.PI * 2 / 18 + 0.2;
            Scheduler.later(16 + i, () -> strike(w, px + Math.cos(a) * 10, y, pz + Math.sin(a) * 10, p));
        }
        w.playSound(null, p.getBlockPos(), SoundEvents.ENTITY_LIGHTNING_BOLT_THUNDER, SoundCategory.PLAYERS, 2.0F, 0.8F);
    }

    /** Petir super: badai petir beruntun lalu ledakan yang menghancurkan tanah. */
    public static void copperMega(ServerPlayerEntity p, ServerWorld w) {
        Vec3d eye = Fx.eye(p);
        Vec3d dir = p.getRotationVec(1.0F);
        HitResult hit = p.raycast(40, 1.0F, false);
        Vec3d pos = hit.getType() == HitResult.Type.MISS ? eye.add(dir.multiply(40)) : hit.getPos();
        if (pos.distanceTo(eye) < 10) {
            pos = eye.add(dir.multiply(10));
        }
        Vec3d t = pos;
        for (int i = 0; i < 8; i++) {
            double a = i * Math.PI / 4;
            Scheduler.later(1 + i * 2, () -> strike(w, t.x + Math.cos(a) * 3, t.y, t.z + Math.sin(a) * 3, p));
        }
        Scheduler.later(20, () -> {
            strike(w, t.x, t.y, t.z, p);
            strike(w, t.x, t.y, t.z, p);
            w.createExplosion(null, t.x, t.y, t.z, 6.0F, World.ExplosionSourceType.TNT);
            w.spawnParticles(ParticleTypes.EXPLOSION_EMITTER, t.x, t.y + 1, t.z, 3, 1, 1, 1, 0);
            w.spawnParticles(ParticleTypes.ELECTRIC_SPARK, t.x, t.y + 1, t.z, 200, 4, 3, 4, 0.5);
        });
        w.playSound(null, p.getBlockPos(), SoundEvents.ENTITY_LIGHTNING_BOLT_THUNDER, SoundCategory.PLAYERS, 3.0F, 0.6F);
    }

    // ================================================================ SCULK SENSE

    private static void sonic(ServerPlayerEntity p, ServerWorld w, float damage, int range) {
        Vec3d start = Fx.eye(p);
        Vec3d dir = p.getRotationVec(1.0F);
        for (int i = 1; i <= range; i++) {
            Vec3d pt = start.add(dir.multiply(i));
            w.spawnParticles(ParticleTypes.SONIC_BOOM, pt.x, pt.y, pt.z, 1, 0, 0, 0, 0);
        }
        Box box = new Box(start, start.add(dir.multiply(range))).expand(1.5);
        for (LivingEntity e : w.getEntitiesByClass(LivingEntity.class, box,
                x -> x != p && x.isAlive() && !Allies.isAlly(x))) {
            e.damage(w, w.getDamageSources().sonicBoom(p), damage);
            e.addVelocity(dir.x * 1.5, 0.4, dir.z * 1.5);
        }
        w.playSound(null, p.getBlockPos(), SoundEvents.ENTITY_WARDEN_SONIC_BOOM, SoundCategory.PLAYERS, 3.0F, 1.0F);
    }

    /** 2 Sonic Boom beruntun, masing-masing 20 damage (10 hati). */
    /** Getaran tanah: makhluk di sekitar terguncang selama ~1 detik. */
    private static void tremor(ServerPlayerEntity p, ServerWorld w) {
        for (int t = 0; t < 16; t++) {
            int tick = t;
            Scheduler.later(1 + t, () -> {
                ThreadLocalRandom r = ThreadLocalRandom.current();
                for (LivingEntity e : Fx.around(p, 14, false)) {
                    e.addVelocity((r.nextDouble() - 0.5) * 0.25, 0.05, (r.nextDouble() - 0.5) * 0.25);
                }
                p.addVelocity((r.nextDouble() - 0.5) * 0.08, 0.0, (r.nextDouble() - 0.5) * 0.08);
                for (int k = 0; k < 32; k++) {
                    double a = k * Math.PI * 2 / 32;
                    double rr = 1.0 + tick * 0.9;
                    w.spawnParticles(ParticleTypes.ASH, p.getX() + Math.cos(a) * rr, p.getY() + 0.1,
                            p.getZ() + Math.sin(a) * rr, 1, 0, 0.15, 0, 0.02);
                }
            });
        }
    }

    public static void doubleSonic(ServerPlayerEntity p, ServerWorld w) {
        tremor(p, w);
        sonic(p, w, 20.0F, 24);
        Scheduler.later(12, () -> {
            if (p.isAlive()) {
                sonic(p, p.getEntityWorld(), 20.0F, 24);
            }
        });
    }

    public static void stealth(ServerPlayerEntity p, ServerWorld w) {
        STEALTH.put(p.getUuid(), w.getTime() + 300);
        Fx.give(p, StatusEffects.INVISIBILITY, 15, 0);
        w.spawnParticles(ParticleTypes.SCULK_SOUL, p.getX(), p.getY() + 1, p.getZ(), 60, 1, 1, 1, 0.05);
    }

    public static void wardenBlood(ServerPlayerEntity p, ServerWorld w) {
        WARDEN.put(p.getUuid(), w.getTime() + 600);
        Fx.give(p, StatusEffects.HEALTH_BOOST, 30, 49);
        Fx.give(p, StatusEffects.RESISTANCE, 30, 1);
        Fx.give(p, StatusEffects.REGENERATION, 30, 1);
        Scheduler.later(3, () -> p.setHealth(p.getMaxHealth()));
        w.spawnParticles(ParticleTypes.SCULK_SOUL, p.getX(), p.getY() + 1, p.getZ(), 120, 1.5, 1.5, 1.5, 0.1);
        w.playSound(null, p.getBlockPos(), SoundEvents.ENTITY_WARDEN_ROAR, SoundCategory.PLAYERS, 3.0F, 1.0F);
    }

    /** Dipanggil tiap 5 tick: mob di sekitar pemain yang bersembunyi / mode Warden kabur dan kehilangan target. */
    public static void stealthTick(MinecraftServer server) {
        if (STEALTH.isEmpty() && WARDEN.isEmpty()) {
            return;
        }
        for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
            ServerWorld w = p.getEntityWorld();
            long now = w.getTime();
            boolean warden = WARDEN.getOrDefault(p.getUuid(), 0L) > now;
            boolean hidden = STEALTH.getOrDefault(p.getUuid(), 0L) > now;
            if (!warden && !hidden) {
                continue;
            }
            double r = warden ? 24 : 16;
            for (MobEntity m : w.getEntitiesByClass(MobEntity.class, p.getBoundingBox().expand(r),
                    x -> x.isAlive() && !Allies.isAlly(x))) {
                if (m.getTarget() == p) {
                    m.setTarget(null);
                }
                Vec3d away = new Vec3d(m.getX() - p.getX(), 0, m.getZ() - p.getZ());
                if (away.lengthSquared() < 1.0E-4) {
                    continue;
                }
                Vec3d a = away.normalize().multiply(12);
                m.getNavigation().startMovingTo(m.getX() + a.x, m.getY(), m.getZ() + a.z, 1.3);
            }
        }
    }

    // ================================================================ GALAXY STONE

    public static void galaxyLaunch(ServerPlayerEntity p, ServerWorld w) {
        for (LivingEntity e : Fx.around(p, 12, false)) {
            e.addVelocity(0, 2.2, 0);
            w.spawnParticles(ParticleTypes.END_ROD, e.getX(), e.getY() + 1, e.getZ(), 30, 0.3, 1.0, 0.3, 0.05);
        }
        w.spawnParticles(ParticleTypes.END_ROD, p.getX(), p.getY() + 0.5, p.getZ(), 80, 5, 0.3, 5, 0.1);
    }

    public static void galaxyFreeze(ServerPlayerEntity p, ServerWorld w) {
        Vec3d look = p.getRotationVec(1.0F);
        Vec3d d = new Vec3d(look.x, 0, look.z).normalize();
        int i = 0;
        for (LivingEntity e : Fx.around(p, 14, false)) {
            double a = i * 0.9;
            double x = p.getX() + d.x * 4 + Math.cos(a) * 1.5;
            double z = p.getZ() + d.z * 4 + Math.sin(a) * 1.5;
            e.requestTeleport(x, p.getY(), z);
            e.setVelocity(Vec3d.ZERO);
            Fx.give(e, StatusEffects.SLOWNESS, 20, 6);
            Fx.give(e, StatusEffects.WEAKNESS, 20, 2);
            if (e instanceof MobEntity m) {
                m.setAiDisabled(true);
                Scheduler.later(400, () -> m.setAiDisabled(false));
            }
            w.spawnParticles(ParticleTypes.END_ROD, x, p.getY() + 1, z, 20, 0.3, 0.8, 0.3, 0.02);
            i++;
        }
    }

    public static void galaxyBlackHole(ServerPlayerEntity p, ServerWorld w) {
        Vec3d eye = Fx.eye(p);
        Vec3d dir = p.getRotationVec(1.0F);
        HitResult hit = p.raycast(25, 1.0F, false);
        Vec3d c = hit.getType() == HitResult.Type.MISS ? eye.add(dir.multiply(20)) : hit.getPos();
        Vec3d center = new Vec3d(c.x, c.y + 3, c.z);
        w.playSound(null, p.getBlockPos(), SoundEvents.ENTITY_WITHER_SPAWN, SoundCategory.PLAYERS, 2.0F, 0.5F);
        // fase 1: bintang runtuh, cincin partikel menyusut ke pusat
        for (int t = 0; t < 30; t++) {
            int tick = t;
            Scheduler.later(1 + t, () -> {
                double r = 9.0 - tick * 0.28;
                for (int k = 0; k < 28; k++) {
                    double a = k * Math.PI * 2 / 28 + tick * 0.3;
                    w.spawnParticles(ParticleTypes.END_ROD, center.x + Math.cos(a) * r, center.y + Math.sin(a * 3) * r * 0.25,
                            center.z + Math.sin(a) * r, 1, 0, 0, 0, 0.0);
                }
                w.spawnParticles(ParticleTypes.END_ROD, center.x, center.y, center.z, 40, 0.3, 0.3, 0.3, 0.6);
            });
        }
        // fase 2: lubang hitam aktif 10 detik
        for (int t = 0; t < 200; t++) {
            int tick = t;
            Scheduler.later(31 + t, () -> blackHoleTick(p, w, center, tick));
        }
        // fase 3: supernova
        Scheduler.later(235, () -> {
            w.spawnParticles(ParticleTypes.END_ROD, center.x, center.y, center.z, 40, 0.3, 0.3, 0.3, 0.6);
            w.spawnParticles(ParticleTypes.EXPLOSION_EMITTER, center.x, center.y, center.z, 3, 1.5, 1.5, 1.5, 0);
            w.spawnParticles(ParticleTypes.END_ROD, center.x, center.y, center.z, 400, 6, 6, 6, 0.9);
            w.playSound(null, BlockPos.ofFloored(center), SoundEvents.ENTITY_WITHER_DEATH, SoundCategory.PLAYERS, 3.0F, 0.6F);
            for (int i = 0; i < 12; i++) {
                double r = 1.0 + i * 1.3;
                Scheduler.later(1 + i * 2, () -> {
                    for (int k = 0; k < 56; k++) {
                        double a = k * Math.PI * 2 / 56;
                        w.spawnParticles(ParticleTypes.END_ROD, center.x + Math.cos(a) * r, center.y, center.z + Math.sin(a) * r, 1, 0, 0, 0, 0.0);
                        w.spawnParticles(ParticleTypes.PORTAL, center.x + Math.cos(a) * r, center.y, center.z + Math.sin(a) * r, 1, 0, 0.1, 0, 0.3);
                        w.spawnParticles(ParticleTypes.END_ROD, center.x + Math.cos(a) * r * 0.4, center.y + Math.sin(a) * r, center.z, 1, 0, 0, 0, 0.0);
                    }
                });
            }
        });
    }

    private static void blackHoleTick(ServerPlayerEntity owner, ServerWorld w, Vec3d center, int tick) {
        ThreadLocalRandom rnd = ThreadLocalRandom.current();
        // cakram akresi: 3 lengan berputar, makin dekat makin cepat dan makin terang
        for (int arm = 0; arm < 3; arm++) {
            for (int k = 1; k <= 9; k++) {
                double r = 1.5 + k * 1.0;
                double a = tick * (0.55 - k * 0.035) + arm * Math.PI * 2 / 3;
                double x = center.x + Math.cos(a) * r;
                double z = center.z + Math.sin(a) * r;
                double y = center.y + Math.sin(a) * r * 0.18;
                w.spawnParticles(k <= 3 ? ParticleTypes.END_ROD : k <= 6 ? ParticleTypes.PORTAL : ParticleTypes.SOUL_FIRE_FLAME,
                        x, y, z, 1, 0, 0, 0, 0.0);
            }
        }
        // semburan jet vertikal dari kutub
        if (tick % 2 == 0) {
            for (int k = 1; k <= 8; k++) {
                w.spawnParticles(ParticleTypes.END_ROD, center.x, center.y + k * 0.9, center.z, 1, 0.06, 0, 0.06, 0.0);
                w.spawnParticles(ParticleTypes.END_ROD, center.x, center.y - k * 0.9, center.z, 1, 0.06, 0, 0.06, 0.0);
            }
        }
        // cakrawala peristiwa gelap di pusat
        w.spawnParticles(ParticleTypes.SQUID_INK, center.x, center.y, center.z, 10, 0.5, 0.5, 0.5, 0.01);
        w.spawnParticles(ParticleTypes.LARGE_SMOKE, center.x, center.y, center.z, 6, 0.6, 0.6, 0.6, 0.02);
        // cincin lensa gravitasi yang melebar
        if (tick % 20 < 10) {
            double lr = 3 + (tick % 20) * 0.9;
            for (int k = 0; k < 40; k++) {
                double a = k * Math.PI * 2 / 40;
                w.spawnParticles(ParticleTypes.END_ROD, center.x + Math.cos(a) * lr, center.y, center.z + Math.sin(a) * lr, 1, 0, 0, 0, 0.0);
            }
        }
        // materi yang tersedot masuk (partikel bergerak ke pusat)
        for (int k = 0; k < 10; k++) {
            double ang = rnd.nextDouble() * Math.PI * 2;
            double rr = 8 + rnd.nextDouble() * 5;
            double px = center.x + Math.cos(ang) * rr;
            double py = center.y + (rnd.nextDouble() - 0.5) * 6;
            double pz = center.z + Math.sin(ang) * rr;
            Vec3d in = new Vec3d(center.x - px, center.y - py, center.z - pz).normalize();
            w.spawnParticles(k % 2 == 0 ? ParticleTypes.END_ROD : ParticleTypes.SOUL_FIRE_FLAME, px, py, pz, 0, in.x, in.y, in.z, 0.6);
        }
        if (tick % 5 == 0) {
            w.spawnParticles(ParticleTypes.ELECTRIC_SPARK, center.x, center.y, center.z, 12, 2.5, 2.5, 2.5, 0.4);
        }
        if (tick % 20 == 0) {
            w.playSound(null, BlockPos.ofFloored(center), SoundEvents.ENTITY_WARDEN_HEARTBEAT, SoundCategory.PLAYERS, 3.0F, 0.4F);
        }

        // tarik semua entitas (kecuali pemilik)
        Box box = new Box(center.x - 15, center.y - 15, center.z - 15, center.x + 15, center.y + 15, center.z + 15);
        for (Entity e : w.getOtherEntities(owner, box, x -> !Allies.isAlly(x))) {
            double dx = center.x - e.getX();
            double dy = center.y - e.getY();
            double dz = center.z - e.getZ();
            double d = Math.sqrt(dx * dx + dy * dy + dz * dz);
            if (d < 0.5 || d > 15) {
                continue;
            }
            double f = (0.25 + (15 - d) / 15.0 * 0.9) * 0.4;
            e.addVelocity(dx / d * f, dy / d * f, dz / d * f);
            if (d < 4 && tick % 5 == 0 && e instanceof LivingEntity le) {
                le.damage(w, w.getDamageSources().magic(), 4.0F);
            }
            if (d < 2 && !(e instanceof LivingEntity) && !(e instanceof PlayerEntity)) {
                e.discard();
            }
        }

        // lahap blok di sekitar pusat
        if (tick % 10 == 0) {
            for (int dx = -3; dx <= 3; dx++) {
                for (int dy = -3; dy <= 3; dy++) {
                    for (int dz = -3; dz <= 3; dz++) {
                        if (dx * dx + dy * dy + dz * dz > 9) {
                            continue;
                        }
                        BlockPos bp = BlockPos.ofFloored(center.x + dx, center.y + dy, center.z + dz);
                        BlockState st = w.getBlockState(bp);
                        if (!st.isAir() && st.getHardness(w, bp) >= 0) {
                            w.setBlockState(bp, Blocks.AIR.getDefaultState());
                        }
                    }
                }
            }
        }
    }

    // ================================================================ ENDER STONE

    public static void enderPrompt(ServerPlayerEntity p, ServerWorld w) {
        Inputs.ask(p, "Ender Stone: ketik koordinat tujuan di chat dengan format X Y Z (contoh: 100 70 -250). "
                + "Format X Z memakai ketinggianmu sekarang. Ketik 'batal' untuk membatalkan.", Skills::enderGo);
    }

    private static void enderGo(ServerPlayerEntity p, String text) {
        String t = text.trim().toLowerCase();
        if (t.equals("batal")) {
            p.sendMessage(Text.literal("Teleport dibatalkan."), true);
            return;
        }
        String[] parts = t.replace(",", " ").split("\\s+");
        double x;
        double y;
        double z;
        try {
            if (parts.length == 3) {
                x = Double.parseDouble(parts[0]);
                y = Double.parseDouble(parts[1]);
                z = Double.parseDouble(parts[2]);
            } else if (parts.length == 2) {
                x = Double.parseDouble(parts[0]);
                y = p.getY();
                z = Double.parseDouble(parts[1]);
            } else {
                p.sendMessage(Text.literal("Format salah. Contoh: 100 70 -250"), true);
                return;
            }
        } catch (NumberFormatException ex) {
            p.sendMessage(Text.literal("Koordinat harus berupa angka. Contoh: 100 70 -250"), true);
            return;
        }
        ServerWorld w = p.getEntityWorld();
        y = Math.max(w.getBottomY() + 1, Math.min(w.getBottomY() + w.getHeight() - 2, y));
        if (!w.getWorldBorder().contains(BlockPos.ofFloored(x, y, z))) {
            p.sendMessage(Text.literal("Koordinat di luar batas dunia."), true);
            return;
        }
        if (!Cooldowns.ready(p, "ender_shard-go", 8)) {
            return;
        }
        w.spawnParticles(ParticleTypes.PORTAL, p.getX(), p.getY() + 1, p.getZ(), 80, 0.5, 1, 0.5, 0.6);
        p.requestTeleport(x, y, z);
        w.spawnParticles(ParticleTypes.PORTAL, x, y + 1, z, 80, 0.5, 1, 0.5, 0.6);
        w.playSound(null, p.getBlockPos(), SoundEvents.ENTITY_ENDERMAN_TELEPORT, SoundCategory.PLAYERS, 1.0F, 1.0F);
        Fx.give(p, StatusEffects.SLOW_FALLING, 6, 0);
        p.sendMessage(Text.literal("Teleport ke " + (int) x + " " + (int) y + " " + (int) z), true);
    }

    // ================================================================ MAGNET STONE

    public static void magnetToggle(ServerPlayerEntity p, ServerWorld w) {
        UUID id = p.getUuid();
        if (HELD.containsKey(id)) {
            magnetRelease(p);
            p.sendMessage(Text.literal("Entity dilepas."), true);
            return;
        }
        LivingEntity t = Fx.target(p, 15);
        if (t == null) {
            p.sendMessage(Text.literal("Tidak ada entity di arah pandanganmu (maks 15 block)."), true);
            return;
        }
        HELD.put(id, t.getUuid());
        HELD_DIST.put(id, Math.max(3.0, Math.sqrt(t.squaredDistanceTo(p))));
        p.sendMessage(Text.literal("Entity digenggam. Klik kanan lagi untuk melepas."), true);
    }

    private static void magnetRelease(ServerPlayerEntity p) {
        UUID target = HELD.remove(p.getUuid());
        HELD_DIST.remove(p.getUuid());
        if (target != null && p.getEntityWorld().getEntity(target) instanceof LivingEntity le) {
            Fx.give(le, StatusEffects.SLOW_FALLING, 4, 0);
        }
    }

    public static void magnetThrow(ServerPlayerEntity p, ServerWorld w) {
        UUID target = HELD.get(p.getUuid());
        if (target == null) {
            p.sendMessage(Text.literal("Belum menggenggam entity."), true);
            return;
        }
        Entity e = w.getEntity(target);
        Vec3d dir = p.getRotationVec(1.0F);
        magnetRelease(p);
        if (e != null) {
            e.addVelocity(dir.x * 3.5, dir.y * 3.5 + 0.3, dir.z * 3.5);
        }
    }

    public static void magnetDistance(ServerPlayerEntity p, ServerWorld w) {
        UUID id = p.getUuid();
        if (!HELD.containsKey(id)) {
            p.sendMessage(Text.literal("Belum menggenggam entity."), true);
            return;
        }
        double d = HELD_DIST.getOrDefault(id, 6.0) + 4.0;
        if (d > 15.0) {
            d = 4.0;
        }
        HELD_DIST.put(id, d);
        p.sendMessage(Text.literal("Jarak genggaman: " + (int) d + " block"), true);
    }

    /** Dipanggil tiap tick: entity yang digenggam mengikuti arah pandangan pemain. */
    public static void magnetTick(MinecraftServer server) {
        if (HELD.isEmpty()) {
            return;
        }
        for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
            UUID target = HELD.get(p.getUuid());
            if (target == null) {
                continue;
            }
            Entity e = p.getEntityWorld().getEntity(target);
            if (e == null || !e.isAlive() || !PowerStones.holds(p, Stones.MAGNET_STONE)) {
                magnetRelease(p);
                continue;
            }
            double dist = HELD_DIST.getOrDefault(p.getUuid(), 6.0);
            Vec3d pos = Fx.eye(p).add(p.getRotationVec(1.0F).multiply(dist));
            e.requestTeleport(pos.x, pos.y - 0.5, pos.z);
            e.setVelocity(Vec3d.ZERO);
            p.getEntityWorld().spawnParticles(ParticleTypes.ELECTRIC_SPARK, pos.x, pos.y, pos.z, 3, 0.3, 0.3, 0.3, 0.02);
        }
    }

    // ================================================================ CONTROL STONE

    public static void chooseProjectile(ServerPlayerEntity p, ServerWorld w) {
        Inputs.ask(p, "Control Stone: ketik nama projectile di chat (contoh: arrow, spectral_arrow, fireball, "
                + "small_fireball, blue_wither_skull, wither_skull, dragon_fireball, snowball, egg, trident). "
                + "Ketik 'batal' untuk membatalkan.", (pl, text) -> {
            String name = text.trim().toLowerCase().replace(' ', '_');
            if (name.equals("batal")) {
                pl.sendMessage(Text.literal("Dibatalkan."), true);
                return;
            }
            String real = name.equals("blue_wither_skull") ? "wither_skull" : name;
            if (!Registries.ENTITY_TYPE.containsId(Identifier.of("minecraft", real))) {
                pl.sendMessage(Text.literal("Projectile '" + name + "' tidak ditemukan."), false);
                return;
            }
            PROJECTILE.put(pl.getUuid(), name);
            pl.sendMessage(Text.literal("Projectile dipilih: " + name), true);
        });
    }

    public static void fireProjectiles(ServerPlayerEntity p, ServerWorld w) {
        String name = PROJECTILE.getOrDefault(p.getUuid(), "arrow");
        boolean blue = name.equals("blue_wither_skull");
        String real = blue ? "wither_skull" : name;
        Identifier id = Identifier.of("minecraft", real);
        if (real.equals("fishing_bobber") || !Registries.ENTITY_TYPE.containsId(id)) {
            p.sendMessage(Text.literal("Projectile '" + name + "' tidak bisa ditembakkan."), true);
            return;
        }
        EntityType<?> type = Registries.ENTITY_TYPE.get(id);
        Vec3d dir = p.getRotationVec(1.0F);
        Vec3d eye = Fx.eye(p);
        Vec3d side = new Vec3d(-dir.z, 0, dir.x).normalize();
        for (int i = 0; i < 15; i++) {
            Entity e = type.create(w, SpawnReason.TRIGGERED);
            if (!(e instanceof ProjectileEntity pr)) {
                if (e != null) {
                    e.discard();
                }
                p.sendMessage(Text.literal("'" + name + "' bukan projectile."), true);
                return;
            }
            double off = ((i % 5) - 2) * 0.35;
            double up = ((i / 5) - 1) * 0.35;
            pr.setOwner(p);
            pr.setPosition(eye.x + dir.x * 1.5 + side.x * off, eye.y + dir.y * 1.5 + up - 0.2, eye.z + dir.z * 1.5 + side.z * off);
            pr.setVelocity(dir.x, dir.y, dir.z, 3.5F, 1.5F);
            if (blue && pr instanceof WitherSkullEntity skull) {
                skull.setCharged(true);
            }
            w.spawnEntity(pr);
        }
        w.playSound(null, p.getBlockPos(), SoundEvents.ENTITY_BLAZE_SHOOT, SoundCategory.PLAYERS, 2.0F, 1.4F);
    }

    // ================================================================ BLACKSTONE WARD

    /** Mendorong semua makhluk di depanmu jauh ke depan. */
    public static void blackstonePush(ServerPlayerEntity p, ServerWorld w) {
        Vec3d look = p.getRotationVec(1.0F);
        Vec3d eye = Fx.eye(p);
        for (LivingEntity e : Fx.around(p, 14, false)) {
            Vec3d to = new Vec3d(e.getX() - eye.x, e.getBodyY(0.5) - eye.y, e.getZ() - eye.z);
            if (to.length() < 0.1 || look.dotProduct(to.normalize()) < 0.45) {
                continue;
            }
            e.addVelocity(look.x * 3.0, 0.6, look.z * 3.0);
            e.damage(w, w.getDamageSources().playerAttack(p), 5.0F);
            w.spawnParticles(ParticleTypes.LARGE_SMOKE, e.getX(), e.getY() + 1, e.getZ(), 12, 0.3, 0.5, 0.3, 0.05);
        }
        for (int i = 1; i <= 14; i++) {
            double spread = i * 0.22;
            Vec3d pt = eye.add(look.multiply(i));
            w.spawnParticles(ParticleTypes.ASH, pt.x, pt.y - 0.3, pt.z, 16, spread, spread * 0.6, spread, 0.02);
            w.spawnParticles(ParticleTypes.LARGE_SMOKE, pt.x, pt.y - 0.3, pt.z, 3, spread * 0.5, spread * 0.3, spread * 0.5, 0.02);
        }
        w.playSound(null, p.getBlockPos(), SoundEvents.ENTITY_IRON_GOLEM_ATTACK, SoundCategory.PLAYERS, 2.0F, 0.6F);
    }

    /** Kubah Blackstone: dibangun dari bawah ke atas, bertahan 10 detik, lalu runtuh dari atas. */
    public static void blackstoneDome(ServerPlayerEntity p, ServerWorld w) {
        BlockPos c = p.getBlockPos();
        int radius = 5;
        for (LivingEntity e : Fx.around(p, radius - 0.2, true)) {
            Fx.push(e, p, -1.8, 0.5);
        }
        List<BlockPos> shell = new ArrayList<>();
        List<Integer> layer = new ArrayList<>();
        for (int dy = -1; dy <= radius; dy++) {
            for (int dx = -radius; dx <= radius; dx++) {
                for (int dz = -radius; dz <= radius; dz++) {
                    double d = Math.sqrt(dx * dx + dy * dy + dz * dz);
                    if (d > radius - 0.5 && d <= radius + 0.5) {
                        shell.add(c.add(dx, dy, dz));
                        layer.add(dy);
                    }
                }
            }
        }
        Set<BlockPos> placed = new HashSet<>();
        for (int i = 0; i < shell.size(); i++) {
            BlockPos bp = shell.get(i);
            int dy = layer.get(i);
            Scheduler.later(1 + (dy + 1) * 2, () -> {
                if (w.getBlockState(bp).isAir()) {
                    w.setBlockState(bp, Blocks.BLACKSTONE.getDefaultState());
                    placed.add(bp);
                    w.spawnParticles(ParticleTypes.ASH, bp.getX() + 0.5, bp.getY() + 0.5, bp.getZ() + 0.5, 3, 0.3, 0.3, 0.3, 0.02);
                }
            });
            Scheduler.later(200 + (radius - dy) * 2, () -> {
                if (placed.contains(bp) && w.getBlockState(bp).isOf(Blocks.BLACKSTONE)) {
                    w.setBlockState(bp, Blocks.AIR.getDefaultState());
                    w.spawnParticles(ParticleTypes.LARGE_SMOKE, bp.getX() + 0.5, bp.getY() + 0.5, bp.getZ() + 0.5, 4, 0.3, 0.3, 0.3, 0.03);
                }
            });
        }
        // kilau di permukaan kubah + cincin rune di tanah selama 10 detik
        for (int t = 0; t < 20; t++) {
            int tick = t;
            Scheduler.later(5 + t * 10, () -> {
                ThreadLocalRandom r = ThreadLocalRandom.current();
                for (int k = 0; k < 50; k++) {
                    double yaw = r.nextDouble() * Math.PI * 2;
                    double pitch = r.nextDouble() * Math.PI / 2;
                    double x = c.getX() + 0.5 + Math.cos(yaw) * Math.cos(pitch) * radius;
                    double y = c.getY() + Math.sin(pitch) * radius;
                    double z = c.getZ() + 0.5 + Math.sin(yaw) * Math.cos(pitch) * radius;
                    w.spawnParticles(k % 3 == 0 ? ParticleTypes.END_ROD : ParticleTypes.ASH, x, y, z, 1, 0, 0, 0, 0.01);
                }
                for (int k = 0; k < 36; k++) {
                    double a = k * Math.PI * 2 / 36 + tick * 0.2;
                    w.spawnParticles(ParticleTypes.END_ROD, c.getX() + 0.5 + Math.cos(a) * (radius - 1),
                            c.getY() + 0.1, c.getZ() + 0.5 + Math.sin(a) * (radius - 1), 1, 0, 0, 0, 0);
                }
            });
        }
        Fx.give(p, StatusEffects.REGENERATION, 10, 1);
        Fx.give(p, StatusEffects.RESISTANCE, 10, 1);
        w.playSound(null, c, SoundEvents.BLOCK_ANVIL_LAND, SoundCategory.PLAYERS, 2.0F, 0.5F);
    }

    public static void blackstoneGolems(ServerPlayerEntity p, ServerWorld w) {
        for (int i = 0; i < 2; i++) {
            Allies.spawn(w, p, EntityType.IRON_GOLEM, 45);
        }
        w.spawnParticles(ParticleTypes.LARGE_SMOKE, p.getX(), p.getY() + 1, p.getZ(), 60, 3, 1, 3, 0.05);
        w.playSound(null, p.getBlockPos(), SoundEvents.ENTITY_IRON_GOLEM_REPAIR, SoundCategory.PLAYERS, 2.0F, 0.7F);
    }

    // ================================================================ ECHO STONE

    /** Sembunyikan dari mob selama beberapa tick (mob kehilangan target dan kabur). */
    public static void hide(ServerPlayerEntity p, ServerWorld w, int ticks) {
        STEALTH.put(p.getUuid(), w.getTime() + ticks);
    }

    public static void echoTwins(ServerPlayerEntity p, ServerWorld w) {
        for (int i = 0; i < 2; i++) {
            Allies.spawnEcho(w, p, 30, 2.5);
        }
        w.spawnParticles(ParticleTypes.ENCHANT, p.getX(), p.getY() + 1, p.getZ(), 120, 2, 1, 2, 0.6);
        w.playSound(null, p.getBlockPos(), SoundEvents.BLOCK_AMETHYST_BLOCK_CHIME, SoundCategory.PLAYERS, 3.0F, 0.8F);
    }

    /** Banyak Echo muncul; kamu dan armormu menghilang selama 12 detik. */
    public static void echoLegion(ServerPlayerEntity p, ServerWorld w) {
        for (int i = 0; i < 12; i++) {
            Allies.spawnEcho(w, p, 12, 6.0);   // salin armor SEBELUM disembunyikan
        }
        hide(p, w, 240);
        Fx.give(p, StatusEffects.INVISIBILITY, 12, 0);
        hideArmor(p, 240);
        w.spawnParticles(ParticleTypes.ENCHANT, p.getX(), p.getY() + 1, p.getZ(), 200, 4, 1.5, 4, 0.8);
        w.playSound(null, p.getBlockPos(), SoundEvents.BLOCK_AMETHYST_BLOCK_RESONATE, SoundCategory.PLAYERS, 3.0F, 0.6F);
    }

    private static void hideArmor(ServerPlayerEntity p, int ticks) {
        if (STASH.containsKey(p.getUuid())) {
            return;
        }
        ItemStack[] saved = new ItemStack[4];
        for (int i = 0; i < 4; i++) {
            saved[i] = p.getEquippedStack(ARMOR[i]).copy();
            p.equipStack(ARMOR[i], ItemStack.EMPTY);
        }
        STASH.put(p.getUuid(), saved);
        UUID id = p.getUuid();
        MinecraftServer server = p.getEntityWorld().getServer();
        Scheduler.later(ticks, () -> {
            ServerPlayerEntity pl = server.getPlayerManager().getPlayer(id);
            if (pl != null) {
                restoreArmor(pl);
            }
        });
    }

    /** Kembalikan armor yang disembunyikan (juga dipanggil saat pemain keluar, mati, atau server berhenti). */
    public static void restoreArmor(ServerPlayerEntity p) {
        ItemStack[] saved = STASH.remove(p.getUuid());
        if (saved == null) {
            return;
        }
        for (int i = 0; i < 4; i++) {
            if (saved[i].isEmpty()) {
                continue;
            }
            if (p.getEquippedStack(ARMOR[i]).isEmpty()) {
                p.equipStack(ARMOR[i], saved[i]);
            } else {
                p.getInventory().offerOrDrop(saved[i]);
            }
        }
    }

    public static boolean hasStash(ServerPlayerEntity p) {
        return STASH.containsKey(p.getUuid());
    }

    // ================================================================ MAGMA STONE

    public static boolean holdsStaff(ServerPlayerEntity p) {
        return p.getMainHandStack().isOf(Stones.MAGMA_STAFF) || p.getOffHandStack().isOf(Stones.MAGMA_STAFF);
    }

    /** Small fireball buatan sendiri: terbang 2 blok per tick, damage 5 hati + terbakar. */
    public static void magmaFireball(ServerPlayerEntity p, ServerWorld w) {
        Vec3d dir = p.getRotationVec(1.0F);
        fireballStep(p, w, Fx.eye(p).add(dir), dir, 0);
        w.playSound(null, p.getBlockPos(), SoundEvents.ENTITY_BLAZE_SHOOT, SoundCategory.PLAYERS, 1.5F, 1.0F);
    }

    private static void fireballStep(ServerPlayerEntity p, ServerWorld w, Vec3d pos, Vec3d dir, int step) {
        if (step > 30) {
            return;
        }
        Vec3d next = pos.add(dir.multiply(1.6));
        w.spawnParticles(ParticleTypes.FLAME, next.x, next.y, next.z, 8, 0.12, 0.12, 0.12, 0.02);
        w.spawnParticles(ParticleTypes.LARGE_SMOKE, next.x, next.y, next.z, 2, 0.1, 0.1, 0.1, 0.01);
        List<LivingEntity> hit = w.getEntitiesByClass(LivingEntity.class, new Box(next, next).expand(1.0),
                e -> e != p && e.isAlive() && !Allies.isAlly(e));
        boolean solid = !w.getBlockState(BlockPos.ofFloored(next)).isAir();
        if (!hit.isEmpty() || solid) {
            if (!hit.isEmpty()) {
                LivingEntity e = hit.get(0);
                e.damage(w, w.getDamageSources().playerAttack(p), 10.0F);
                e.setOnFireFor(8);
            }
            w.spawnParticles(ParticleTypes.FLAME, next.x, next.y, next.z, 50, 0.5, 0.5, 0.5, 0.12);
            w.spawnParticles(ParticleTypes.LAVA, next.x, next.y, next.z, 15, 0.4, 0.4, 0.4, 0.1);
            return;
        }
        Scheduler.later(1, () -> fireballStep(p, w, next, dir, step + 1));
    }

    /** Pasif Magma Staff: makhluk dalam radius 7 block terbakar dan terluka. */
    public static void magmaAura(ServerPlayerEntity p, ServerWorld w) {
        for (LivingEntity e : Fx.around(p, 7, false)) {
            e.setOnFireFor(4);
            e.damage(w, w.getDamageSources().inFire(), 4.0F);
        }
        for (int k = 0; k < 40; k++) {
            double a = k * Math.PI * 2 / 40;
            w.spawnParticles(ParticleTypes.FLAME, p.getX() + Math.cos(a) * 7, p.getY() + 0.2, p.getZ() + Math.sin(a) * 7, 1, 0, 0.1, 0, 0.02);
        }
    }

    // ================================================================ CORROSIVE STONE

    /** Setiap pukulan mengurangi durability armor dan senjata musuh sebanyak 20. */
    public static void corrode(LivingEntity e) {
        EquipmentSlot[] slots = {EquipmentSlot.MAINHAND, EquipmentSlot.OFFHAND, EquipmentSlot.HEAD,
                EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
        for (EquipmentSlot slot : slots) {
            ItemStack stack = e.getEquippedStack(slot);
            if (!stack.isEmpty() && stack.isDamageable()) {
                int nd = stack.getDamage() + 20;
                if (nd >= stack.getMaxDamage()) {
                    e.equipStack(slot, ItemStack.EMPTY);
                } else {
                    stack.setDamage(nd);
                }
            }
        }
    }

    // ================================================================ CORROSIVE STONE (Karat Total)

    private static final Map<UUID, ItemStack> DISARMED = new HashMap<>();

    /** Senjata semua makhluk radius 12 hancur seketika selama 5 detik, lalu dikembalikan. */
    public static void disarm(ServerPlayerEntity p, ServerWorld w) {
        int count = 0;
        for (LivingEntity e : Fx.around(p, 12, false)) {
            ItemStack hand = e.getMainHandStack();
            if (hand.isEmpty() || DISARMED.containsKey(e.getUuid())) {
                continue;
            }
            DISARMED.put(e.getUuid(), hand.copy());
            e.equipStack(EquipmentSlot.MAINHAND, ItemStack.EMPTY);
            w.spawnParticles(ParticleTypes.CRIT, e.getX(), e.getY() + 1.2, e.getZ(), 40, 0.4, 0.4, 0.4, 0.4);
            w.spawnParticles(ParticleTypes.LARGE_SMOKE, e.getX(), e.getY() + 1.2, e.getZ(), 10, 0.3, 0.3, 0.3, 0.05);
            UUID id = e.getUuid();
            Scheduler.later(100, () -> returnWeapon(w, id));
            count++;
        }
        w.playSound(null, p.getBlockPos(), SoundEvents.BLOCK_ANVIL_BREAK, SoundCategory.PLAYERS, 2.0F, 0.7F);
        p.sendMessage(Text.literal("Senjata " + count + " musuh hancur selama 5 detik"), true);
    }

    private static void returnWeapon(ServerWorld w, UUID id) {
        ItemStack weapon = DISARMED.remove(id);
        if (weapon == null) {
            return;
        }
        Entity e = w.getEntity(id);
        if (e instanceof LivingEntity le && le.isAlive()) {
            if (le.getMainHandStack().isEmpty()) {
                le.equipStack(EquipmentSlot.MAINHAND, weapon);
            } else if (le instanceof ServerPlayerEntity sp) {
                sp.getInventory().offerOrDrop(weapon);
            }
            w.spawnParticles(ParticleTypes.ENCHANT, le.getX(), le.getY() + 1, le.getZ(), 30, 0.4, 0.6, 0.4, 0.5);
        }
    }

    /** Kembalikan senjata pemain yang sedang "hancur" (keluar, mati, atau server berhenti). */
    public static void restoreWeapon(ServerPlayerEntity p) {
        ItemStack weapon = DISARMED.remove(p.getUuid());
        if (weapon == null) {
            return;
        }
        if (p.getMainHandStack().isEmpty()) {
            p.equipStack(EquipmentSlot.MAINHAND, weapon);
        } else {
            p.getInventory().offerOrDrop(weapon);
        }
    }

    // ================================================================ QUARTZ RADIANCE

    private static final Map<UUID, Long> LASER_UNTIL = new HashMap<>();

    /** Sinar laser putih yang bisa ditahan 10 detik: 3 hati damage tiap detik; kamu bersinar (Glowing). */
    public static void laser(ServerPlayerEntity p, ServerWorld w) {
        long token = w.getTime() + 200;
        LASER_UNTIL.put(p.getUuid(), token);
        Fx.give(p, StatusEffects.GLOWING, 10, 0);
        for (int t = 0; t < 200; t++) {
            int tick = t;
            Scheduler.later(1 + t, () -> laserTick(p, token, tick));
        }
    }

    private static void laserTick(ServerPlayerEntity p, long token, int tick) {
        if (!p.isAlive() || LASER_UNTIL.getOrDefault(p.getUuid(), 0L) != token) {
            return;
        }
        if (!PowerStones.holds(p, Stones.QUARTZ_RADIANCE)) {
            LASER_UNTIL.remove(p.getUuid());
            p.sendMessage(Text.literal("Laser berhenti (batu dilepas)."), true);
            return;
        }
        ServerWorld w = p.getEntityWorld();
        Vec3d eye = Fx.eye(p);
        Vec3d dir = p.getRotationVec(1.0F);
        HitResult hit = p.raycast(30, 1.0F, false);
        double maxDist = hit.getType() == HitResult.Type.MISS ? 30.0 : hit.getPos().distanceTo(eye);
        Vec3d end = eye.add(dir.multiply(maxDist));
        for (double d = 1.0; d <= maxDist; d += 0.35) {
            Vec3d pt = eye.add(dir.multiply(d));
            w.spawnParticles(ParticleTypes.END_ROD, pt.x, pt.y - 0.2, pt.z, 1, 0.02, 0.02, 0.02, 0.0);
        }
        w.spawnParticles(ParticleTypes.ELECTRIC_SPARK, end.x, end.y, end.z, 6, 0.3, 0.3, 0.3, 0.1);
        if (tick % 10 == 0) {
            for (LivingEntity e : w.getEntitiesByClass(LivingEntity.class, new Box(eye, end).expand(1.2),
                    x -> x != p && x.isAlive() && !Allies.isAlly(x))) {
                Vec3d c = new Vec3d(e.getX(), e.getBodyY(0.5), e.getZ());
                double t = c.subtract(eye).dotProduct(dir);
                if (t >= 0 && t <= maxDist && eye.add(dir.multiply(t)).distanceTo(c) <= 1.3) {
                    e.damage(w, w.getDamageSources().playerAttack(p), 4.5F);
                    w.spawnParticles(ParticleTypes.END_ROD, e.getX(), e.getBodyY(0.5), e.getZ(), 25, 0.3, 0.4, 0.3, 0.15);
                }
            }
            w.spawnParticles(ParticleTypes.END_ROD, end.x, end.y, end.z, 30, 0.4, 0.4, 0.4, 0.2);
            if (tick % 20 == 0) {
                w.playSound(null, p.getBlockPos(), SoundEvents.ENTITY_WARDEN_SONIC_BOOM, SoundCategory.PLAYERS, 1.0F, 2.0F);
            }
        }
    }

    // ================================================================ BLOOD STONE

    private record Link(UUID target, long until) {}

    private static final Map<UUID, Link> BLOOD_LINK = new HashMap<>();

    /** Korbankan 4 hati untuk Strength III + Speed II. */
    public static void bloodSacrifice(ServerPlayerEntity p, ServerWorld w) {
        if (p.getHealth() <= 10.0F) {
            p.sendMessage(Text.literal("Darahmu terlalu sedikit untuk tumbal (butuh lebih dari 5 hati)."), true);
            return;
        }
        p.setHealth(p.getHealth() - 8.0F);
        Fx.give(p, StatusEffects.STRENGTH, 12, 2);
        Fx.give(p, StatusEffects.SPEED, 12, 1);
        w.spawnParticles(ParticleTypes.DAMAGE_INDICATOR, p.getX(), p.getY() + 1, p.getZ(), 40, 0.5, 0.8, 0.5, 0.2);
        w.spawnParticles(ParticleTypes.CRIMSON_SPORE, p.getX(), p.getY() + 1, p.getZ(), 80, 1.0, 1.0, 1.0, 0.1);
    }

    /** Tandai musuh: 50% damage yang kamu terima selama 10 detik pindah ke dia. */
    public static void bloodLink(ServerPlayerEntity p, ServerWorld w) {
        LivingEntity t = Fx.target(p, 20);
        if (t == null) {
            p.sendMessage(Text.literal("Tidak ada musuh yang dibidik (maks 20 block)."), true);
            return;
        }
        BLOOD_LINK.put(p.getUuid(), new Link(t.getUuid(), w.getTime() + 200));
        Fx.give(t, StatusEffects.GLOWING, 10, 0);
        Vec3d from = Fx.eye(p);
        Vec3d to = new Vec3d(t.getX(), t.getBodyY(0.5), t.getZ());
        for (int i = 0; i <= 20; i++) {
            Vec3d pt = from.add(to.subtract(from).multiply(i / 20.0));
            w.spawnParticles(ParticleTypes.CRIMSON_SPORE, pt.x, pt.y, pt.z, 3, 0.05, 0.05, 0.05, 0.0);
        }
        p.sendMessage(Text.literal("Rantai Darah terpasang (10 detik)"), true);
    }

    /** Dipanggil saat pemain terluka: 50% damage dipindahkan ke musuh yang ditandai. */
    public static void bloodLinkReflect(ServerPlayerEntity p, float amount) {
        Link link = BLOOD_LINK.get(p.getUuid());
        if (link == null) {
            return;
        }
        ServerWorld w = p.getEntityWorld();
        if (w.getTime() >= link.until()) {
            BLOOD_LINK.remove(p.getUuid());
            return;
        }
        if (w.getEntity(link.target()) instanceof LivingEntity t && t.isAlive()) {
            t.damage(w, w.getDamageSources().magic(), amount * 0.5F);
            Scheduler.later(1, () -> p.heal(amount * 0.5F));
            w.spawnParticles(ParticleTypes.DAMAGE_INDICATOR, t.getX(), t.getBodyY(0.5), t.getZ(), 10, 0.3, 0.3, 0.3, 0.1);
        }
    }

    /** 10 detik: tiap detik musuh radius 8 kehilangan 1 hati dan kamu sembuh. */
    public static void bloodFeast(ServerPlayerEntity p, ServerWorld w) {
        for (int sec = 1; sec <= 10; sec++) {
            Scheduler.later(sec * 20, () -> {
                if (!p.isAlive()) {
                    return;
                }
                ServerWorld pw = p.getEntityWorld();
                float healed = 0.0F;
                for (LivingEntity e : Fx.around(p, 8, false)) {
                    e.damage(pw, pw.getDamageSources().magic(), 2.0F);
                    healed += 2.0F;
                    pw.spawnParticles(ParticleTypes.DAMAGE_INDICATOR, e.getX(), e.getBodyY(0.5), e.getZ(), 6, 0.3, 0.4, 0.3, 0.1);
                }
                p.heal(Math.min(healed, 8.0F));
                for (int k = 0; k < 36; k++) {
                    double a = k * Math.PI * 2 / 36;
                    pw.spawnParticles(ParticleTypes.CRIMSON_SPORE, p.getX() + Math.cos(a) * 8, p.getY() + 0.3,
                            p.getZ() + Math.sin(a) * 8, 1, 0, 0.2, 0, 0.02);
                }
                pw.spawnParticles(ParticleTypes.HEART, p.getX(), p.getY() + 1.5, p.getZ(), 6, 0.5, 0.4, 0.5, 0.0);
            });
        }
        w.playSound(null, p.getBlockPos(), SoundEvents.ENTITY_WARDEN_HEARTBEAT, SoundCategory.PLAYERS, 3.0F, 0.5F);
    }

    // ================================================================ CONTROL STONE: KENDALI PIKIRAN

    private record Puppet(UUID owner, long until) {}

    private static final Map<UUID, Puppet> PUPPETS = new HashMap<>();

    /** Mob yang dibidik menjadi sekutu 12 detik; pemain atau makhluk lain digerakkan ke arah yang kamu tuju. */
    public static void controlMind(ServerPlayerEntity p, ServerWorld w) {
        LivingEntity t = Fx.target(p, 25);
        if (t == null) {
            p.sendMessage(Text.literal("Tidak ada target yang dibidik (maks 25 block)."), true);
            return;
        }
        if (t instanceof MobEntity m) {
            if (Allies.adopt(p, m, 12)) {
                p.sendMessage(Text.literal("Kamu mengendalikan makhluk itu selama 12 detik"), true);
            } else {
                p.sendMessage(Text.literal("Makhluk itu tidak bisa dikendalikan."), true);
                return;
            }
        } else {
            PUPPETS.put(t.getUuid(), new Puppet(p.getUuid(), w.getTime() + 240));
            p.sendMessage(Text.literal("Kamu menggerakkan target selama 12 detik (arahkan pandanganmu)"), true);
        }
        Fx.give(t, StatusEffects.GLOWING, 12, 0);
        w.spawnParticles(ParticleTypes.ENCHANT, t.getX(), t.getBodyY(0.5), t.getZ(), 80, 0.5, 0.8, 0.5, 0.5);
        Vec3d from = Fx.eye(p);
        Vec3d to = new Vec3d(t.getX(), t.getBodyY(0.5), t.getZ());
        for (int i = 0; i <= 24; i++) {
            Vec3d pt = from.add(to.subtract(from).multiply(i / 24.0));
            w.spawnParticles(ParticleTypes.ELECTRIC_SPARK, pt.x, pt.y, pt.z, 2, 0.05, 0.05, 0.05, 0.0);
        }
    }

    /** Dipanggil tiap tick: boneka mengikuti titik 8 block di depan pandangan pengendali. */
    public static void controlTick(MinecraftServer server) {
        if (PUPPETS.isEmpty()) {
            return;
        }
        for (Iterator<Map.Entry<UUID, Puppet>> it = PUPPETS.entrySet().iterator(); it.hasNext();) {
            Map.Entry<UUID, Puppet> en = it.next();
            Puppet pu = en.getValue();
            ServerPlayerEntity owner = server.getPlayerManager().getPlayer(pu.owner());
            Entity e = owner == null ? null : owner.getEntityWorld().getEntity(en.getKey());
            if (owner == null || e == null || !e.isAlive() || owner.getEntityWorld().getTime() >= pu.until()) {
                it.remove();
                continue;
            }
            Vec3d aim = Fx.eye(owner).add(owner.getRotationVec(1.0F).multiply(8));
            Vec3d to = aim.subtract(new Vec3d(e.getX(), e.getY(), e.getZ()));
            double len = to.length();
            e.setVelocity(Vec3d.ZERO);
            if (len > 0.5) {
                Vec3d v = to.normalize().multiply(Math.min(0.55, len * 0.3));
                e.addVelocity(v.x, v.y, v.z);
            }
            owner.getEntityWorld().spawnParticles(ParticleTypes.ELECTRIC_SPARK, e.getX(), e.getBodyY(0.5), e.getZ(), 3, 0.2, 0.3, 0.2, 0.02);
        }
    }
}
