package com.powerstones;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.GameMode;
import net.minecraft.world.Heightmap;

/** Time Stone, Glitch Stone, dan Cursed Stone. */
public final class Chrono {

    private record Freeze(UUID owner, long until, double x, double y, double z, boolean fromStop) {}

    private record Phase(GameMode previous, Vec3d origin) {}

    private static final Map<UUID, Freeze> FROZEN = new HashMap<>();
    private static final Map<UUID, Integer> HITS = new HashMap<>();
    private static final Map<UUID, Long> NEAR_DEATH_CD = new HashMap<>();
    private static final Map<UUID, Deque<double[]>> HISTORY = new HashMap<>();
    private static final Set<UUID> GLITCHING = new HashSet<>();
    private static final Map<UUID, Phase> PHASE = new HashMap<>();
    private static final Map<UUID, Long> LIFESTEAL_UNTIL = new HashMap<>();

    private Chrono() {}

    // ================================================================ TIME STONE

    public static boolean isFrozen(Entity e) {
        return FROZEN.containsKey(e.getUuid());
    }

    /** Pemilik Time Stop tidak bisa menyerang yang beku sampai 5 kali hampir mati. */
    public static boolean blocksOwnerAttack(Entity attacker, Entity victim) {
        if (!(attacker instanceof ServerPlayerEntity ap)) {
            return false;
        }
        Freeze f = FROZEN.get(victim.getUuid());
        return f != null && f.fromStop() && f.owner().equals(ap.getUuid())
                && ap.getAttachedOrElse(PowerStones.NEAR_DEATH, 0) < 5;
    }

    private static void freeze(Entity e, UUID owner, long until, boolean fromStop) {
        FROZEN.put(e.getUuid(), new Freeze(owner, until, e.getX(), e.getY(), e.getZ(), fromStop));
        e.setNoGravity(true);
        if (e instanceof MobEntity m) {
            m.setAiDisabled(true);
        }
    }

    private static void release(Entity e) {
        e.setNoGravity(false);
        if (e instanceof MobEntity m) {
            m.setAiDisabled(false);
        }
    }

    /** Pasif Time Stone: penyerang makin lambat lalu beku 3 detik; hampir mati = penyerang langsung beku. */
    public static void onVictimHit(ServerPlayerEntity victim, Entity attacker, float amount) {
        if (!(attacker instanceof LivingEntity la) || la == victim || Allies.isAlly(la)) {
            return;
        }
        long now = victim.getEntityWorld().getTime();
        int n = HITS.merge(la.getUuid(), 1, Integer::sum);
        Fx.give(la, StatusEffects.SLOWNESS, 5, Math.min(n - 1, 4));
        if (n >= 4) {
            HITS.remove(la.getUuid());
            freeze(la, victim.getUuid(), now + 60, false);
        }
        if (victim.getHealth() - amount <= 4.0F) {
            freeze(la, victim.getUuid(), now + 100, false);
            UUID id = victim.getUuid();
            if (now >= NEAR_DEATH_CD.getOrDefault(id, 0L)) {
                NEAR_DEATH_CD.put(id, now + 200);
                int count = victim.getAttachedOrElse(PowerStones.NEAR_DEATH, 0) + 1;
                victim.setAttached(PowerStones.NEAR_DEATH, count);
                victim.sendMessage(Text.literal("Hampir mati: " + Math.min(count, 5) + "/5"
                        + (count == 5 ? " - kamu kini bisa menyerang di dalam Time Stop!" : "")), true);
            }
        }
    }

    /** Time Stop: semua makhluk, projectile, dan pemain dalam 10 block berhenti 8 detik. */
    public static void timeStop(ServerPlayerEntity p, ServerWorld w) {
        long until = w.getTime() + 160;
        double cx = p.getX();
        double cy = p.getY();
        double cz = p.getZ();
        int n = 0;
        for (Entity e : w.getOtherEntities(p, p.getBoundingBox().expand(10),
                x -> !Allies.isAlly(x) && x.squaredDistanceTo(p) <= 100.0)) {
            freeze(e, p.getUuid(), until, true);
            n++;
        }
        w.playSound(null, p.getBlockPos(), SoundEvents.BLOCK_BEACON_DEACTIVATE, SoundCategory.PLAYERS, 3.0F, 0.5F);
        for (int t = 0; t < 80; t++) {
            int tick = t;
            Scheduler.later(1 + t * 2, () -> {
                ThreadLocalRandom r = ThreadLocalRandom.current();
                for (int k = 0; k < 30; k++) {
                    double th = r.nextDouble() * Math.PI * 2;
                    double ph = Math.acos(2 * r.nextDouble() - 1);
                    w.spawnParticles(k % 3 == 0 ? ParticleTypes.ENCHANT : ParticleTypes.END_ROD,
                            cx + 10 * Math.sin(ph) * Math.cos(th), cy + 10 * Math.cos(ph) * 0.8 + 1,
                            cz + 10 * Math.sin(ph) * Math.sin(th), 1, 0, 0, 0, 0.0);
                }
                double minute = tick * 0.6;
                double hour = tick * 0.05;
                for (int k = 1; k <= 8; k++) {
                    w.spawnParticles(ParticleTypes.END_ROD, cx + Math.cos(minute) * k, cy + 0.2, cz + Math.sin(minute) * k, 1, 0, 0, 0, 0.0);
                }
                for (int k = 1; k <= 5; k++) {
                    w.spawnParticles(ParticleTypes.ENCHANT, cx + Math.cos(hour) * k, cy + 0.3, cz + Math.sin(hour) * k, 1, 0, 0, 0, 0.0);
                }
                if (tick % 2 == 0) {
                    for (int k = 0; k < 40; k++) {
                        double a = k * Math.PI * 2 / 40;
                        w.spawnParticles(ParticleTypes.END_ROD, cx + Math.cos(a) * 10, cy + 0.1, cz + Math.sin(a) * 10, 1, 0, 0, 0, 0.0);
                    }
                }
            });
        }
        int near = p.getAttachedOrElse(PowerStones.NEAR_DEATH, 0);
        p.sendMessage(Text.literal("Time Stop! " + n + " target berhenti. "
                + (near >= 5 ? "Kamu bisa menyerang mereka." : "Menyerang mereka butuh 5x hampir mati (" + near + "/5).")), true);
    }

    /** Dipanggil tiap tick: pertahankan pembekuan dan fase tembus tembok. */
    public static void tick(MinecraftServer server) {
        if (!FROZEN.isEmpty()) {
            for (Iterator<Map.Entry<UUID, Freeze>> it = FROZEN.entrySet().iterator(); it.hasNext();) {
                Map.Entry<UUID, Freeze> en = it.next();
                Freeze f = en.getValue();
                Entity e = null;
                ServerWorld where = null;
                for (ServerWorld w : server.getWorlds()) {
                    e = w.getEntity(en.getKey());
                    if (e != null) {
                        where = w;
                        break;
                    }
                }
                if (e == null) {
                    it.remove();
                    continue;
                }
                if (where.getTime() >= f.until() || !e.isAlive()) {
                    release(e);
                    it.remove();
                    continue;
                }
                e.setVelocity(Vec3d.ZERO);
                if (e instanceof ServerPlayerEntity sp) {
                    sp.requestTeleport(f.x(), f.y(), f.z());
                }
                if (where.getTime() % 5 == 0) {
                    where.spawnParticles(ParticleTypes.END_ROD, e.getX(), e.getY() + e.getHeight() / 2, e.getZ(), 2, 0.2, 0.3, 0.2, 0.0);
                }
            }
        }
        for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
            UUID id = p.getUuid();
            boolean has = PowerStones.holds(p, Stones.GLITCH_STONE);
            boolean phasing = PHASE.containsKey(id);
            if (has && p.isSneaking() && !phasing && !p.isSpectator() && !FROZEN.containsKey(id)) {
                enterPhase(p);
            } else if (phasing && (!has || !p.isSneaking())) {
                exitPhase(p);
            }
        }
    }

    public static void record(ServerPlayerEntity p) {
        Deque<double[]> q = HISTORY.computeIfAbsent(p.getUuid(), k -> new ArrayDeque<>());
        q.addLast(new double[] {p.getX(), p.getY(), p.getZ(), p.getHealth()});
        while (q.size() > 9) {
            q.pollFirst();
        }
    }

    /** Putar Balik: kembali ke posisi dan darah 8 detik yang lalu. */
    public static void rewind(ServerPlayerEntity p, ServerWorld w) {
        Deque<double[]> q = HISTORY.get(p.getUuid());
        double[] o = q == null ? null : q.peekFirst();
        if (o == null || q.size() < 3) {
            p.sendMessage(Text.literal("Belum ada riwayat waktu. Tunggu beberapa detik."), true);
            return;
        }
        w.spawnParticles(ParticleTypes.REVERSE_PORTAL, p.getX(), p.getY() + 1, p.getZ(), 80, 0.5, 1, 0.5, 0.5);
        p.requestTeleport(o[0], o[1], o[2]);
        p.setHealth(Math.max(p.getHealth(), Math.min((float) o[3], p.getMaxHealth())));
        w.spawnParticles(ParticleTypes.END_ROD, o[0], o[1] + 1, o[2], 80, 0.5, 1, 0.5, 0.3);
        w.playSound(null, p.getBlockPos(), SoundEvents.BLOCK_BEACON_POWER_SELECT, SoundCategory.PLAYERS, 2.0F, 0.6F);
        q.clear();
    }

    // ================================================================ GLITCH STONE

    private static Vec3d randomSpot(ServerWorld w, Vec3d center, double radius) {
        ThreadLocalRandom r = ThreadLocalRandom.current();
        for (int i = 0; i < 6; i++) {
            double ang = r.nextDouble() * Math.PI * 2;
            double d = Math.min(8, radius) + r.nextDouble() * Math.max(0, radius - 8);
            double x = center.x + Math.cos(ang) * d;
            double z = center.z + Math.sin(ang) * d;
            int y = w.getTopY(Heightmap.Type.MOTION_BLOCKING, (int) Math.floor(x), (int) Math.floor(z));
            if (y > w.getBottomY() + w.getHeight() - 6) {
                continue;
            }
            if (!w.getWorldBorder().contains(BlockPos.ofFloored(x, y, z))) {
                continue;
            }
            return new Vec3d(x, y, z);
        }
        return center;
    }

    private static void glitchFx(ServerWorld w, double x, double y, double z) {
        w.spawnParticles(ParticleTypes.ELECTRIC_SPARK, x, y + 1, z, 60, 0.5, 1.0, 0.5, 0.4);
        w.spawnParticles(ParticleTypes.PORTAL, x, y + 1, z, 80, 0.5, 1.0, 0.5, 0.8);
    }

    /** Pasif: sesekali terlempar ke tempat acak 4,5 detik lalu kembali ke tempat asal. */
    public static void glitchTick(ServerPlayerEntity p) {
        UUID id = p.getUuid();
        if (GLITCHING.contains(id) || FROZEN.containsKey(id) || PHASE.containsKey(id)
                || ThreadLocalRandom.current().nextInt(45) != 0) {
            return;
        }
        ServerWorld w = p.getEntityWorld();
        Vec3d origin = new Vec3d(p.getX(), p.getY(), p.getZ());
        Vec3d dest = randomSpot(w, origin, 40);
        GLITCHING.add(id);
        glitchFx(w, origin.x, origin.y, origin.z);
        p.requestTeleport(dest.x, dest.y, dest.z);
        glitchFx(w, dest.x, dest.y, dest.z);
        p.sendMessage(Text.literal("Glitch! Kembali dalam 4,5 detik"), true);
        Scheduler.later(90, () -> {
            GLITCHING.remove(id);
            if (p.isAlive() && !p.isRemoved()) {
                glitchFx(p.getEntityWorld(), p.getX(), p.getY(), p.getZ());
                p.requestTeleport(origin.x, origin.y, origin.z);
                glitchFx(p.getEntityWorld(), origin.x, origin.y, origin.z);
            }
        });
    }

    private static boolean free(ServerWorld w, BlockPos bp) {
        return w.getBlockState(bp).getCollisionShape(w, bp).isEmpty();
    }

    private static void enterPhase(ServerPlayerEntity p) {
        GameMode prev = p.interactionManager.getGameMode();
        PHASE.put(p.getUuid(), new Phase(prev, new Vec3d(p.getX(), p.getY(), p.getZ())));
        p.changeGameMode(GameMode.SPECTATOR);
        p.sendMessage(Text.literal("Glitch: tembus tembok (tahan jongkok)"), true);
    }

    /** Kembali ke mode semula dan pastikan tidak tertinggal di dalam blok. */
    public static void exitPhase(ServerPlayerEntity p) {
        Phase ph = PHASE.remove(p.getUuid());
        if (ph == null) {
            return;
        }
        p.changeGameMode(ph.previous());
        ServerWorld w = p.getEntityWorld();
        BlockPos bp = p.getBlockPos();
        if (!free(w, bp) || !free(w, bp.up())) {
            Vec3d safe = null;
            for (int dy = 0; dy <= 24 && safe == null; dy++) {
                BlockPos c = bp.up(dy);
                if (free(w, c) && free(w, c.up())) {
                    safe = new Vec3d(c.getX() + 0.5, c.getY(), c.getZ() + 0.5);
                }
            }
            Vec3d to = safe != null ? safe : ph.origin();
            p.requestTeleport(to.x, to.y, to.z);
        }
    }

    // ---- skill Glitch Stone

    public static void glitchPick(ServerPlayerEntity p, ServerWorld w) {
        Inputs.ask(p, "Glitch Stone: ketik nama skill dari batu lain di chat (contoh: Lubang Hitam, Double Sonic Boom, "
                + "Tiga Jalur Petir). Ketik 'batal' untuk membatalkan.", Chrono::glitchRun);
    }

    private static void glitchRun(ServerPlayerEntity p, String text) {
        String q = text.trim().toLowerCase();
        if (q.equals("batal")) {
            p.sendMessage(Text.literal("Dibatalkan."), true);
            return;
        }
        StoneItem found = null;
        int idx = -1;
        boolean exact = false;
        for (StoneItem st : Stones.ITEMS.values()) {
            if (st == Stones.GLITCH_STONE) {
                continue;
            }
            for (StoneDef.Power pw : st.def.powers) {
                if (pw.use() == StoneDef.Use.PASSIVE) {
                    continue;
                }
                String n = pw.name().toLowerCase();
                int i = pw.use() == StoneDef.Use.RIGHT ? 0 : pw.use() == StoneDef.Use.SNEAK ? 1 : 2;
                if (n.equals(q)) {
                    found = st;
                    idx = i;
                    exact = true;
                    break;
                }
                if (found == null && q.length() >= 3 && n.contains(q)) {
                    found = st;
                    idx = i;
                }
            }
            if (exact) {
                break;
            }
        }
        if (found == null) {
            p.sendMessage(Text.literal("Skill '" + text.trim() + "' tidak ditemukan."), false);
            return;
        }
        if (!Cooldowns.ready(p, "glitch_stone-pick", 10)) {
            return;
        }
        found.trigger(p, p.getEntityWorld(), idx);
    }

    /** Entity/pemain yang dibidik teleport ke tempat acak 5 kali (tiap 2 detik), lalu kembali dalam 10 detik. */
    public static void glitchScramble(ServerPlayerEntity p, ServerWorld w) {
        LivingEntity t = Fx.target(p, 25);
        if (t == null) {
            p.sendMessage(Text.literal("Tidak ada target yang dibidik (maks 25 block)."), true);
            return;
        }
        Vec3d origin = new Vec3d(t.getX(), t.getY(), t.getZ());
        UUID id = t.getUuid();
        for (int i = 0; i < 5; i++) {
            Scheduler.later(1 + i * 40, () -> {
                Entity e = w.getEntity(id);
                if (e != null && e.isAlive()) {
                    glitchFx(w, e.getX(), e.getY(), e.getZ());
                    Vec3d d = randomSpot(w, origin, 25);
                    e.requestTeleport(d.x, d.y, d.z);
                    glitchFx(w, d.x, d.y, d.z);
                }
            });
        }
        Scheduler.later(200, () -> {
            Entity e = w.getEntity(id);
            if (e != null && e.isAlive()) {
                glitchFx(w, e.getX(), e.getY(), e.getZ());
                e.requestTeleport(origin.x, origin.y, origin.z);
                glitchFx(w, origin.x, origin.y, origin.z);
            }
        });
        p.sendMessage(Text.literal("Target diacak 5x, kembali dalam 10 detik"), true);
    }

    // ================================================================ CURSED STONE

    /** Pasif: pemain lain dalam 7 block terkena Blindness. */
    public static void cursedAura(ServerPlayerEntity p) {
        for (ServerPlayerEntity o : p.getEntityWorld().getPlayers()) {
            if (o != p && o.squaredDistanceTo(p) <= 49.0) {
                Fx.give(o, StatusEffects.BLINDNESS, 3, 0);
            }
        }
    }

    public static void cursedHit(ServerPlayerEntity attacker) {
        if (attacker.getEntityWorld().getTime() < LIFESTEAL_UNTIL.getOrDefault(attacker.getUuid(), 0L)) {
            attacker.heal(1.0F);
        }
    }

    /** Lemparan Sabit: sabit melesat 14 block lalu kembali, melukai semua yang dilewati (5 hati). */
    public static void scytheThrow(ServerPlayerEntity p, ServerWorld w) {
        if (p.getAttachedOrElse(PowerStones.CURSED_HEADS, 0) < 1) {
            p.sendMessage(Text.literal("Terkunci: serap 1 kepala (bunuh pemain dengan Cursed Scythe, lalu klik kanan kepalanya)."), true);
            return;
        }
        Vec3d dir = p.getRotationVec(1.0F);
        Vec3d[] pos = {Fx.eye(p).add(dir.multiply(1.0))};
        Set<UUID> hitOut = new HashSet<>();
        Set<UUID> hitBack = new HashSet<>();
        w.playSound(null, p.getBlockPos(), SoundEvents.ENTITY_ILLUSIONER_CAST_SPELL, SoundCategory.PLAYERS, 2.0F, 0.6F);
        for (int t = 0; t < 26; t++) {
            int tick = t;
            Scheduler.later(1 + t, () -> {
                if (!p.isAlive()) {
                    return;
                }
                boolean out = tick < 13;
                if (out) {
                    pos[0] = pos[0].add(dir.multiply(1.3));
                } else {
                    Vec3d toP = Fx.eye(p).subtract(pos[0]);
                    pos[0] = toP.length() < 1.6 ? Fx.eye(p) : pos[0].add(toP.normalize().multiply(1.6));
                }
                Vec3d c = pos[0];
                for (int k = 0; k < 10; k++) {
                    double a = tick * 0.8 + k * 0.2;
                    w.spawnParticles(ParticleTypes.CRIT, c.x + Math.cos(a) * 1.2, c.y, c.z + Math.sin(a) * 1.2, 1, 0, 0, 0, 0.0);
                }
                w.spawnParticles(ParticleTypes.SOUL, c.x, c.y, c.z, 4, 0.2, 0.2, 0.2, 0.02);
                Set<UUID> hit = out ? hitOut : hitBack;
                for (LivingEntity e : w.getEntitiesByClass(LivingEntity.class, new Box(c, c).expand(1.8),
                        x -> x != p && x.isAlive() && !Allies.isAlly(x))) {
                    if (hit.add(e.getUuid())) {
                        e.damage(w, w.getDamageSources().playerAttack(p), 10.0F);
                        w.spawnParticles(ParticleTypes.SOUL, e.getX(), e.getBodyY(0.5), e.getZ(), 20, 0.3, 0.4, 0.3, 0.1);
                    }
                }
            });
        }
    }

    /** Haus Darah: 25 detik, tiap pukulan menyembuhkan 0,5 hati. */
    public static void bloodThirst(ServerPlayerEntity p, ServerWorld w) {
        if (p.getAttachedOrElse(PowerStones.CURSED_HEADS, 0) < 2) {
            p.sendMessage(Text.literal("Terkunci: serap 2 kepala."), true);
            return;
        }
        LIFESTEAL_UNTIL.put(p.getUuid(), w.getTime() + 500);
        w.spawnParticles(ParticleTypes.SOUL, p.getX(), p.getY() + 1, p.getZ(), 100, 1.0, 1.0, 1.0, 0.1);
        p.sendMessage(Text.literal("Haus Darah aktif (25 detik)"), true);
    }
}
