package com.powerstones;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.world.World;

/** Kepala pemain yang dibunuh dengan Cursed Scythe. Klik kanan untuk menyerap dan membuka skill Cursed Stone. */
public class CursedHeadItem extends Item {

    public CursedHeadItem(Settings settings) {
        super(settings);
    }

    @Override
    public ActionResult use(World world, PlayerEntity user, Hand hand) {
        if (world instanceof ServerWorld sw && user instanceof ServerPlayerEntity sp) {
            int n = sp.getAttachedOrElse(PowerStones.CURSED_HEADS, 0) + 1;
            sp.setAttached(PowerStones.CURSED_HEADS, n);
            user.getStackInHand(hand).decrement(1);
            String unlocked = n == 1 ? "Lemparan Sabit terbuka!" : n == 2 ? "Haus Darah terbuka!" : "Semua skill sudah terbuka.";
            sp.sendMessage(Text.literal("Kepala diserap (" + n + "). " + unlocked), true);
            sw.spawnParticles(ParticleTypes.SOUL, sp.getX(), sp.getY() + 1, sp.getZ(), 60, 0.6, 1.0, 0.6, 0.1);
        }
        return ActionResult.SUCCESS;
    }
}
