package com.powerstones;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.ai.brain.MemoryModuleType;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.AbstractSkeletonEntity;
import net.minecraft.entity.mob.DrownedEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.mob.WardenEntity;
import net.minecraft.entity.mob.ZombieEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Unit;

/** Sistem sekutu (mob summon) milik pemain. */
public final class Allies {

    private static final class Ally {
        final UUID mob;
        final UUID owner;
        final long expire;
        Ally(UUID mob, UUID owner, long expire) {
            this.mob = mob;
            this.owner = owner;
            this.expire = expire;
        }
    }

    private static final List<Ally> ALLIES = new ArrayList<>();
    private static final Map<UUID, UUID> OWNER_OF = new HashMap<>();
    private static final Map<UUID, Deque<EntityType<?>>> KILLED = new HashMap<>();
    private static final Set<UUID> ECHOES = new HashSet<>();
    private static final Set<UUID> ADOPTED = new HashSet<>();
    private static final int MAX_PER_OWNER = 80;
    private static final EquipmentSlot[] ECHO_SLOTS = {EquipmentSlot.HEAD, EquipmentSlot.CHEST,
            EquipmentSlot.LEGS, EquipmentSlot.FEET};

    private Allies() {}

    public static boolean isAlly(Entity e) {
        return OWNER_OF.containsKey(e.getUuid());
    }

    public static UUID ownerOf(Entity e) {
        return OWNER_OF.get(e.getUuid());
    }

    private static int countOf(UUID owner) {
        int n = 0;
        for (Ally a : ALLIES) {
            if (a.owner.equals(owner)) {
                n++;
            }
        }
        return n;
    }

    /** Warden tidak boleh menggali kembali ke tanah: perbarui 'cooldown gali' miliknya terus-menerus. */
    private static void keepWardenUp(MobEntity m) {
        if (m instanceof WardenEntity) {
            m.getBrain().remember(MemoryModuleType.DIG_COOLDOWN, Unit.INSTANCE, 1200L);
        }
    }

    /** Munculkan satu sekutu di sekitar pemain. */
    public static boolean spawn(ServerWorld w, ServerPlayerEntity owner, EntityType<?> type, int seconds) {
        if (countOf(owner.getUuid()) >= MAX_PER_OWNER) {
            return false;
        }
        Entity e = type.create(w, SpawnReason.MOB_SUMMONED);
        if (!(e instanceof MobEntity m)) {
            if (e != null) {
                e.discard();
            }
            return false;
        }
        ThreadLocalRandom r = ThreadLocalRandom.current();
        double x = owner.getX() + (r.nextDouble() - 0.5) * 7;
        double z = owner.getZ() + (r.nextDouble() - 0.5) * 7;
        m.refreshPositionAndAngles(x, owner.getY(), z, owner.getYaw(), 0.0F);
        m.setPersistent();
        m.addStatusEffect(new StatusEffectInstance(StatusEffects.FIRE_RESISTANCE, seconds * 20 + 200, 0, false, false));
        if (m instanceof AbstractSkeletonEntity skeleton) {
            skeleton.equipStack(EquipmentSlot.MAINHAND, new ItemStack(Items.BOW));
            skeleton.updateAttackType();
        } else if (m instanceof DrownedEntity) {
            m.equipStack(EquipmentSlot.MAINHAND, new ItemStack(Items.TRIDENT));
        } else if (m instanceof ZombieEntity) {
            m.equipStack(EquipmentSlot.MAINHAND, new ItemStack(Items.IRON_SWORD));
        }
        keepWardenUp(m);
        w.spawnEntity(m);
        ALLIES.add(new Ally(m.getUuid(), owner.getUuid(), w.getTime() + seconds * 20L));
        OWNER_OF.put(m.getUuid(), owner.getUuid());
        return true;
    }

    /** Ambil alih mob lain sementara (Control Stone): ia berpihak padamu lalu dilepas, tidak dihapus. */
    public static boolean adopt(ServerPlayerEntity owner, MobEntity m, int seconds) {
        if (isAlly(m) || m.getType() == EntityType.WITHER || m.getType() == EntityType.ENDER_DRAGON) {
            return false;
        }
        ALLIES.add(new Ally(m.getUuid(), owner.getUuid(), owner.getEntityWorld().getTime() + seconds * 20L));
        OWNER_OF.put(m.getUuid(), owner.getUuid());
        ADOPTED.add(m.getUuid());
        m.setTarget(null);
        return true;
    }

    public static boolean isAdopted(Entity e) {
        return ADOPTED.contains(e.getUuid());
    }

    /** Bayangan (Echo): zombie sekutu yang memakai salinan armor dan senjata pemilik. */
    public static boolean spawnEcho(ServerWorld w, ServerPlayerEntity owner, int seconds, double radius) {
        if (countOf(owner.getUuid()) >= MAX_PER_OWNER) {
            return false;
        }
        Entity e = EntityType.ZOMBIE.create(w, SpawnReason.MOB_SUMMONED);
        if (!(e instanceof ZombieEntity z)) {
            if (e != null) {
                e.discard();
            }
            return false;
        }
        ThreadLocalRandom r = ThreadLocalRandom.current();
        double ang = r.nextDouble() * Math.PI * 2;
        double dist = 1.5 + r.nextDouble() * radius;
        z.refreshPositionAndAngles(owner.getX() + Math.cos(ang) * dist, owner.getY(),
                owner.getZ() + Math.sin(ang) * dist, owner.getYaw(), 0.0F);
        z.setPersistent();
        z.addStatusEffect(new StatusEffectInstance(StatusEffects.FIRE_RESISTANCE, seconds * 20 + 200, 0, false, false));
        z.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, seconds * 20 + 200, 1, false, false));
        for (EquipmentSlot slot : ECHO_SLOTS) {
            ItemStack copy = owner.getEquippedStack(slot).copy();
            if (!copy.isEmpty()) {
                z.equipStack(slot, copy);
            }
        }
        z.equipStack(EquipmentSlot.MAINHAND, bestWeapon(owner));
        z.setCustomName(Text.literal("Echo " + owner.getName().getString()));
        z.setCustomNameVisible(true);
        w.spawnEntity(z);
        ALLIES.add(new Ally(z.getUuid(), owner.getUuid(), w.getTime() + seconds * 20L));
        OWNER_OF.put(z.getUuid(), owner.getUuid());
        ECHOES.add(z.getUuid());
        return true;
    }

    /** Senjata terbaik di inventory pemain (pedang/kapak); bukan batu. Kalau tidak ada, pedang besi. */
    private static ItemStack bestWeapon(ServerPlayerEntity owner) {
        ItemStack best = ItemStack.EMPTY;
        int bestScore = -1;
        var inv = owner.getInventory();
        for (int i = 0; i < inv.size(); i++) {
            ItemStack s = inv.getStack(i);
            if (s.isEmpty() || s.getItem() instanceof StoneItem || s.getItem() instanceof StoneHolderItem) {
                continue;
            }
            boolean weapon = s.isIn(ItemTags.SWORDS) || s.isIn(ItemTags.AXES)
                    || s.isOf(Stones.TRUE_BLADE) || s.isOf(Stones.ICE_DAGGER);
            if (weapon && s.getMaxDamage() > bestScore) {
                bestScore = s.getMaxDamage();
                best = s;
            }
        }
        return best.isEmpty() ? new ItemStack(Items.IRON_SWORD) : best.copy();
    }

    /** Catat mob yang dibunuh pemain (maksimal 15 terakhir) untuk dibangkitkan Summoner Stone. */
    public static void recordKill(ServerPlayerEntity p, LivingEntity victim) {
        if (!(victim instanceof MobEntity) || isAlly(victim)
                || victim.getType() == EntityType.WITHER || victim.getType() == EntityType.ENDER_DRAGON) {
            return;
        }
        Deque<EntityType<?>> q = KILLED.computeIfAbsent(p.getUuid(), k -> new ArrayDeque<>());
        q.addLast(victim.getType());
        while (q.size() > 15) {
            q.pollFirst();
        }
    }

    public static void summonKilled(ServerPlayerEntity p, ServerWorld w) {
        Deque<EntityType<?>> q = KILLED.get(p.getUuid());
        if (q == null || q.isEmpty()) {
            p.sendMessage(Text.literal("Belum ada mob yang kamu bunuh untuk dibangkitkan."), true);
            return;
        }
        int n = 0;
        for (EntityType<?> t : q) {
            if (spawn(w, p, t, 60)) {
                n++;
            }
        }
        q.clear();
        p.sendMessage(Text.literal("Arwah korban bangkit: " + n + " mob"), true);
    }

    /** Dipanggil tiap 5 tick: atur target & ikuti pemain. */
    public static void tick(MinecraftServer server) {
        if (ALLIES.isEmpty()) {
            return;
        }
        for (Iterator<Ally> it = ALLIES.iterator(); it.hasNext();) {
            Ally a = it.next();
            ServerPlayerEntity owner = server.getPlayerManager().getPlayer(a.owner);
            Entity e = owner == null ? null : owner.getEntityWorld().getEntity(a.mob);
            MobEntity m = (e instanceof MobEntity mm) ? mm : null;
            if (owner == null || m == null || !m.isAlive() || owner.getEntityWorld().getTime() >= a.expire) {
                if (e != null && e.isAlive() && !ADOPTED.contains(a.mob)) {
                    e.discard();
                }
                if (e instanceof MobEntity released && ADOPTED.contains(a.mob)) {
                    released.setTarget(null);
                }
                ADOPTED.remove(a.mob);
                OWNER_OF.remove(a.mob);
                ECHOES.remove(a.mob);
                it.remove();
                continue;
            }
            keepWardenUp(m);
            if (m instanceof WardenEntity) {
                owner.removeStatusEffect(net.minecraft.entity.effect.StatusEffects.DARKNESS);
            }
            ServerWorld w = owner.getEntityWorld();
            LivingEntity best = null;
            double bestDist = 28.0 * 28.0;
            for (LivingEntity c : w.getEntitiesByClass(LivingEntity.class, m.getBoundingBox().expand(24),
                    x -> x != m && x.isAlive() && !isAlly(x) && !(x instanceof PlayerEntity)
                            && (x instanceof HostileEntity
                                    || (x instanceof MobEntity xm && xm.getTarget() == owner)))) {
                double d = m.squaredDistanceTo(c);
                if (d < bestDist) {
                    bestDist = d;
                    best = c;
                }
            }
            // semua sekutu menyerang yang sedang diserang pemiliknya, atau yang baru menyerang pemiliknya
            LivingEntity att = owner.getAttacking();
            if (att != null && att.isAlive() && att != owner && !isAlly(att)) {
                best = att;
            } else {
                LivingEntity foe = owner.getAttacker();
                if (foe != null && foe.isAlive() && foe != owner && !isAlly(foe)) {
                    best = foe;
                }
            }
            m.setTarget(best);
            if (best == null) {
                double d2 = m.squaredDistanceTo(owner);
                if (d2 > 1600.0) {
                    m.requestTeleport(owner.getX() + 1, owner.getY(), owner.getZ() + 1);
                } else if (d2 > 64.0) {
                    m.getNavigation().startMovingTo(owner, 1.25);
                }
            }
        }
    }
}
