package com.powerstones;

import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;

/** Enchanted Stone di tangan kiri + klik kiri dengan item di tangan kanan = 1 enchant acak (cooldown 30 detik). */
public final class Enchanter {

    private Enchanter() {}

    private static boolean stoneInOffhand(ServerPlayerEntity p) {
        ItemStack off = p.getOffHandStack();
        if (off.isOf(Stones.ENCHANTED_STONE)) {
            return true;
        }
        return off.getItem() instanceof StoneHolderItem && StoneHolderItem.selectedStone(off) == Stones.ENCHANTED_STONE;
    }

    public static void tryEnchant(ServerPlayerEntity p) {
        if (!stoneInOffhand(p)) {
            return;
        }
        ItemStack stack = p.getMainHandStack();
        if (stack.isEmpty()) {
            return;
        }
        if (!Cooldowns.ready(p, "enchanted_stone-use", 30)) {
            return;
        }
        ServerWorld w = p.getEntityWorld();
        Registry<Enchantment> reg = w.getRegistryManager().getOrThrow(RegistryKeys.ENCHANTMENT);
        for (int attempt = 0; attempt < 10; attempt++) {
            var opt = reg.getRandom(w.getRandom());
            if (opt.isEmpty()) {
                break;
            }
            RegistryEntry<Enchantment> entry = opt.get();
            int max = entry.value().getMaxLevel();
            int cur = EnchantmentHelper.getLevel(entry, stack);
            if (cur >= max) {
                continue;
            }
            int level = cur + 1 + w.getRandom().nextInt(max - cur);
            stack.addEnchantment(entry, level);
            p.sendMessage(Text.literal("Enchant didapat: ").append(entry.value().description())
                    .append(Text.literal(" " + level)), true);
            w.spawnParticles(ParticleTypes.ENCHANT, p.getX(), p.getY() + 1.5, p.getZ(), 120, 0.8, 0.8, 0.8, 1.0);
            w.spawnParticles(ParticleTypes.ENCHANTED_HIT, p.getX(), p.getY() + 1.2, p.getZ(), 40, 0.5, 0.5, 0.5, 0.3);
            w.playSound(null, p.getBlockPos(), SoundEvents.BLOCK_ENCHANTMENT_TABLE_USE, SoundCategory.PLAYERS, 2.0F, 1.2F);
            return;
        }
        p.sendMessage(Text.literal("Tidak ada enchant baru untuk item ini."), true);
    }
}
