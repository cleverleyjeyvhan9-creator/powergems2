package com.powerstones;

import java.util.HashMap;
import java.util.Map;

import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

/** Cooldown per pemain per skill (terus berjalan walau batu tidak dipegang). */
public final class Cooldowns {

    private static final Map<String, Long> READY = new HashMap<>();

    private Cooldowns() {}

    /** Seperti ready(), tapi tanpa pesan ke pemain. */
    public static boolean quiet(ServerPlayerEntity p, String key, int seconds) {
        long now = p.getEntityWorld().getTime();
        String k = p.getUuid() + "|" + key;
        if (now < READY.getOrDefault(k, 0L)) {
            return false;
        }
        READY.put(k, now + seconds * 20L);
        return true;
    }

    /** True kalau skill boleh dipakai (dan langsung memulai cooldown). */
    public static boolean ready(ServerPlayerEntity p, String key, int seconds) {
        if (seconds <= 0) {
            return true;
        }
        long now = p.getEntityWorld().getTime();
        String k = p.getUuid() + "|" + key;
        long readyAt = READY.getOrDefault(k, 0L);
        if (now < readyAt) {
            long left = (readyAt - now + 19) / 20;
            p.sendMessage(Text.literal("Cooldown: " + left + " detik"), true);
            return false;
        }
        READY.put(k, now + seconds * 20L);
        return true;
    }
}
