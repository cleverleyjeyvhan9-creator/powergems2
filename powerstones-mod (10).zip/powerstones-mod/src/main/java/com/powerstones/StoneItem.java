package com.powerstones;

import java.util.Set;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.world.World;

public class StoneItem extends Item {

    /** Stone yang skillnya tidak melukai siapa pun: diberi ledakan PvP kecil agar tetap bisa melukai pemain lawan. */
    private static final Set<String> UTILITY = Set.of("emerald_pulse", "netherite_heart", "obsidian_veil", "redstone_spark",
            "lapis_mind", "gold_stone", "echo_stone", "glowstone_beacon", "prismarine_tide", "ender_shard", "summoner_stone",
            "ice_stone", "corrosive_stone", "crying_obsidian_tear", "quartz_radiance", "magnet_stone", "time_stone",
            "glitch_stone", "diamond_core", "true_stone");

    public final StoneDef def;

    public StoneItem(Settings settings, StoneDef def) {
        super(settings);
        this.def = def;
    }

    /**
     * Klik kanan di main hand = skill 1, jongkok + klik kanan = skill 2,
     * klik kanan dengan batu di offhand = skill 3.
     */
    @Override
    public ActionResult use(World world, PlayerEntity user, Hand hand) {
        int idx = hand == Hand.OFF_HAND ? 2 : (user.isSneaking() ? 1 : 0);
        if (def.skills[idx] == null) {
            return super.use(world, user, hand);
        }
        if (world instanceof ServerWorld sw && user instanceof ServerPlayerEntity sp) {
            trigger(sp, sw, idx);
        }
        return ActionResult.SUCCESS;
    }

    /** Dipakai juga oleh Stone Holder. */
    public void trigger(ServerPlayerEntity p, ServerWorld w, int idx) {
        StoneDef.Skill skill = def.skills[idx];
        if (skill == null) {
            return;
        }
        if (!Cooldowns.ready(p, def.id + idx, def.cooldowns[idx])) {
            return;
        }
        skill.run(p, w);
        if (UTILITY.contains(def.id) && Cooldowns.quiet(p, "pvp-burst", 4)) {
            Fx.pvpBurst(p, w, 6.0, 4.0F);
        }
        Fx.skillFx(w, p, def.aura, def.fx, def.style);
        w.playSound(null, p.getBlockPos(), SoundEvents.ENTITY_EVOKER_CAST_SPELL, SoundCategory.PLAYERS, 1.0F, 1.2F);
    }
}
