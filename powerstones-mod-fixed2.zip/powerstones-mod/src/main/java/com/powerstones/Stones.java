package com.powerstones;

import static com.powerstones.Fx.around;
import static com.powerstones.Fx.blink;
import static com.powerstones.Fx.give;
import static com.powerstones.Fx.push;
import static com.powerstones.Fx.target;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_10191;
import net.minecraft.class_10192;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1299;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1322;
import net.minecraft.class_1588;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1814;
import net.minecraft.class_2378;
import net.minecraft.class_2398;
import net.minecraft.class_2960;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_4081;
import net.minecraft.class_5134;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.class_9274;
import net.minecraft.class_9285;
import net.minecraft.class_9334;
import net.minecraft.class_9886;
import com.powerstones.StoneDef.Use;

/** Daftar semua power stone beserta deskripsi dan kemampuannya. */
public final class Stones {

    public static final Map<String, StoneItem> ITEMS = new LinkedHashMap<>();
    /** Semua item untuk tab kreatif (batu + holder). */
    public static final List<class_1792> TAB = new ArrayList<>();
    public static StoneItem LAPIS_MIND;
    public static StoneItem TRUE_STONE;
    public static class_1792 TRUE_BLADE;
    public static StoneItem GALAXY_STONE;
    public static StoneItem MAGNET_STONE;
    public static StoneItem GOLD_STONE;
    public static StoneItem OBSIDIAN_VEIL;
    public static StoneItem MAGMA_STONE;
    public static StoneItem ICE_STONE;
    public static StoneItem BLOOD_STONE;
    public static StoneItem EMERALD_PULSE;
    public static StoneItem QUARTZ_RADIANCE;
    public static StoneItem CORROSIVE_STONE;
    public static class_1792 MAGMA_STAFF;
    public static class_1792 ICE_DAGGER;
    public static StoneItem SUMMONER_STONE;
    public static StoneHolderItem HOLDER;

    private Stones() {}

    public static void register() {
        // ---------------------------------------------------------------- 1
        add(new StoneDef("diamond_core").style(2).aura(class_2398.field_11208).fx(class_2398.field_11205).chestplate()
                .desc("Armor instan. Pakai di slot chestplate.")
                .info(Use.PASSIVE, "Armor Berlian",
                        "Armor +10 di slot chestplate"));

        EMERALD_PULSE = add(new StoneDef("emerald_pulse").style(1).aura(class_2398.field_11211).fx(class_2398.field_11220)
                .desc("Keberuntungan dan penyembuhan tim.")
                .info(Use.PASSIVE, "Hero Permanen", "Hero of the Village V terus menyala selama batu ada di inventory")
                .passive(class_1294.field_5926, 1)
                .passive(class_1294.field_5922, 0)
                .power(Use.RIGHT, "Pulse Kemakmuran", 30,
                        "Regen + Speed untuk tim, dapat XP", (p, w) -> {
                    give(p, class_1294.field_5924, 8, 1);
                    give(p, class_1294.field_5904, 8, 0);
                    for (class_1309 e : around(p, 10, false)) {
                        if (e instanceof class_1657) {
                            give(e, class_1294.field_5924, 8, 1);
                            give(e, class_1294.field_5904, 8, 0);
                        }
                    }
                    p.method_7255(30);
                }));

        add(new StoneDef("netherite_heart").style(5).aura(class_2398.field_11251).fx(class_2398.field_11240)
                .desc("Tubuh sekuat netherite.")
                .passive(class_1294.field_5918, 0).passive(class_1294.field_5907, 1)
                .passive(class_1294.field_5914, 1)
                .power(Use.RIGHT, "Hati Netherite", 45,
                        "Resistance IV + Regeneration III", (p, w) -> {
                    give(p, class_1294.field_5907, 6, 3);
                    give(p, class_1294.field_5924, 6, 2);
                    give(p, class_1294.field_5918, 20, 0);
                }));

        OBSIDIAN_VEIL = add(new StoneDef("obsidian_veil").style(4).aura(class_2398.field_23190).fx(class_2398.field_11214)
                .desc("Tabir obsidian. Darahmu berubah acak.")
                .info(Use.PASSIVE, "Darah Acak", "Tiap dipegang: 20, 15, atau 13 hati, kadang hanya 5 hati")
                .info(Use.PASSIVE, "Darah Terkikis", "Kehilangan 0,5 hati tiap detik (berhenti di 2 hati)")
                .power(Use.RIGHT, "Perisai Obsidian", 120,
                        "Resistance IV selama 20 detik", (p, w) -> {
                    give(p, class_1294.field_5907, 20, 3);
                    w.method_65096(class_2398.field_23190, p.method_23317(), p.method_23318() + 1, p.method_23321(), 100, 0.8, 1, 0.8, 0.3);
                }));

        add(new StoneDef("redstone_spark").style(3).aura(class_2398.field_11205).fx(class_2398.field_29644)
                .desc("Kecepatan dan energi.")
                .passive(class_1294.field_5904, 3)
                .info(Use.PASSIVE, "Speed IV", "Hanya untuk pemegangnya")
                .power(Use.RIGHT, "Lonjakan Energi", 30,
                        "Haste III + lompat tinggi", (p, w) -> {
                    give(p, class_1294.field_5917, 10, 2);
                    give(p, class_1294.field_5913, 10, 1);
                }));

        LAPIS_MIND = add(new StoneDef("lapis_mind").style(2).aura(class_2398.field_11215).fx(class_2398.field_11207)
                .desc("Drop berlipat dan sihir.")
                .passive(class_1294.field_5926, 0).passive(class_1294.field_5917, 0)
                .passive(class_1294.field_5925, 0)
                .info(Use.PASSIVE, "Fortune Surge",
                        "Tiap 4 menit: drop x2 selama 15 detik")
                .power(Use.RIGHT, "Ledakan Pikiran", 60,
                        "Dapat XP + Haste III", (p, w) -> {
                    p.method_7255(60);
                    give(p, class_1294.field_5924, 10, 0);
                    give(p, class_1294.field_5917, 10, 2);
                }));

        GOLD_STONE = add(new StoneDef("gold_stone").style(1).aura(class_2398.field_11220).fx(class_2398.field_11207)
                .desc("Kecepatan ekstrem. Piglin tidak menyerangmu.")
                .passive(class_1294.field_5904, 1).passive(class_1294.field_5913, 0)
                .passive(class_1294.field_5917, 0)
                .info(Use.PASSIVE, "Teman Piglin", "Piglin tidak akan menyerangmu")
                .power(Use.RIGHT, "Gold Rush", 30,
                        "Speed IV + lompat tinggi + Haste III", (p, w) -> {
                    give(p, class_1294.field_5904, 8, 3);
                    give(p, class_1294.field_5913, 8, 2);
                    give(p, class_1294.field_5917, 8, 2);
                }));

        add(new StoneDef("echo_stone").style(4).aura(class_2398.field_28479).fx(class_2398.field_11215)
                .desc("Memunculkan bayangan dirimu.")
                .passive(class_1294.field_5925, 0).passive(class_1294.field_5906, 0)
                .power(Use.RIGHT, "Dua Echo", 30,
                        "2 bayangan dirimu, menyerang saat kamu menyerang", Skills::echoTwins)
                .power(Use.SNEAK, "Pasukan Echo", 60,
                        "Banyak echo muncul, kamu dan armormu tak terlihat 12 detik", Skills::echoLegion)
                .power(Use.OFFHAND, "Gema Kristal", 15,
                        "Musuh sekitar pusing dan terdorong", (p, w) -> {
                    for (class_1309 e : around(p, 8, false)) {
                        give(e, class_1294.field_5916, 8, 0);
                        give(e, class_1294.field_5912, 8, 0);
                        push(e, p, -1.2, 0.3);
                    }
                    give(p, class_1294.field_5907, 5, 1);
                    w.method_8396(null, p.method_24515(), class_3417.field_26980,
                            class_3419.field_15248, 3.0F, 0.6F);
                }));

        add(new StoneDef("glowstone_beacon").style(3).aura(class_2398.field_11207).fx(class_2398.field_11220)
                .desc("Cahaya penyembuh.")
                .passive(class_1294.field_5925, 0).passive(class_1294.field_5924, 0)
                .power(Use.RIGHT, "Mercusuar", 20,
                        "Sembuhkan tim, butakan musuh", (p, w) -> {
                    for (class_1309 e : around(p, 10, false)) {
                        if (e instanceof class_1657) {
                            e.method_6025(6.0F);
                            give(e, class_1294.field_5898, 10, 1);
                        } else if (e instanceof class_1588) {
                            give(e, class_1294.field_5919, 5, 0);
                            give(e, class_1294.field_5912, 10, 0);
                        }
                    }
                    p.method_6025(6.0F);
                    give(p, class_1294.field_5898, 10, 1);
                }));

        add(new StoneDef("prismarine_tide").style(1).aura(class_2398.field_11229).fx(class_2398.field_11202)
                .desc("Pasukan laut membantumu.")
                .passive(class_1294.field_5900, 0).passive(class_1294.field_5927, 0)
                .passive(class_1294.field_5923, 0).passive(class_1294.field_5925, 0)
                .power(Use.RIGHT, "Panggil Pasukan Laut", 60,
                        "Panggil 6 Drowned + 3 Guardian", (p, w) -> {
                    for (int i = 0; i < 6; i++) {
                        Allies.spawn(w, p, class_1299.field_6123, 45);
                    }
                    for (int i = 0; i < 3; i++) {
                        Allies.spawn(w, p, class_1299.field_6118, 45);
                    }
                    w.method_65096(class_2398.field_11229, p.method_23317(), p.method_23318() + 1, p.method_23321(), 100, 3, 1, 3, 0.5);
                })
                .power(Use.SNEAK, "Gelombang Pasang", 30,
                        "Dorong musuh + buff Speed", (p, w) -> {
                    for (class_1309 e : around(p, 8, true)) {
                        give(e, class_1294.field_5909, 6, 1);
                        push(e, p, -1.4, 0.2);
                    }
                    give(p, class_1294.field_5904, 8, 1);
                    give(p, class_1294.field_5924, 8, 0);
                }));

        add(new StoneDef("ender_shard").style(4).aura(class_2398.field_11214).fx(class_2398.field_23190)
                .desc("Teleport ke koordinat mana pun.")
                .passive(class_1294.field_5906, 0).passive(class_1294.field_5913, 0)
                .power(Use.RIGHT, "Teleport Koordinat", 0,
                        "Ketik X Y Z di chat untuk teleport",
                        Skills::enderPrompt));

        // ---------------------------------------------------------------- Summoner Stone
        SUMMONER_STONE = add(new StoneDef("summoner_stone").style(2).aura(class_2398.field_23114).fx(class_2398.field_38002)
                .desc("Panggil pasukan undead.")
                .passive(class_1294.field_5925, 0)
                .power(Use.RIGHT, "Belenggu Arwah", 20,
                        "Perlambat musuh radius 12", (p, w) -> {
                    for (class_1309 e : around(p, 12, true)) {
                        give(e, class_1294.field_5909, 10, 2);
                        give(e, class_1294.field_5911, 10, 0);
                    }
                    w.method_65096(class_2398.field_23114, p.method_23317(), p.method_23318() + 1, p.method_23321(), 80, 4, 1, 4, 0.05);
                })
                .power(Use.SNEAK, "Pasukan Undead", 60,
                        "Panggil 10 Zombie + 10 Skeleton", (p, w) -> {
                    for (int i = 0; i < 10; i++) {
                        Allies.spawn(w, p, class_1299.field_6051, 60);
                        Allies.spawn(w, p, class_1299.field_6137, 60);
                    }
                    w.method_65096(class_2398.field_23114, p.method_23317(), p.method_23318() + 1, p.method_23321(), 150, 4, 1, 4, 0.1);
                })
                .power(Use.OFFHAND, "Arwah Korban", 45,
                        "Bangkitkan mob yang kamu bunuh (maks 15)",
                        Allies::summonKilled));

        MAGMA_STONE = add(new StoneDef("magma_stone").style(5).aura(class_2398.field_11240).fx(class_2398.field_11239)
                .desc("Api lava dan Magma Staff.")
                .passive(class_1294.field_5918, 0).passive(class_1294.field_5910, 0)
                .info(Use.PASSIVE, "Magma Staff", "Muncul otomatis di inventory (tak bisa dibuang). Klik kanan: fireball 5 hati")
                .info(Use.PASSIVE, "Aura Api", "Memegang staff: musuh radius 7 terbakar dan terluka")
                .info(Use.PASSIVE, "Api Menyala", "Setiap pukulan dan panahmu membakar musuh")
                .power(Use.RIGHT, "Amarah Magma", 15,
                        "Bakar sekitar + Strength II", (p, w) -> {
                    for (class_1309 e : around(p, 6, false)) {
                        e.method_5639(8);
                        e.method_64397(w, w.method_48963().method_48794(), 6.0F);
                    }
                    give(p, class_1294.field_5910, 6, 1);
                    give(p, class_1294.field_5904, 6, 0);
                    w.method_65096(class_2398.field_11239, p.method_23317(), p.method_23318() + 1, p.method_23321(), 40, 2, 0.5, 2, 0.1);
                    w.method_8396(null, p.method_24515(), class_3417.field_14970, class_3419.field_15248, 1.5F, 0.8F);
                }));

        ICE_STONE = add(new StoneDef("ice_stone").style(2).aura(class_2398.field_28013).fx(class_2398.field_11207)
                .desc("Dagger es yang membekukan lawan.")
                .passive(class_1294.field_5910, 0)
                .info(Use.PASSIVE, "Ice Dagger", "Muncul otomatis di inventory (tak bisa dibuang), serangan cepat")
                .info(Use.PASSIVE, "Pukulan Beku", "Tiap pukulan: musuh beku dan lambat")
                .power(Use.RIGHT, "Pembekuan", 20,
                        "Bekukan makhluk sekitar", (p, w) -> {
                    for (class_1309 e : around(p, 8, false)) {
                        give(e, class_1294.field_5909, 4, 6);
                        e.method_32317(200);
                    }
                    give(p, class_1294.field_5907, 6, 1);
                    w.method_65096(class_2398.field_28013, p.method_23317(), p.method_23318() + 1, p.method_23321(), 60, 3, 1, 3, 0.05);
                }));

        CORROSIVE_STONE = add(new StoneDef("corrosive_stone").style(4).aura(class_2398.field_11211).fx(class_2398.field_11249)
                .desc("Batu pengikis: kamu melemah, musuh berkarat.")
                .info(Use.PASSIVE, "Wither Pelan", "Kamu terkena Wither pelan, berhenti di 4 hati (tidak mati)")
                .info(Use.PASSIVE, "Karat", "Tiap pukulan: durability armor/senjata musuh -20")
                .power(Use.SNEAK, "Karat Total", 40,
                        "Senjata musuh hancur 5 detik, lalu dikembalikan", Skills::disarm)
                .power(Use.RIGHT, "Celah Hampa", 25,
                        "Tarik semua makhluk ke arahmu", (p, w) -> {
                    for (class_1309 e : around(p, 10, false)) {
                        push(e, p, 1.4, 0.1);
                        give(e, class_1294.field_5912, 8, 0);
                    }
                    w.method_65096(class_2398.field_23190, p.method_23317(), p.method_23318() + 1, p.method_23321(), 80, 2, 1, 2, 0.2);
                }));

        // ---------------------------------------------------------------- Sculk Sense
        add(new StoneDef("sculk_sense").style(5).aura(class_2398.field_38002).fx(class_2398.field_23114)
                .desc("Kekuatan Warden.")
                .passive(class_1294.field_5925, 0)
                .info(Use.PASSIVE, "Deteksi Getaran", "Makhluk sekitar bersinar")
                .tick((p, w) -> {
                    for (class_1309 e : around(p, 16, false)) {
                        give(e, class_1294.field_5912, 2, 0);
                    }
                })
                .power(Use.RIGHT, "Double Sonic Boom", 20,
                        "2 Sonic Boom 10 hati + getaran tanah", Skills::doubleSonic)
                .power(Use.SNEAK, "Bayangan Sunyi", 60,
                        "Mob tak bisa melihatmu dan kabur", Skills::stealth)
                .power(Use.OFFHAND, "Darah Warden", 90,
                        "+200 HP, mob ketakutan (30 detik)",
                        Skills::wardenBlood));

        // ---------------------------------------------------------------- Copper Surge (tanpa efek potion)
        add(new StoneDef("copper_surge").style(3).aura(class_2398.field_29644).fx(class_2398.field_11205)
                .desc("Petir dahsyat (tanpa efek potion).")
                .power(Use.RIGHT, "Tiga Jalur Petir", 15,
                        "3 jalur petir menyapu ke depan",
                        Skills::copperLines)
                .power(Use.SNEAK, "Cincin Petir", 30,
                        "Petir membentuk lingkaran di sekitarmu", Skills::copperRing)
                .power(Use.OFFHAND, "Petir Penghancur", 60,
                        "Ledakan petir, tanah hancur",
                        Skills::copperMega));

        add(new StoneDef("crying_obsidian_tear").style(4).aura(class_2398.field_22446).fx(class_2398.field_11214)
                .desc("Teleport dan lemahkan musuh.")
                .passive(class_1294.field_5907, 0).passive(class_1294.field_5925, 0)
                .power(Use.RIGHT, "Tangisan Portal", 30,
                        "Lemahkan musuh + teleport maju", (p, w) -> {
                    for (class_1309 e : around(p, 10, true)) {
                        give(e, class_1294.field_5911, 10, 1);
                    }
                    blink(p, 25);
                    give(p, class_1294.field_5898, 8, 1);
                    give(p, class_1294.field_5904, 4, 1);
                }));

        add(new StoneDef("blackstone_ward").style(5).aura(class_2398.field_22247).fx(class_2398.field_11237)
                .desc("Penjaga Nether yang kokoh.")
                .passive(class_1294.field_5907, 0).passive(class_1294.field_5898, 0)
                .power(Use.RIGHT, "Dorongan Batu", 15,
                        "Dorong makhluk di depanmu jauh ke depan", Skills::blackstonePush)
                .power(Use.SNEAK, "Benteng Blackstone", 45,
                        "Kubah batu pelindung 10 detik + Regeneration", Skills::blackstoneDome)
                .power(Use.OFFHAND, "Golem Penjaga", 60,
                        "Panggil 2 Iron Golem sekutu (45 detik)", Skills::blackstoneGolems));

        QUARTZ_RADIANCE = add(new StoneDef("quartz_radiance").style(1).aura(class_2398.field_11204).fx(class_2398.field_11207)
                .desc("Cahaya kemurnian: laser 5 hati/tick dan penyucian.")
                .passive(class_1294.field_5924, 0).passive(class_1294.field_5914, 0)
                .power(Use.RIGHT, "Sinar Laser", 25,
                        "Laser putih bisa ditahan 10 detik, 5 hati/tick, kamu bersinar", Skills::laser)
                .power(Use.SNEAK, "Penyucian", 30,
                        "Hapus efek buruk + sembuhkan", (p, w) -> {
                    for (class_1293 i : new ArrayList<>(p.method_6026())) {
                        if (i.method_5579().comp_349().method_18792() == class_4081.field_18272) {
                            p.method_6016(i.method_5579());
                        }
                    }
                    p.method_6025(6.0F);
                    p.method_7344().method_7585(6, 0.6F);
                    give(p, class_1294.field_5924, 6, 1);
                    for (class_1309 e : around(p, 8, false)) {
                        if (e instanceof class_1657) {
                            e.method_6025(6.0F);
                        }
                    }
                }));

        // ---------------------------------------------------------------- Galaxy Stone
        GALAXY_STONE = add(new StoneDef("galaxy_stone").style(4).aura(class_2398.field_11207).fx(class_2398.field_11214)
                .desc("Terbang dan kuasai gravitasi.")
                .info(Use.PASSIVE, "Terbang", "Terbang bebas seperti creative")
                .power(Use.RIGHT, "Lontar Angkasa", 20,
                        "Lontarkan makhluk ke atas", Skills::galaxyLaunch)
                .power(Use.SNEAK, "Tarikan Gravitasi", 45,
                        "Tarik makhluk dan bekukan 20 detik", Skills::galaxyFreeze)
                .power(Use.OFFHAND, "Lubang Hitam", 120,
                        "Sedot dan hancurkan di titik bidik",
                        Skills::galaxyBlackHole));

        // ---------------------------------------------------------------- True Stone
        TRUE_STONE = add(new StoneDef("true_stone").style(2).aura(class_2398.field_11208).fx(class_2398.field_11205)
                .desc("Pedang sejati muncul otomatis. Skill terbuka dari kill mob.")
                .passive(class_1294.field_5910, 0).passive(class_1294.field_5904, 0)
                .info(Use.PASSIVE, "True Blade", "Pedang Sharpness V muncul otomatis di inventory (tak bisa dibuang)")
                .info(Use.PASSIVE, "25 kill", "Untouchable: kebal 2 detik saat diserang")
                .info(Use.PASSIVE, "100 kill", "Musuh yang kamu bunuh lenyap tanpa drop")
                .info(Use.PASSIVE, "Bunuh pemain", "Dapat 1 armor netherite"));

        class_2960 bid = class_2960.method_60655(PowerStones.MOD_ID, "true_blade");
        class_5321<class_1792> bkey = class_5321.method_29179(class_7924.field_41197, bid);
        TRUE_BLADE = new class_1792(new class_1792.class_1793().method_63686(bkey).method_7889(1).method_7894(class_1814.field_8904)
                .method_66333(class_9886.field_52590, 3.0F, -2.4F));
        class_2378.method_39197(class_7923.field_41178, bkey, TRUE_BLADE);

        class_5321<class_1792> mkey = class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(PowerStones.MOD_ID, "magma_staff"));
        MAGMA_STAFF = new MagmaStaffItem(new class_1792.class_1793().method_63686(mkey).method_7889(1).method_7894(class_1814.field_8904));
        class_2378.method_39197(class_7923.field_41178, mkey, MAGMA_STAFF);

        class_5321<class_1792> dkey = class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(PowerStones.MOD_ID, "ice_dagger"));
        ICE_DAGGER = new class_1792(new class_1792.class_1793().method_63686(dkey).method_7889(1).method_7894(class_1814.field_8904)
                .method_66333(class_9886.field_52588, 1.5F, -1.0F));
        class_2378.method_39197(class_7923.field_41178, dkey, ICE_DAGGER);

        // ---------------------------------------------------------------- Blood Stone (baru)
        BLOOD_STONE = add(new StoneDef("blood_stone").style(3).aura(class_2398.field_22248).fx(class_2398.field_11201)
                .desc("Kekuatan darah: tiap pukulan menyembuhkanmu.")
                .info(Use.PASSIVE, "Hisap Darah", "Tiap pukulan menyembuhkanmu 1 hati")
                .power(Use.RIGHT, "Tumbal Darah", 30,
                        "Korbankan 4 hati: Strength III + Speed II (12 detik)", Skills::bloodSacrifice)
                .power(Use.SNEAK, "Rantai Darah", 45,
                        "Musuh yang dibidik menanggung 50% damage yang kamu terima (10 detik)", Skills::bloodLink)
                .power(Use.OFFHAND, "Pesta Darah", 90,
                        "10 detik: musuh radius 8 kehilangan 1 hati/detik, kamu sembuh", Skills::bloodFeast));

        // ---------------------------------------------------------------- Magnet Stone (baru)
        MAGNET_STONE = add(new StoneDef("magnet_stone").style(3).aura(class_2398.field_29644).fx(class_2398.field_11205)
                .desc("Genggam makhluk dari jauh.")
                .power(Use.RIGHT, "Genggam / Lepas", 0,
                        "Genggam makhluk yang kamu lihat",
                        Skills::magnetToggle)
                .power(Use.SNEAK, "Lempar", 3,
                        "Lempar makhluk yang digenggam", Skills::magnetThrow)
                .power(Use.OFFHAND, "Atur Jarak", 0,
                        "Ganti jarak genggam", Skills::magnetDistance));

        // ---------------------------------------------------------------- Control Stone (baru)
        add(new StoneDef("control_stone").style(0).aura(class_2398.field_11214).fx(class_2398.field_29644)
                .desc("Tembakkan projectile pilihanmu.")
                .power(Use.RIGHT, "Tembak", 15,
                        "Tembak 15 projectile cepat", Skills::fireProjectiles)
                .power(Use.SNEAK, "Pilih Projectile", 0,
                        "Ketik nama projectile di chat",
                        Skills::chooseProjectile));

        // ---------------------------------------------------------------- Stone Holder
        class_2960 hid = class_2960.method_60655(PowerStones.MOD_ID, "stone_holder");
        class_5321<class_1792> hkey = class_5321.method_29179(class_7924.field_41197, hid);
        HOLDER = new StoneHolderItem(new class_1792.class_1793().method_63686(hkey).method_7889(1).method_7894(class_1814.field_8904));
        class_2378.method_39197(class_7923.field_41178, hkey, HOLDER);
        TAB.add(HOLDER);
    }

    private static StoneItem add(StoneDef def) {
        class_2960 id = class_2960.method_60655(PowerStones.MOD_ID, def.id);
        class_5321<class_1792> key = class_5321.method_29179(class_7924.field_41197, id);
        class_1792.class_1793 settings = new class_1792.class_1793().method_63686(key).method_7889(1).method_7894(class_1814.field_8904);
        if (def.sword) {
            settings = settings.method_66333(class_9886.field_52590, 3.0F, -2.4F);
        }
        if (def.chestplate) {
            settings = settings
                    .method_57349(class_9334.field_54196, class_10192.method_64202(class_1304.field_6174)
                            .method_64204(class_5321.method_29179(class_10191.field_55214, class_2960.method_60655(PowerStones.MOD_ID, def.id)))
                            .method_64203())
                    .method_57348(class_9285.method_57480()
                            .method_57487(class_5134.field_23724,
                                    new class_1322(class_2960.method_60655(PowerStones.MOD_ID, def.id + "_armor"),
                                            10.0, class_1322.class_1323.field_6328),
                                    class_9274.field_49222)
                            .method_57487(class_5134.field_23725,
                                    new class_1322(class_2960.method_60655(PowerStones.MOD_ID, def.id + "_toughness"),
                                            4.0, class_1322.class_1323.field_6328),
                                    class_9274.field_49222)
                            .method_57486());
        }
        StoneItem item = new StoneItem(settings, def);
        class_2378.method_39197(class_7923.field_41178, key, item);
        ITEMS.put(def.id, item);
        TAB.add(item);
        return item;
    }
}
