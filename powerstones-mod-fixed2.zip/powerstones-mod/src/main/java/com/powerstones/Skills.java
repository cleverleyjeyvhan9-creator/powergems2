package com.powerstones;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;
import java.util.Map;
import java.util.UUID;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1304;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1538;
import net.minecraft.class_1657;
import net.minecraft.class_1676;
import net.minecraft.class_1687;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3730;
import net.minecraft.class_7923;
import net.minecraft.server.MinecraftServer;

/** Skill-skill rumit yang tidak muat sebagai lambda pendek. */
public final class Skills {

    private static final Map<UUID, Long> STEALTH = new HashMap<>();
    private static final Map<UUID, Long> WARDEN = new HashMap<>();
    private static final Map<UUID, UUID> HELD = new HashMap<>();
    private static final Map<UUID, Double> HELD_DIST = new HashMap<>();
    private static final Map<UUID, String> PROJECTILE = new HashMap<>();
    private static final Map<UUID, class_1799[]> STASH = new HashMap<>();
    private static final class_1304[] ARMOR = {class_1304.field_6169, class_1304.field_6174,
            class_1304.field_6172, class_1304.field_6166};

    private Skills() {}

    // ================================================================ COPPER SURGE

    private static void strike(class_3218 w, double x, double y, double z, class_3222 owner) {
        class_1538 bolt = class_1299.field_6112.method_5883(w, class_3730.field_16461);
        if (bolt == null) {
            return;
        }
        bolt.method_24203(x, y, z);
        bolt.method_6961(owner);
        w.method_8649(bolt);
        w.method_65096(class_2398.field_29644, x, y + 1.0, z, 24, 0.4, 1.0, 0.4, 0.25);
    }

    /** 3 jalur petir menyapu 10 block ke depan; petir di belakang lenyap saat gelombang maju. */
    public static void copperLines(class_3222 p, class_3218 w) {
        class_243 look = p.method_5828(1.0F);
        class_243 d = new class_243(look.field_1352, 0, look.field_1350).method_1029();
        class_243 side = new class_243(-d.field_1350, 0, d.field_1352);
        double y = p.method_23318();
        double px = p.method_23317();
        double pz = p.method_23321();
        for (int step = 0; step < 10; step++) {
            double dist = 3 + step;
            Scheduler.later(1 + step * 2, () -> {
                for (int lane = -1; lane <= 1; lane++) {
                    strike(w, px + d.field_1352 * dist + side.field_1352 * lane * 3.0, y, pz + d.field_1350 * dist + side.field_1350 * lane * 3.0, p);
                }
            });
        }
        w.method_8396(null, p.method_24515(), class_3417.field_14865, class_3419.field_15248, 2.0F, 1.0F);
    }

    /** Dua cincin petir bulat di sekeliling pemain. */
    public static void copperRing(class_3222 p, class_3218 w) {
        double y = p.method_23318();
        double px = p.method_23317();
        double pz = p.method_23321();
        for (int i = 0; i < 12; i++) {
            double a = i * Math.PI * 2 / 12;
            Scheduler.later(1 + i, () -> strike(w, px + Math.cos(a) * 6, y, pz + Math.sin(a) * 6, p));
        }
        for (int i = 0; i < 18; i++) {
            double a = i * Math.PI * 2 / 18 + 0.2;
            Scheduler.later(16 + i, () -> strike(w, px + Math.cos(a) * 10, y, pz + Math.sin(a) * 10, p));
        }
        w.method_8396(null, p.method_24515(), class_3417.field_14865, class_3419.field_15248, 2.0F, 0.8F);
    }

    /** Petir super: badai petir beruntun lalu ledakan yang menghancurkan tanah. */
    public static void copperMega(class_3222 p, class_3218 w) {
        class_243 eye = Fx.eye(p);
        class_243 dir = p.method_5828(1.0F);
        class_239 hit = p.method_5745(40, 1.0F, false);
        class_243 pos = hit.method_17783() == class_239.class_240.field_1333 ? eye.method_1019(dir.method_1021(40)) : hit.method_17784();
        if (pos.method_1022(eye) < 10) {
            pos = eye.method_1019(dir.method_1021(10));
        }
        class_243 t = pos;
        for (int i = 0; i < 8; i++) {
            double a = i * Math.PI / 4;
            Scheduler.later(1 + i * 2, () -> strike(w, t.field_1352 + Math.cos(a) * 3, t.field_1351, t.field_1350 + Math.sin(a) * 3, p));
        }
        Scheduler.later(20, () -> {
            strike(w, t.field_1352, t.field_1351, t.field_1350, p);
            strike(w, t.field_1352, t.field_1351, t.field_1350, p);
            w.method_8437(null, t.field_1352, t.field_1351, t.field_1350, 6.0F, class_1937.class_7867.field_40891);
            w.method_65096(class_2398.field_11221, t.field_1352, t.field_1351 + 1, t.field_1350, 3, 1, 1, 1, 0);
            w.method_65096(class_2398.field_29644, t.field_1352, t.field_1351 + 1, t.field_1350, 200, 4, 3, 4, 0.5);
        });
        w.method_8396(null, p.method_24515(), class_3417.field_14865, class_3419.field_15248, 3.0F, 0.6F);
    }

    // ================================================================ SCULK SENSE

    private static void sonic(class_3222 p, class_3218 w, float damage, int range) {
        class_243 start = Fx.eye(p);
        class_243 dir = p.method_5828(1.0F);
        for (int i = 1; i <= range; i++) {
            class_243 pt = start.method_1019(dir.method_1021(i));
            w.method_65096(class_2398.field_38908, pt.field_1352, pt.field_1351, pt.field_1350, 1, 0, 0, 0, 0);
        }
        class_238 box = new class_238(start, start.method_1019(dir.method_1021(range))).method_1014(1.5);
        for (class_1309 e : w.method_8390(class_1309.class, box,
                x -> x != p && x.method_5805() && !Allies.isAlly(x))) {
            e.method_64397(w, w.method_48963().method_48821(p), damage);
            e.method_5762(dir.field_1352 * 1.5, 0.4, dir.field_1350 * 1.5);
        }
        w.method_8396(null, p.method_24515(), class_3417.field_38830, class_3419.field_15248, 3.0F, 1.0F);
    }

    /** 2 Sonic Boom beruntun, masing-masing 20 damage (10 hati). */
    /** Getaran tanah: makhluk di sekitar terguncang selama ~1 detik. */
    private static void tremor(class_3222 p, class_3218 w) {
        for (int t = 0; t < 16; t++) {
            int tick = t;
            Scheduler.later(1 + t, () -> {
                ThreadLocalRandom r = ThreadLocalRandom.current();
                for (class_1309 e : Fx.around(p, 14, false)) {
                    e.method_5762((r.nextDouble() - 0.5) * 0.25, 0.05, (r.nextDouble() - 0.5) * 0.25);
                }
                p.method_5762((r.nextDouble() - 0.5) * 0.08, 0.0, (r.nextDouble() - 0.5) * 0.08);
                for (int k = 0; k < 32; k++) {
                    double a = k * Math.PI * 2 / 32;
                    double rr = 1.0 + tick * 0.9;
                    w.method_65096(class_2398.field_22247, p.method_23317() + Math.cos(a) * rr, p.method_23318() + 0.1,
                            p.method_23321() + Math.sin(a) * rr, 1, 0, 0.15, 0, 0.02);
                }
            });
        }
    }

    public static void doubleSonic(class_3222 p, class_3218 w) {
        tremor(p, w);
        sonic(p, w, 20.0F, 24);
        Scheduler.later(12, () -> {
            if (p.method_5805()) {
                sonic(p, p.method_51469(), 20.0F, 24);
            }
        });
    }

    public static void stealth(class_3222 p, class_3218 w) {
        STEALTH.put(p.method_5667(), w.method_75260() + 300);
        Fx.give(p, class_1294.field_5905, 15, 0);
        w.method_65096(class_2398.field_38002, p.method_23317(), p.method_23318() + 1, p.method_23321(), 60, 1, 1, 1, 0.05);
    }

    public static void wardenBlood(class_3222 p, class_3218 w) {
        WARDEN.put(p.method_5667(), w.method_75260() + 600);
        Fx.give(p, class_1294.field_5914, 30, 49);
        Fx.give(p, class_1294.field_5907, 30, 1);
        Fx.give(p, class_1294.field_5924, 30, 1);
        Scheduler.later(3, () -> p.method_6033(p.method_6063()));
        w.method_65096(class_2398.field_38002, p.method_23317(), p.method_23318() + 1, p.method_23321(), 120, 1.5, 1.5, 1.5, 0.1);
        w.method_8396(null, p.method_24515(), class_3417.field_38075, class_3419.field_15248, 3.0F, 1.0F);
    }

    /** Dipanggil tiap 5 tick: mob di sekitar pemain yang bersembunyi / mode Warden kabur dan kehilangan target. */
    public static void stealthTick(MinecraftServer server) {
        if (STEALTH.isEmpty() && WARDEN.isEmpty()) {
            return;
        }
        for (class_3222 p : server.method_3760().method_14571()) {
            class_3218 w = p.method_51469();
            long now = w.method_75260();
            boolean warden = WARDEN.getOrDefault(p.method_5667(), 0L) > now;
            boolean hidden = STEALTH.getOrDefault(p.method_5667(), 0L) > now;
            if (!warden && !hidden) {
                continue;
            }
            double r = warden ? 24 : 16;
            for (class_1308 m : w.method_8390(class_1308.class, p.method_5829().method_1014(r),
                    x -> x.method_5805() && !Allies.isAlly(x))) {
                if (m.method_5968() == p) {
                    m.method_5980(null);
                }
                class_243 away = new class_243(m.method_23317() - p.method_23317(), 0, m.method_23321() - p.method_23321());
                if (away.method_1027() < 1.0E-4) {
                    continue;
                }
                class_243 a = away.method_1029().method_1021(12);
                m.method_5942().method_6337(m.method_23317() + a.field_1352, m.method_23318(), m.method_23321() + a.field_1350, 1.3);
            }
        }
    }

    // ================================================================ GALAXY STONE

    public static void galaxyLaunch(class_3222 p, class_3218 w) {
        for (class_1309 e : Fx.around(p, 12, false)) {
            e.method_5762(0, 2.2, 0);
            w.method_65096(class_2398.field_11207, e.method_23317(), e.method_23318() + 1, e.method_23321(), 30, 0.3, 1.0, 0.3, 0.05);
        }
        w.method_65096(class_2398.field_11207, p.method_23317(), p.method_23318() + 0.5, p.method_23321(), 80, 5, 0.3, 5, 0.1);
    }

    public static void galaxyFreeze(class_3222 p, class_3218 w) {
        class_243 look = p.method_5828(1.0F);
        class_243 d = new class_243(look.field_1352, 0, look.field_1350).method_1029();
        int i = 0;
        for (class_1309 e : Fx.around(p, 14, false)) {
            double a = i * 0.9;
            double x = p.method_23317() + d.field_1352 * 4 + Math.cos(a) * 1.5;
            double z = p.method_23321() + d.field_1350 * 4 + Math.sin(a) * 1.5;
            e.method_5859(x, p.method_23318(), z);
            e.method_18799(class_243.field_1353);
            Fx.give(e, class_1294.field_5909, 20, 6);
            Fx.give(e, class_1294.field_5911, 20, 2);
            if (e instanceof class_1308 m) {
                m.method_5977(true);
                Scheduler.later(400, () -> m.method_5977(false));
            }
            w.method_65096(class_2398.field_11207, x, p.method_23318() + 1, z, 20, 0.3, 0.8, 0.3, 0.02);
            i++;
        }
    }

    public static void galaxyBlackHole(class_3222 p, class_3218 w) {
        class_243 eye = Fx.eye(p);
        class_243 dir = p.method_5828(1.0F);
        class_239 hit = p.method_5745(25, 1.0F, false);
        class_243 c = hit.method_17783() == class_239.class_240.field_1333 ? eye.method_1019(dir.method_1021(20)) : hit.method_17784();
        class_243 center = new class_243(c.field_1352, c.field_1351 + 3, c.field_1350);
        w.method_8396(null, p.method_24515(), class_3417.field_14792, class_3419.field_15248, 2.0F, 0.5F);
        for (int t = 0; t < 200; t++) {
            int tick = t;
            Scheduler.later(1 + t, () -> blackHoleTick(p, w, center, tick));
        }
        Scheduler.later(205, () -> {
            w.method_65096(class_2398.field_11221, center.field_1352, center.field_1351, center.field_1350, 2, 1, 1, 1, 0);
            w.method_65096(class_2398.field_11207, center.field_1352, center.field_1351, center.field_1350, 300, 5, 5, 5, 0.6);
        });
    }

    private static void blackHoleTick(class_3222 owner, class_3218 w, class_243 center, int tick) {
        // visual: lengan spiral berputar menuju pusat
        for (int arm = 0; arm < 4; arm++) {
            for (int k = 1; k <= 7; k++) {
                double r = k * 1.6;
                double a = tick * 0.35 + k * 0.55 + arm * Math.PI / 2;
                double x = center.field_1352 + Math.cos(a) * r;
                double z = center.field_1350 + Math.sin(a) * r;
                double y = center.field_1351 + Math.sin(a * 0.5) * r * 0.15;
                w.method_65096(k < 4 ? class_2398.field_23190 : class_2398.field_11214, x, y, z, 2, 0, 0, 0, 0);
                if (k == 6) {
                    w.method_65096(class_2398.field_11207, x, y, z, 1, 0, 0, 0, 0);
                }
            }
        }
        w.method_65096(class_2398.field_11237, center.field_1352, center.field_1351, center.field_1350, 8, 0.6, 0.6, 0.6, 0.02);
        w.method_65096(class_2398.field_11251, center.field_1352, center.field_1351, center.field_1350, 12, 1.0, 1.0, 1.0, 0.05);

        // tarik semua entitas (kecuali pemilik)
        class_238 box = new class_238(center.field_1352 - 15, center.field_1351 - 15, center.field_1350 - 15, center.field_1352 + 15, center.field_1351 + 15, center.field_1350 + 15);
        for (class_1297 e : w.method_8333(owner, box, x -> !Allies.isAlly(x))) {
            double dx = center.field_1352 - e.method_23317();
            double dy = center.field_1351 - e.method_23318();
            double dz = center.field_1350 - e.method_23321();
            double d = Math.sqrt(dx * dx + dy * dy + dz * dz);
            if (d < 0.5 || d > 15) {
                continue;
            }
            double f = (0.25 + (15 - d) / 15.0 * 0.9) * 0.4;
            e.method_5762(dx / d * f, dy / d * f, dz / d * f);
            if (d < 4 && tick % 5 == 0 && e instanceof class_1309 le) {
                le.method_64397(w, w.method_48963().method_48831(), 4.0F);
            }
            if (d < 2 && !(e instanceof class_1309) && !(e instanceof class_1657)) {
                e.method_31472();
            }
        }

        // lahap blok di sekitar pusat
        if (tick % 10 == 0) {
            for (int dx = -3; dx <= 3; dx++) {
                for (int dy = -3; dy <= 3; dy++) {
                    for (int dz = -3; dz <= 3; dz++) {
                        if (dx * dx + dy * dy + dz * dz > 9) {
                            continue;
                        }
                        class_2338 bp = class_2338.method_49637(center.field_1352 + dx, center.field_1351 + dy, center.field_1350 + dz);
                        class_2680 st = w.method_8320(bp);
                        if (!st.method_26215() && st.method_26214(w, bp) >= 0) {
                            w.method_8501(bp, class_2246.field_10124.method_9564());
                        }
                    }
                }
            }
        }
    }

    // ================================================================ ENDER STONE

    public static void enderPrompt(class_3222 p, class_3218 w) {
        Inputs.ask(p, "Ender Stone: ketik koordinat tujuan di chat dengan format X Y Z (contoh: 100 70 -250). "
                + "Format X Z memakai ketinggianmu sekarang. Ketik 'batal' untuk membatalkan.", Skills::enderGo);
    }

    private static void enderGo(class_3222 p, String text) {
        String t = text.trim().toLowerCase();
        if (t.equals("batal")) {
            p.method_7353(class_2561.method_43470("Teleport dibatalkan."), true);
            return;
        }
        String[] parts = t.replace(",", " ").split("\\s+");
        double x;
        double y;
        double z;
        try {
            if (parts.length == 3) {
                x = Double.parseDouble(parts[0]);
                y = Double.parseDouble(parts[1]);
                z = Double.parseDouble(parts[2]);
            } else if (parts.length == 2) {
                x = Double.parseDouble(parts[0]);
                y = p.method_23318();
                z = Double.parseDouble(parts[1]);
            } else {
                p.method_7353(class_2561.method_43470("Format salah. Contoh: 100 70 -250"), true);
                return;
            }
        } catch (NumberFormatException ex) {
            p.method_7353(class_2561.method_43470("Koordinat harus berupa angka. Contoh: 100 70 -250"), true);
            return;
        }
        class_3218 w = p.method_51469();
        y = Math.max(w.method_31607() + 1, Math.min(w.method_31607() + w.method_31605() - 2, y));
        if (!w.method_8621().method_11952(class_2338.method_49637(x, y, z))) {
            p.method_7353(class_2561.method_43470("Koordinat di luar batas dunia."), true);
            return;
        }
        if (!Cooldowns.ready(p, "ender_shard-go", 8)) {
            return;
        }
        w.method_65096(class_2398.field_11214, p.method_23317(), p.method_23318() + 1, p.method_23321(), 80, 0.5, 1, 0.5, 0.6);
        p.method_5859(x, y, z);
        w.method_65096(class_2398.field_11214, x, y + 1, z, 80, 0.5, 1, 0.5, 0.6);
        w.method_8396(null, p.method_24515(), class_3417.field_14879, class_3419.field_15248, 1.0F, 1.0F);
        Fx.give(p, class_1294.field_5906, 6, 0);
        p.method_7353(class_2561.method_43470("Teleport ke " + (int) x + " " + (int) y + " " + (int) z), true);
    }

    // ================================================================ MAGNET STONE

    public static void magnetToggle(class_3222 p, class_3218 w) {
        UUID id = p.method_5667();
        if (HELD.containsKey(id)) {
            magnetRelease(p);
            p.method_7353(class_2561.method_43470("Entity dilepas."), true);
            return;
        }
        class_1309 t = Fx.target(p, 15);
        if (t == null) {
            p.method_7353(class_2561.method_43470("Tidak ada entity di arah pandanganmu (maks 15 block)."), true);
            return;
        }
        HELD.put(id, t.method_5667());
        HELD_DIST.put(id, Math.max(3.0, Math.sqrt(t.method_5858(p))));
        p.method_7353(class_2561.method_43470("Entity digenggam. Klik kanan lagi untuk melepas."), true);
    }

    private static void magnetRelease(class_3222 p) {
        UUID target = HELD.remove(p.method_5667());
        HELD_DIST.remove(p.method_5667());
        if (target != null && p.method_51469().method_66347(target) instanceof class_1309 le) {
            Fx.give(le, class_1294.field_5906, 4, 0);
        }
    }

    public static void magnetThrow(class_3222 p, class_3218 w) {
        UUID target = HELD.get(p.method_5667());
        if (target == null) {
            p.method_7353(class_2561.method_43470("Belum menggenggam entity."), true);
            return;
        }
        class_1297 e = w.method_66347(target);
        class_243 dir = p.method_5828(1.0F);
        magnetRelease(p);
        if (e != null) {
            e.method_5762(dir.field_1352 * 3.5, dir.field_1351 * 3.5 + 0.3, dir.field_1350 * 3.5);
        }
    }

    public static void magnetDistance(class_3222 p, class_3218 w) {
        UUID id = p.method_5667();
        if (!HELD.containsKey(id)) {
            p.method_7353(class_2561.method_43470("Belum menggenggam entity."), true);
            return;
        }
        double d = HELD_DIST.getOrDefault(id, 6.0) + 4.0;
        if (d > 15.0) {
            d = 4.0;
        }
        HELD_DIST.put(id, d);
        p.method_7353(class_2561.method_43470("Jarak genggaman: " + (int) d + " block"), true);
    }

    /** Dipanggil tiap tick: entity yang digenggam mengikuti arah pandangan pemain. */
    public static void magnetTick(MinecraftServer server) {
        if (HELD.isEmpty()) {
            return;
        }
        for (class_3222 p : server.method_3760().method_14571()) {
            UUID target = HELD.get(p.method_5667());
            if (target == null) {
                continue;
            }
            class_1297 e = p.method_51469().method_66347(target);
            if (e == null || !e.method_5805() || !PowerStones.holds(p, Stones.MAGNET_STONE)) {
                magnetRelease(p);
                continue;
            }
            double dist = HELD_DIST.getOrDefault(p.method_5667(), 6.0);
            class_243 pos = Fx.eye(p).method_1019(p.method_5828(1.0F).method_1021(dist));
            e.method_5859(pos.field_1352, pos.field_1351 - 0.5, pos.field_1350);
            e.method_18799(class_243.field_1353);
            p.method_51469().method_65096(class_2398.field_29644, pos.field_1352, pos.field_1351, pos.field_1350, 3, 0.3, 0.3, 0.3, 0.02);
        }
    }

    // ================================================================ CONTROL STONE

    public static void chooseProjectile(class_3222 p, class_3218 w) {
        Inputs.ask(p, "Control Stone: ketik nama projectile di chat (contoh: arrow, spectral_arrow, fireball, "
                + "small_fireball, blue_wither_skull, wither_skull, dragon_fireball, snowball, egg, trident). "
                + "Ketik 'batal' untuk membatalkan.", (pl, text) -> {
            String name = text.trim().toLowerCase().replace(' ', '_');
            if (name.equals("batal")) {
                pl.method_7353(class_2561.method_43470("Dibatalkan."), true);
                return;
            }
            String real = name.equals("blue_wither_skull") ? "wither_skull" : name;
            if (!class_7923.field_41177.method_10250(class_2960.method_60655("minecraft", real))) {
                pl.method_7353(class_2561.method_43470("Projectile '" + name + "' tidak ditemukan."), false);
                return;
            }
            PROJECTILE.put(pl.method_5667(), name);
            pl.method_7353(class_2561.method_43470("Projectile dipilih: " + name), true);
        });
    }

    public static void fireProjectiles(class_3222 p, class_3218 w) {
        String name = PROJECTILE.getOrDefault(p.method_5667(), "arrow");
        boolean blue = name.equals("blue_wither_skull");
        String real = blue ? "wither_skull" : name;
        class_2960 id = class_2960.method_60655("minecraft", real);
        if (real.equals("fishing_bobber") || !class_7923.field_41177.method_10250(id)) {
            p.method_7353(class_2561.method_43470("Projectile '" + name + "' tidak bisa ditembakkan."), true);
            return;
        }
        class_1299<?> type = class_7923.field_41177.method_63535(id);
        class_243 dir = p.method_5828(1.0F);
        class_243 eye = Fx.eye(p);
        class_243 side = new class_243(-dir.field_1350, 0, dir.field_1352).method_1029();
        for (int i = 0; i < 15; i++) {
            class_1297 e = type.method_5883(w, class_3730.field_16461);
            if (!(e instanceof class_1676 pr)) {
                if (e != null) {
                    e.method_31472();
                }
                p.method_7353(class_2561.method_43470("'" + name + "' bukan projectile."), true);
                return;
            }
            double off = ((i % 5) - 2) * 0.35;
            double up = ((i / 5) - 1) * 0.35;
            pr.method_7432(p);
            pr.method_5814(eye.field_1352 + dir.field_1352 * 1.5 + side.field_1352 * off, eye.field_1351 + dir.field_1351 * 1.5 + up - 0.2, eye.field_1350 + dir.field_1350 * 1.5 + side.field_1350 * off);
            pr.method_7485(dir.field_1352, dir.field_1351, dir.field_1350, 3.5F, 1.5F);
            if (blue && pr instanceof class_1687 skull) {
                skull.method_7502(true);
            }
            w.method_8649(pr);
        }
        w.method_8396(null, p.method_24515(), class_3417.field_14970, class_3419.field_15248, 2.0F, 1.4F);
    }

    // ================================================================ BLACKSTONE WARD

    /** Mendorong semua makhluk di depanmu jauh ke depan. */
    public static void blackstonePush(class_3222 p, class_3218 w) {
        class_243 look = p.method_5828(1.0F);
        class_243 eye = Fx.eye(p);
        for (class_1309 e : Fx.around(p, 14, false)) {
            class_243 to = new class_243(e.method_23317() - eye.field_1352, e.method_23323(0.5) - eye.field_1351, e.method_23321() - eye.field_1350);
            if (to.method_1033() < 0.1 || look.method_1026(to.method_1029()) < 0.45) {
                continue;
            }
            e.method_5762(look.field_1352 * 3.0, 0.6, look.field_1350 * 3.0);
            e.method_64397(w, w.method_48963().method_48802(p), 5.0F);
            w.method_65096(class_2398.field_11237, e.method_23317(), e.method_23318() + 1, e.method_23321(), 12, 0.3, 0.5, 0.3, 0.05);
        }
        for (int i = 1; i <= 14; i++) {
            double spread = i * 0.22;
            class_243 pt = eye.method_1019(look.method_1021(i));
            w.method_65096(class_2398.field_22247, pt.field_1352, pt.field_1351 - 0.3, pt.field_1350, 16, spread, spread * 0.6, spread, 0.02);
            w.method_65096(class_2398.field_11237, pt.field_1352, pt.field_1351 - 0.3, pt.field_1350, 3, spread * 0.5, spread * 0.3, spread * 0.5, 0.02);
        }
        w.method_8396(null, p.method_24515(), class_3417.field_14649, class_3419.field_15248, 2.0F, 0.6F);
    }

    /** Kubah Blackstone: dibangun dari bawah ke atas, bertahan 10 detik, lalu runtuh dari atas. */
    public static void blackstoneDome(class_3222 p, class_3218 w) {
        class_2338 c = p.method_24515();
        int radius = 5;
        for (class_1309 e : Fx.around(p, radius - 0.2, true)) {
            Fx.push(e, p, -1.8, 0.5);
        }
        List<class_2338> shell = new ArrayList<>();
        List<Integer> layer = new ArrayList<>();
        for (int dy = -1; dy <= radius; dy++) {
            for (int dx = -radius; dx <= radius; dx++) {
                for (int dz = -radius; dz <= radius; dz++) {
                    double d = Math.sqrt(dx * dx + dy * dy + dz * dz);
                    if (d > radius - 0.5 && d <= radius + 0.5) {
                        shell.add(c.method_10069(dx, dy, dz));
                        layer.add(dy);
                    }
                }
            }
        }
        Set<class_2338> placed = new HashSet<>();
        for (int i = 0; i < shell.size(); i++) {
            class_2338 bp = shell.get(i);
            int dy = layer.get(i);
            Scheduler.later(1 + (dy + 1) * 2, () -> {
                if (w.method_8320(bp).method_26215()) {
                    w.method_8501(bp, class_2246.field_23869.method_9564());
                    placed.add(bp);
                    w.method_65096(class_2398.field_22247, bp.method_10263() + 0.5, bp.method_10264() + 0.5, bp.method_10260() + 0.5, 3, 0.3, 0.3, 0.3, 0.02);
                }
            });
            Scheduler.later(200 + (radius - dy) * 2, () -> {
                if (placed.contains(bp) && w.method_8320(bp).method_27852(class_2246.field_23869)) {
                    w.method_8501(bp, class_2246.field_10124.method_9564());
                    w.method_65096(class_2398.field_11237, bp.method_10263() + 0.5, bp.method_10264() + 0.5, bp.method_10260() + 0.5, 4, 0.3, 0.3, 0.3, 0.03);
                }
            });
        }
        // kilau di permukaan kubah + cincin rune di tanah selama 10 detik
        for (int t = 0; t < 20; t++) {
            int tick = t;
            Scheduler.later(5 + t * 10, () -> {
                ThreadLocalRandom r = ThreadLocalRandom.current();
                for (int k = 0; k < 50; k++) {
                    double yaw = r.nextDouble() * Math.PI * 2;
                    double pitch = r.nextDouble() * Math.PI / 2;
                    double x = c.method_10263() + 0.5 + Math.cos(yaw) * Math.cos(pitch) * radius;
                    double y = c.method_10264() + Math.sin(pitch) * radius;
                    double z = c.method_10260() + 0.5 + Math.sin(yaw) * Math.cos(pitch) * radius;
                    w.method_65096(k % 3 == 0 ? class_2398.field_11207 : class_2398.field_22247, x, y, z, 1, 0, 0, 0, 0.01);
                }
                for (int k = 0; k < 36; k++) {
                    double a = k * Math.PI * 2 / 36 + tick * 0.2;
                    w.method_65096(class_2398.field_11207, c.method_10263() + 0.5 + Math.cos(a) * (radius - 1),
                            c.method_10264() + 0.1, c.method_10260() + 0.5 + Math.sin(a) * (radius - 1), 1, 0, 0, 0, 0);
                }
            });
        }
        Fx.give(p, class_1294.field_5924, 10, 1);
        Fx.give(p, class_1294.field_5907, 10, 1);
        w.method_8396(null, c, class_3417.field_14833, class_3419.field_15248, 2.0F, 0.5F);
    }

    public static void blackstoneGolems(class_3222 p, class_3218 w) {
        for (int i = 0; i < 2; i++) {
            Allies.spawn(w, p, class_1299.field_6147, 45);
        }
        w.method_65096(class_2398.field_11237, p.method_23317(), p.method_23318() + 1, p.method_23321(), 60, 3, 1, 3, 0.05);
        w.method_8396(null, p.method_24515(), class_3417.field_21077, class_3419.field_15248, 2.0F, 0.7F);
    }

    // ================================================================ ECHO STONE

    /** Sembunyikan dari mob selama beberapa tick (mob kehilangan target dan kabur). */
    public static void hide(class_3222 p, class_3218 w, int ticks) {
        STEALTH.put(p.method_5667(), w.method_75260() + ticks);
    }

    public static void echoTwins(class_3222 p, class_3218 w) {
        for (int i = 0; i < 2; i++) {
            Allies.spawnEcho(w, p, 30, 2.5);
        }
        w.method_65096(class_2398.field_11215, p.method_23317(), p.method_23318() + 1, p.method_23321(), 120, 2, 1, 2, 0.6);
        w.method_8396(null, p.method_24515(), class_3417.field_26980, class_3419.field_15248, 3.0F, 0.8F);
    }

    /** Banyak Echo muncul; kamu dan armormu menghilang selama 12 detik. */
    public static void echoLegion(class_3222 p, class_3218 w) {
        for (int i = 0; i < 12; i++) {
            Allies.spawnEcho(w, p, 12, 6.0);   // salin armor SEBELUM disembunyikan
        }
        hide(p, w, 240);
        Fx.give(p, class_1294.field_5905, 12, 0);
        hideArmor(p, 240);
        w.method_65096(class_2398.field_11215, p.method_23317(), p.method_23318() + 1, p.method_23321(), 200, 4, 1.5, 4, 0.8);
        w.method_8396(null, p.method_24515(), class_3417.field_43154, class_3419.field_15248, 3.0F, 0.6F);
    }

    private static void hideArmor(class_3222 p, int ticks) {
        if (STASH.containsKey(p.method_5667())) {
            return;
        }
        class_1799[] saved = new class_1799[4];
        for (int i = 0; i < 4; i++) {
            saved[i] = p.method_6118(ARMOR[i]).method_7972();
            p.method_5673(ARMOR[i], class_1799.field_8037);
        }
        STASH.put(p.method_5667(), saved);
        UUID id = p.method_5667();
        MinecraftServer server = p.method_51469().method_8503();
        Scheduler.later(ticks, () -> {
            class_3222 pl = server.method_3760().method_14602(id);
            if (pl != null) {
                restoreArmor(pl);
            }
        });
    }

    /** Kembalikan armor yang disembunyikan (juga dipanggil saat pemain keluar, mati, atau server berhenti). */
    public static void restoreArmor(class_3222 p) {
        class_1799[] saved = STASH.remove(p.method_5667());
        if (saved == null) {
            return;
        }
        for (int i = 0; i < 4; i++) {
            if (saved[i].method_7960()) {
                continue;
            }
            if (p.method_6118(ARMOR[i]).method_7960()) {
                p.method_5673(ARMOR[i], saved[i]);
            } else {
                p.method_31548().method_7398(saved[i]);
            }
        }
    }

    public static boolean hasStash(class_3222 p) {
        return STASH.containsKey(p.method_5667());
    }

    // ================================================================ MAGMA STONE

    public static boolean holdsStaff(class_3222 p) {
        return p.method_6047().method_31574(Stones.MAGMA_STAFF) || p.method_6079().method_31574(Stones.MAGMA_STAFF);
    }

    /** Small fireball buatan sendiri: terbang 2 blok per tick, damage 5 hati + terbakar. */
    public static void magmaFireball(class_3222 p, class_3218 w) {
        class_243 dir = p.method_5828(1.0F);
        fireballStep(p, w, Fx.eye(p).method_1019(dir), dir, 0);
        w.method_8396(null, p.method_24515(), class_3417.field_14970, class_3419.field_15248, 1.5F, 1.0F);
    }

    private static void fireballStep(class_3222 p, class_3218 w, class_243 pos, class_243 dir, int step) {
        if (step > 30) {
            return;
        }
        class_243 next = pos.method_1019(dir.method_1021(1.6));
        w.method_65096(class_2398.field_11240, next.field_1352, next.field_1351, next.field_1350, 8, 0.12, 0.12, 0.12, 0.02);
        w.method_65096(class_2398.field_11237, next.field_1352, next.field_1351, next.field_1350, 2, 0.1, 0.1, 0.1, 0.01);
        List<class_1309> hit = w.method_8390(class_1309.class, new class_238(next, next).method_1014(1.0),
                e -> e != p && e.method_5805() && !Allies.isAlly(e));
        boolean solid = !w.method_8320(class_2338.method_49638(next)).method_26215();
        if (!hit.isEmpty() || solid) {
            if (!hit.isEmpty()) {
                class_1309 e = hit.get(0);
                e.method_64397(w, w.method_48963().method_48802(p), 10.0F);
                e.method_5639(8);
            }
            w.method_65096(class_2398.field_11240, next.field_1352, next.field_1351, next.field_1350, 50, 0.5, 0.5, 0.5, 0.12);
            w.method_65096(class_2398.field_11239, next.field_1352, next.field_1351, next.field_1350, 15, 0.4, 0.4, 0.4, 0.1);
            return;
        }
        Scheduler.later(1, () -> fireballStep(p, w, next, dir, step + 1));
    }

    /** Pasif Magma Staff: makhluk dalam radius 7 block terbakar dan terluka. */
    public static void magmaAura(class_3222 p, class_3218 w) {
        for (class_1309 e : Fx.around(p, 7, false)) {
            e.method_5639(4);
            e.method_64397(w, w.method_48963().method_48794(), 4.0F);
        }
        for (int k = 0; k < 40; k++) {
            double a = k * Math.PI * 2 / 40;
            w.method_65096(class_2398.field_11240, p.method_23317() + Math.cos(a) * 7, p.method_23318() + 0.2, p.method_23321() + Math.sin(a) * 7, 1, 0, 0.1, 0, 0.02);
        }
    }

    // ================================================================ CORROSIVE STONE

    /** Setiap pukulan mengurangi durability armor dan senjata musuh sebanyak 20. */
    public static void corrode(class_1309 e) {
        class_1304[] slots = {class_1304.field_6173, class_1304.field_6171, class_1304.field_6169,
                class_1304.field_6174, class_1304.field_6172, class_1304.field_6166};
        for (class_1304 slot : slots) {
            class_1799 stack = e.method_6118(slot);
            if (!stack.method_7960() && stack.method_7963()) {
                int nd = stack.method_7919() + 20;
                if (nd >= stack.method_7936()) {
                    e.method_5673(slot, class_1799.field_8037);
                } else {
                    stack.method_7974(nd);
                }
            }
        }
    }

    // ================================================================ CORROSIVE STONE (Karat Total)

    private static final Map<UUID, class_1799> DISARMED = new HashMap<>();

    /** Senjata semua makhluk radius 12 hancur seketika selama 5 detik, lalu dikembalikan. */
    public static void disarm(class_3222 p, class_3218 w) {
        int count = 0;
        for (class_1309 e : Fx.around(p, 12, false)) {
            class_1799 hand = e.method_6047();
            if (hand.method_7960() || DISARMED.containsKey(e.method_5667())) {
                continue;
            }
            DISARMED.put(e.method_5667(), hand.method_7972());
            e.method_5673(class_1304.field_6173, class_1799.field_8037);
            w.method_65096(class_2398.field_11205, e.method_23317(), e.method_23318() + 1.2, e.method_23321(), 40, 0.4, 0.4, 0.4, 0.4);
            w.method_65096(class_2398.field_11237, e.method_23317(), e.method_23318() + 1.2, e.method_23321(), 10, 0.3, 0.3, 0.3, 0.05);
            UUID id = e.method_5667();
            Scheduler.later(100, () -> returnWeapon(w, id));
            count++;
        }
        w.method_8396(null, p.method_24515(), class_3417.field_14542, class_3419.field_15248, 2.0F, 0.7F);
        p.method_7353(class_2561.method_43470("Senjata " + count + " musuh hancur selama 5 detik"), true);
    }

    private static void returnWeapon(class_3218 w, UUID id) {
        class_1799 weapon = DISARMED.remove(id);
        if (weapon == null) {
            return;
        }
        class_1297 e = w.method_66347(id);
        if (e instanceof class_1309 le && le.method_5805()) {
            if (le.method_6047().method_7960()) {
                le.method_5673(class_1304.field_6173, weapon);
            } else if (le instanceof class_3222 sp) {
                sp.method_31548().method_7398(weapon);
            }
            w.method_65096(class_2398.field_11215, le.method_23317(), le.method_23318() + 1, le.method_23321(), 30, 0.4, 0.6, 0.4, 0.5);
        }
    }

    /** Kembalikan senjata pemain yang sedang "hancur" (keluar, mati, atau server berhenti). */
    public static void restoreWeapon(class_3222 p) {
        class_1799 weapon = DISARMED.remove(p.method_5667());
        if (weapon == null) {
            return;
        }
        if (p.method_6047().method_7960()) {
            p.method_5673(class_1304.field_6173, weapon);
        } else {
            p.method_31548().method_7398(weapon);
        }
    }

    // ================================================================ QUARTZ RADIANCE

    private static final Map<UUID, Long> LASER_UNTIL = new HashMap<>();

    /** Sinar laser putih yang bisa ditahan 10 detik: 5 hati damage tiap tick; kamu bersinar (Glowing). */
    public static void laser(class_3222 p, class_3218 w) {
        long token = w.method_75260() + 200;
        LASER_UNTIL.put(p.method_5667(), token);
        Fx.give(p, class_1294.field_5912, 10, 0);
        for (int t = 0; t < 200; t++) {
            int tick = t;
            Scheduler.later(1 + t, () -> laserTick(p, token, tick));
        }
    }

    private static void laserTick(class_3222 p, long token, int tick) {
        if (!p.method_5805() || LASER_UNTIL.getOrDefault(p.method_5667(), 0L) != token) {
            return;
        }
        if (!PowerStones.holds(p, Stones.QUARTZ_RADIANCE)) {
            LASER_UNTIL.remove(p.method_5667());
            p.method_7353(class_2561.method_43470("Laser berhenti (batu dilepas)."), true);
            return;
        }
        class_3218 w = p.method_51469();
        class_243 eye = Fx.eye(p);
        class_243 dir = p.method_5828(1.0F);
        class_239 hit = p.method_5745(30, 1.0F, false);
        double maxDist = hit.method_17783() == class_239.class_240.field_1333 ? 30.0 : hit.method_17784().method_1022(eye);
        class_243 end = eye.method_1019(dir.method_1021(maxDist));
        for (double d = 1.0; d <= maxDist; d += 0.35) {
            class_243 pt = eye.method_1019(dir.method_1021(d));
            w.method_65096(class_2398.field_11207, pt.field_1352, pt.field_1351 - 0.2, pt.field_1350, 1, 0.02, 0.02, 0.02, 0.0);
        }
        w.method_65096(class_2398.field_29644, end.field_1352, end.field_1351, end.field_1350, 6, 0.3, 0.3, 0.3, 0.1);
        for (class_1309 e : w.method_8390(class_1309.class, new class_238(eye, end).method_1014(1.2),
                x -> x != p && x.method_5805() && !Allies.isAlly(x))) {
            class_243 c = new class_243(e.method_23317(), e.method_23323(0.5), e.method_23321());
            double t = c.method_1020(eye).method_1026(dir);
            if (t >= 0 && t <= maxDist && eye.method_1019(dir.method_1021(t)).method_1022(c) <= 1.3) {
                e.method_64397(w, w.method_48963().method_48802(p), 10.0F);
                w.method_65096(class_2398.field_11207, e.method_23317(), e.method_23323(0.5), e.method_23321(), 25, 0.3, 0.4, 0.3, 0.15);
            }
        }
        w.method_65096(class_2398.field_11207, end.field_1352, end.field_1351, end.field_1350, 30, 0.4, 0.4, 0.4, 0.2);
        w.method_8396(null, p.method_24515(), class_3417.field_38830, class_3419.field_15248, 1.0F, 2.0F);
    }
    // ================================================================ BLOOD STONE

    private record Link(UUID target, long until) {}

    private static final Map<UUID, Link> BLOOD_LINK = new HashMap<>();

    /** Korbankan 4 hati untuk Strength III + Speed II. */
    public static void bloodSacrifice(class_3222 p, class_3218 w) {
        if (p.method_6032() <= 10.0F) {
            p.method_7353(class_2561.method_43470("Darahmu terlalu sedikit untuk tumbal (butuh lebih dari 5 hati)."), true);
            return;
        }
        p.method_6033(p.method_6032() - 8.0F);
        Fx.give(p, class_1294.field_5910, 12, 2);
        Fx.give(p, class_1294.field_5904, 12, 1);
        w.method_65096(class_2398.field_11209, p.method_23317(), p.method_23318() + 1, p.method_23321(), 40, 0.5, 0.8, 0.5, 0.2);
        w.method_65096(class_2398.field_22248, p.method_23317(), p.method_23318() + 1, p.method_23321(), 80, 1.0, 1.0, 1.0, 0.1);
    }

    /** Tandai musuh: 50% damage yang kamu terima selama 10 detik pindah ke dia. */
    public static void bloodLink(class_3222 p, class_3218 w) {
        class_1309 t = Fx.target(p, 20);
        if (t == null) {
            p.method_7353(class_2561.method_43470("Tidak ada musuh yang dibidik (maks 20 block)."), true);
            return;
        }
        BLOOD_LINK.put(p.method_5667(), new Link(t.method_5667(), w.method_75260() + 200));
        Fx.give(t, class_1294.field_5912, 10, 0);
        class_243 from = Fx.eye(p);
        class_243 to = new class_243(t.method_23317(), t.method_23323(0.5), t.method_23321());
        for (int i = 0; i <= 20; i++) {
            class_243 pt = from.method_1019(to.method_1020(from).method_1021(i / 20.0));
            w.method_65096(class_2398.field_22248, pt.field_1352, pt.field_1351, pt.field_1350, 3, 0.05, 0.05, 0.05, 0.0);
        }
        p.method_7353(class_2561.method_43470("Rantai Darah terpasang (10 detik)"), true);
    }

    /** Dipanggil saat pemain terluka: 50% damage dipindahkan ke musuh yang ditandai. */
    public static void bloodLinkReflect(class_3222 p, float amount) {
        Link link = BLOOD_LINK.get(p.method_5667());
        if (link == null) {
            return;
        }
        class_3218 w = p.method_51469();
        if (w.method_75260() >= link.until()) {
            BLOOD_LINK.remove(p.method_5667());
            return;
        }
        if (w.method_66347(link.target()) instanceof class_1309 t && t.method_5805()) {
            t.method_64397(w, w.method_48963().method_48831(), amount * 0.5F);
            Scheduler.later(1, () -> p.method_6025(amount * 0.5F));
            w.method_65096(class_2398.field_11209, t.method_23317(), t.method_23323(0.5), t.method_23321(), 10, 0.3, 0.3, 0.3, 0.1);
        }
    }

    /** 10 detik: tiap detik musuh radius 8 kehilangan 1 hati dan kamu sembuh. */
    public static void bloodFeast(class_3222 p, class_3218 w) {
        for (int sec = 1; sec <= 10; sec++) {
            Scheduler.later(sec * 20, () -> {
                if (!p.method_5805()) {
                    return;
                }
                class_3218 pw = p.method_51469();
                float healed = 0.0F;
                for (class_1309 e : Fx.around(p, 8, false)) {
                    e.method_64397(pw, pw.method_48963().method_48831(), 2.0F);
                    healed += 2.0F;
                    pw.method_65096(class_2398.field_11209, e.method_23317(), e.method_23323(0.5), e.method_23321(), 6, 0.3, 0.4, 0.3, 0.1);
                }
                p.method_6025(Math.min(healed, 8.0F));
                for (int k = 0; k < 36; k++) {
                    double a = k * Math.PI * 2 / 36;
                    pw.method_65096(class_2398.field_22248, p.method_23317() + Math.cos(a) * 8, p.method_23318() + 0.3,
                            p.method_23321() + Math.sin(a) * 8, 1, 0, 0.2, 0, 0.02);
                }
                pw.method_65096(class_2398.field_11201, p.method_23317(), p.method_23318() + 1.5, p.method_23321(), 6, 0.5, 0.4, 0.5, 0.0);
            });
        }
        w.method_8396(null, p.method_24515(), class_3417.field_38068, class_3419.field_15248, 3.0F, 0.5F);
    }
}
