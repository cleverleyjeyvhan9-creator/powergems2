package com.powerstones;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

import com.mojang.serialization.Codec;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.attachment.v1.AttachmentRegistry;
import net.fabricmc.fabric.api.attachment.v1.AttachmentType;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.component.ComponentType;
import net.minecraft.entity.Entity;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.ai.brain.MemoryModuleType;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.mob.PiglinBruteEntity;
import net.minecraft.entity.mob.PiglinEntity;
import net.minecraft.entity.projectile.ProjectileEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;

public class PowerStones implements ModInitializer {

    public static final String MOD_ID = "powerstones";

    /** Progres kill True Stone: permanen di pemain (tetap ada walau item hilang / pemain mati). */
    public static final AttachmentType<Integer> TRUE_KILLS = AttachmentRegistry.create(
            Identifier.of(MOD_ID, "true_kills"),
            builder -> builder.initializer(() -> 0).persistent(Codec.INT).copyOnDeath());

    public static final int SKILL_2_KILLS = 25;
    public static final int SKILL_3_KILLS = 100;

    /** Jumlah kill yang ditempel di item True Stone supaya tampil di tooltip. */
    public static final ComponentType<Integer> KILLS_COMPONENT = Registry.register(
            Registries.DATA_COMPONENT_TYPE, Identifier.of(MOD_ID, "kills"),
            ComponentType.<Integer>builder().codec(Codec.INT).packetCodec(PacketCodecs.VAR_INT).build());

    /** Isi Stone Holder: id batu dipisah koma, dan indeks batu yang dipilih. */
    public static final ComponentType<String> HOLDER_STONES = Registry.register(
            Registries.DATA_COMPONENT_TYPE, Identifier.of(MOD_ID, "holder_stones"),
            ComponentType.<String>builder().codec(Codec.STRING).packetCodec(PacketCodecs.STRING).build());
    public static final ComponentType<Integer> HOLDER_SEL = Registry.register(
            Registries.DATA_COMPONENT_TYPE, Identifier.of(MOD_ID, "holder_sel"),
            ComponentType.<Integer>builder().codec(Codec.INT).packetCodec(PacketCodecs.VAR_INT).build());

    // Waktu dunia (tick). Cooldown tetap berjalan walau batu tidak dipegang.
    private static final Map<UUID, Long> surgeUntil = new HashMap<>();
    private static final Map<UUID, Long> surgeReady = new HashMap<>();
    private static final Map<UUID, Long> untouchableUntil = new HashMap<>();
    private static final Map<UUID, Long> untouchableReady = new HashMap<>();
    private static final Map<UUID, Long> eraseReady = new HashMap<>();
    private static final Set<UUID> flyers = new HashSet<>();

    @Override
    public void onInitialize() {
        Stones.register();
        registerCreativeTab();
        Inputs.register();

        ServerTickEvents.END_SERVER_TICK.register(PowerStones::onTick);

        // armor yang disembunyikan Echo Stone tidak boleh hilang
        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {
            Skills.restoreArmor(handler.getPlayer());
            Skills.restoreWeapon(handler.getPlayer());
        });
        ServerLifecycleEvents.SERVER_STOPPING.register(server -> {
            for (ServerPlayerEntity pl : server.getPlayerManager().getPlayerList()) {
                Skills.restoreArmor(pl);
                Skills.restoreWeapon(pl);
            }
        });

        ServerLivingEntityEvents.ALLOW_DAMAGE.register((entity, source, amount) -> {
            // sekutu tidak melukai pemiliknya maupun sesama sekutu (termasuk lewat panah / ledakan)
            Entity attacker = source.getAttacker();
            Entity direct = source.getSource();
            Entity allyEntity = null;
            if (attacker != null && Allies.isAlly(attacker)) {
                allyEntity = attacker;
            } else if (direct != null && Allies.isAlly(direct)) {
                allyEntity = direct;
            } else if (direct instanceof ProjectileEntity pr && pr.getOwner() != null && Allies.isAlly(pr.getOwner())) {
                allyEntity = pr.getOwner();
            }
            if (allyEntity != null) {
                UUID owner = Allies.ownerOf(allyEntity);
                if (entity instanceof ServerPlayerEntity pl && pl.getUuid().equals(owner)) {
                    return false;
                }
                if (Allies.isAlly(entity)) {
                    return false;
                }
            }

            // Ice Dagger: pukulan membekukan; Corrosive Stone: pukulan mengikis durability
            if (attacker instanceof ServerPlayerEntity ap && entity != ap) {
                if (ap.getMainHandStack().isOf(Stones.ICE_DAGGER)) {
                    entity.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 80, 2));
                    entity.setFrozenTicks(160);
                }
                if (holds(ap, Stones.CORROSIVE_STONE)) {
                    Skills.corrode(entity);
                }
            }

            // Magma Stone / Magma Staff: setiap pukulan dan panah membakar musuh
            if (attacker instanceof ServerPlayerEntity fa && entity != fa
                    && (holds(fa, Stones.MAGMA_STONE) || fa.getMainHandStack().isOf(Stones.MAGMA_STAFF))) {
                entity.setOnFireFor(5);
            }
            // Blood Stone: tiap pukulan menyembuhkan 1 hati
            if (attacker instanceof ServerPlayerEntity ba && entity != ba && holds(ba, Stones.BLOOD_STONE)) {
                ba.heal(2.0F);
            }
            // Blood Stone: Rantai Darah memindahkan 50% damage ke musuh yang ditandai
            if (entity instanceof ServerPlayerEntity lp) {
                Skills.bloodLinkReflect(lp, amount);
            }

            // Gold Stone: Piglin tidak bisa melukai pemegangnya
            if (entity instanceof ServerPlayerEntity gp && holds(gp, Stones.GOLD_STONE)
                    && (attacker instanceof PiglinEntity || attacker instanceof PiglinBruteEntity)) {
                return false;
            }

            // True Stone skill 2: Untouchable (2 detik tak bisa disentuh, cooldown 20 detik)
            if (!(entity instanceof ServerPlayerEntity p) || !holds(p, Stones.TRUE_STONE)) {
                return true;
            }
            if (p.getAttachedOrElse(TRUE_KILLS, 0) < SKILL_2_KILLS) {
                return true;
            }
            UUID id = p.getUuid();
            long now = p.getEntityWorld().getTime();
            if (now < untouchableUntil.getOrDefault(id, 0L)) {
                return false;
            }
            if (now >= untouchableReady.getOrDefault(id, 0L)) {
                untouchableUntil.put(id, now + 40);
                untouchableReady.put(id, now + 400);
                p.sendMessage(Text.literal("Untouchable!"), true);
                return false;
            }
            return true;
        });

        ServerLivingEntityEvents.ALLOW_DEATH.register((entity, source, amount) -> {
            // sekutu yang mati lenyap tanpa drop dan XP (mencegah duplikasi item)
            if (Allies.isAlly(entity)) {
                entity.discard();
                return false;
            }
            // pemain mati saat armornya disembunyikan Echo Stone: kembalikan dulu
            if (entity instanceof ServerPlayerEntity dyingW) {
                Skills.restoreWeapon(dyingW);
            }
            if (entity instanceof ServerPlayerEntity dying && Skills.hasStash(dying)) {
                Skills.restoreArmor(dying);
            }
            if (!(source.getAttacker() instanceof ServerPlayerEntity p)) {
                return true;
            }

            // True Stone fase 2: membunuh pemain = 1 armor netherite
            if (entity instanceof ServerPlayerEntity && holds(p, Stones.TRUE_STONE)) {
                grantNetherite(p);
                return true;
            }
            if (!(entity instanceof MobEntity)) {
                return true;
            }

            // Summoner Stone: catat mob yang dibunuh
            if (holds(p, Stones.SUMMONER_STONE)) {
                Allies.recordKill(p, (net.minecraft.entity.LivingEntity) entity);
            }

            if (!holds(p, Stones.TRUE_STONE)) {
                return true;
            }
            int kills = p.getAttachedOrElse(TRUE_KILLS, 0) + 1;
            p.setAttached(TRUE_KILLS, kills);
            syncKills(p, kills);
            if (kills == SKILL_2_KILLS) {
                p.sendMessage(Text.literal("True Stone: skill Untouchable terbuka!"), false);
            } else if (kills == SKILL_3_KILLS) {
                p.sendMessage(Text.literal("True Stone: skill Erase Existence terbuka! (level max)"), false);
            }
            UUID id = p.getUuid();
            long now = p.getEntityWorld().getTime();
            if (kills >= SKILL_3_KILLS && now >= eraseReady.getOrDefault(id, 0L)) {
                eraseReady.put(id, now + 6000);
                entity.discard(); // hilang tanpa mayat, drop, atau XP
                p.sendMessage(Text.literal("Erase Existence!"), true);
                return false;
            }
            return true;
        });

        // Lapis Mind - Fortune Surge: drop yang muncul di dekat pemain digandakan selama 15 detik
        ServerEntityEvents.ENTITY_LOAD.register((entity, world) -> {
            if (entity instanceof ItemEntity bladeDrop && (bladeDrop.getStack().isOf(Stones.TRUE_BLADE) || bladeDrop.getStack().isOf(Stones.ICE_DAGGER)
                    || bladeDrop.getStack().isOf(Stones.MAGMA_STAFF))) {
                world.getServer().execute(bladeDrop::discard);
                return;
            }
            if (!(entity instanceof ItemEntity item) || item.getItemAge() > 1
                    || item.getCommandTags().contains("ps_dup")) {
                return;
            }
            long now = world.getTime();
            for (ServerPlayerEntity p : world.getPlayers()) {
                Long until = surgeUntil.get(p.getUuid());
                if (until == null || now >= until || !holds(p, Stones.LAPIS_MIND)) {
                    continue;
                }
                double d = item.squaredDistanceTo(p);
                // > 1.5 block dari pemain: abaikan item yang dibuang pemain sendiri
                if (d > 2.25 && d < 64.0) {
                    ItemEntity dup = new ItemEntity(world, item.getX(), item.getY(), item.getZ(),
                            item.getStack().copy());
                    dup.addCommandTag("ps_dup");
                    world.getServer().execute(() -> world.spawnEntity(dup));
                    return;
                }
            }
        });
    }

    /** Batu yang sedang aktif: dipegang, terpilih di Stone Holder yang dipegang, atau dipakai di chestplate. */
    public static List<StoneItem> effective(ServerPlayerEntity p) {
        List<StoneItem> out = new ArrayList<>();
        for (ItemStack s : List.of(p.getMainHandStack(), p.getOffHandStack())) {
            if (s.getItem() instanceof StoneItem st) {
                out.add(st);
            } else if (s.getItem() instanceof StoneHolderItem) {
                StoneItem sel = StoneHolderItem.selectedStone(s);
                if (sel != null) {
                    out.add(sel);
                }
            }
        }
        if (p.getEquippedStack(EquipmentSlot.CHEST).getItem() instanceof StoneItem st) {
            out.add(st);
        }
        // memegang senjata hasil batu = memegang batunya
        Item main = p.getMainHandStack().getItem();
        if (main == Stones.TRUE_BLADE) {
            out.add(Stones.TRUE_STONE);
        } else if (main == Stones.ICE_DAGGER) {
            out.add(Stones.ICE_STONE);
        } else if (main == Stones.MAGMA_STAFF) {
            out.add(Stones.MAGMA_STONE);
        }
        return out;
    }

    public static boolean holds(ServerPlayerEntity p, Item item) {
        for (StoneItem st : effective(p)) {
            if (st == item) {
                return true;
            }
        }
        return false;
    }

    private static void onTick(MinecraftServer server) {
        Scheduler.tick();
        Skills.magnetTick(server);
        int t = server.getTicks();
        if (t % 2 == 0) {
            Allies.tick(server);
        }
        if (t % 5 == 0) {
            extraItemsTick(server);
            Skills.stealthTick(server);
            piglinTick(server);
        }
        if (t % 20 != 0) {
            return;
        }
        for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
            secondly(p);
        }
    }

    /** Gold Stone: Piglin di sekitar pemegangnya melupakan targetnya (tidak akan menyerang). */
    private static void piglinTick(MinecraftServer server) {
        for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
            if (!holds(p, Stones.GOLD_STONE)) {
                continue;
            }
            for (MobEntity m : p.getEntityWorld().getEntitiesByClass(MobEntity.class, p.getBoundingBox().expand(24),
                    x -> x instanceof PiglinEntity || x instanceof PiglinBruteEntity)) {
                if (m.getTarget() == p) {
                    m.setTarget(null);
                }
                m.getBrain().forget(MemoryModuleType.ATTACK_TARGET);
                m.getBrain().forget(MemoryModuleType.ANGRY_AT);
            }
        }
    }

    private static boolean offhandHas(ServerPlayerEntity p, StoneItem stone) {
        ItemStack off = p.getOffHandStack();
        if (off.isOf(stone)) {
            return true;
        }
        return off.getItem() instanceof StoneHolderItem && StoneHolderItem.selectedStone(off) == stone;
    }

    private static void syncItem(ServerPlayerEntity p, Item item, boolean want, boolean give, String message) {
        var inv = p.getInventory();
        boolean has = false;
        for (int i = 0; i < inv.size(); i++) {
            ItemStack s = inv.getStack(i);
            if (s.isOf(item)) {
                if (want && !has) {
                    has = true;
                } else {
                    inv.setStack(i, ItemStack.EMPTY);
                }
            }
        }
        if (want && !has && give && (p.getMainHandStack().isEmpty() || p.getInventory().getEmptySlot() >= 0)) {
            ItemStack made = new ItemStack(item);
            if (p.getMainHandStack().isEmpty()) {
                p.setStackInHand(Hand.MAIN_HAND, made);
            } else {
                p.getInventory().offerOrDrop(made);
            }
            ServerWorld w = p.getEntityWorld();
            Fx.skillFx(w, p, ParticleTypes.SNOWFLAKE, ParticleTypes.END_ROD, 2);
            w.playSound(null, p.getBlockPos(), SoundEvents.ENTITY_EVOKER_CAST_SPELL, SoundCategory.PLAYERS, 1.0F, 1.5F);
            p.sendMessage(Text.literal(message), true);
        }
    }

    /** Apakah pemain membawa batu ini di inventory (atau di dalam Stone Holder)? */
    public static boolean carries(ServerPlayerEntity p, StoneItem stone) {
        var inv = p.getInventory();
        for (int i = 0; i < inv.size(); i++) {
            ItemStack s = inv.getStack(i);
            if (s.isOf(stone)) {
                return true;
            }
            if (s.getItem() instanceof StoneHolderItem && StoneHolderItem.stones(s).contains(stone)) {
                return true;
            }
        }
        return false;
    }

    /** True Blade, Ice Dagger, dan Magma Staff muncul otomatis selama batunya dibawa; tak bisa dibuang. */
    private static void extraItemsTick(MinecraftServer server) {
        for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
            syncItem(p, Stones.TRUE_BLADE, carries(p, Stones.TRUE_STONE), true, "True Blade muncul!");
            syncItem(p, Stones.ICE_DAGGER, carries(p, Stones.ICE_STONE), true, "Ice Dagger muncul!");
            syncItem(p, Stones.MAGMA_STAFF, carries(p, Stones.MAGMA_STONE), true, "Magma Staff muncul!");
        }
    }

    private static void secondly(ServerPlayerEntity p) {
        ServerWorld w = p.getEntityWorld();
        long now = w.getTime();
        UUID id = p.getUuid();
        List<StoneItem> active = effective(p);

        // Efek hanya aktif selama batu aktif
        for (StoneItem stone : new HashSet<>(active)) {
            for (StatusEffectInstance e : stone.def.passives) {
                p.addStatusEffect(new StatusEffectInstance(e));
            }
            if (stone.def.tickSkill != null) {
                stone.def.tickSkill.run(p, w);
            }
            for (int k = 0; k < 14; k++) {
                double a = k * Math.PI * 2 / 14;
                w.spawnParticles(stone.def.aura, p.getX() + Math.cos(a) * 0.9, p.getY() + 0.1 + k * 0.12,
                        p.getZ() + Math.sin(a) * 0.9, 1, 0, 0, 0, 0.0);
            }
            w.spawnParticles(stone.def.fx, p.getX(), p.getY() + 2.1, p.getZ(), 4, 0.3, 0.2, 0.3, 0.02);
        }

        // Galaxy Stone: terbang seperti creative selama dipegang
        if (active.contains(Stones.GALAXY_STONE)) {
            if (!p.getAbilities().allowFlying) {
                p.getAbilities().allowFlying = true;
                p.sendAbilitiesUpdate();
                flyers.add(id);
            }
        } else if (flyers.remove(id)) {
            if (!p.isCreative() && !p.isSpectator()) {
                p.getAbilities().allowFlying = false;
                p.getAbilities().flying = false;
                p.sendAbilitiesUpdate();
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOW_FALLING, 160, 0));
            }
        }

        // Emerald Pulse: Hero of the Village V permanen selama batu ada di inventory
        if (carries(p, Stones.EMERALD_PULSE)) {
            p.addStatusEffect(new StatusEffectInstance(StatusEffects.HERO_OF_THE_VILLAGE, 600, 4, true, false, true));
        }

        // Corrosive Stone: Wither pelan, berhenti sebelum mati
        if (active.contains(Stones.CORROSIVE_STONE)) {
            p.addStatusEffect(new StatusEffectInstance(StatusEffects.WITHER, 100, 0, true, true, true));
            if (p.getHealth() <= 8.0F) {
                p.removeStatusEffect(StatusEffects.WITHER);
            }
        }

        // Obsidian Veil: darah acak (20 / 15 / 13 hati, kadang hanya 5 hati) setiap dipegang
        EntityAttributeInstance hp = p.getAttributeInstance(EntityAttributes.MAX_HEALTH);
        Identifier hpId = Identifier.of(MOD_ID, "obsidian_veil_health");
        if (hp != null) {
            boolean has = active.contains(Stones.OBSIDIAN_VEIL);
            if (has && !hp.hasModifier(hpId)) {
                double[] pool = {20.0, 20.0, 10.0, 10.0, 10.0, 6.0, 6.0, 6.0, -10.0, -10.0};
                double bonus = pool[ThreadLocalRandom.current().nextInt(pool.length)];
                hp.addTemporaryModifier(new EntityAttributeModifier(hpId, bonus, EntityAttributeModifier.Operation.ADD_VALUE));
                if (bonus > 0) {
                    p.setHealth(p.getHealth() + (float) bonus);
                }
                p.sendMessage(Text.literal("Obsidian Veil: darahmu menjadi " + (int) ((20.0 + bonus) / 2) + " hati"), true);
            } else if (!has && hp.hasModifier(hpId)) {
                hp.removeModifier(hpId);
                if (p.getHealth() > p.getMaxHealth()) {
                    p.setHealth(p.getMaxHealth());
                }
            }
        }

        // Obsidian Veil: darah berkurang 0,5 hati tiap detik (berhenti di 2 hati)
        if (active.contains(Stones.OBSIDIAN_VEIL) && p.getHealth() > 4.0F) {
            p.setHealth(p.getHealth() - 1.0F);
        }

        // Magma Staff: aura api radius 7
        if (Skills.holdsStaff(p)) {
            Skills.magmaAura(p, w);
        }

        // Salin progres kill ke item True Stone + perbarui tampilan Stone Holder
        syncKills(p, p.getAttachedOrElse(TRUE_KILLS, 0));
        var inv = p.getInventory();
        for (int i = 0; i < inv.size(); i++) {
            ItemStack s = inv.getStack(i);
            if (s.getItem() instanceof StoneHolderItem) {
                StoneHolderItem.refreshModel(s);
            }
        }

        // Lapis Mind - Fortune Surge: aktif 15 detik, lalu cooldown 4 menit
        if (active.contains(Stones.LAPIS_MIND) && now >= surgeReady.getOrDefault(id, 0L)) {
            surgeUntil.put(id, now + 300);
            surgeReady.put(id, now + 4800);
            p.addStatusEffect(new StatusEffectInstance(StatusEffects.LUCK, 300, 2));
            p.addStatusEffect(new StatusEffectInstance(StatusEffects.HASTE, 300, 1));
            w.spawnParticles(ParticleTypes.ENCHANT, p.getX(), p.getY() + 1.0, p.getZ(), 80, 0.8, 1.0, 0.8, 0.5);
            p.sendMessage(Text.literal("Fortune Surge aktif! (15 detik)"), true);
        }
    }

    private static void grantNetherite(ServerPlayerEntity p) {
        EquipmentSlot[] slots = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
        Item[] pieces = {Items.NETHERITE_HELMET, Items.NETHERITE_CHESTPLATE, Items.NETHERITE_LEGGINGS, Items.NETHERITE_BOOTS};
        for (int i = 0; i < slots.length; i++) {
            ItemStack current = p.getEquippedStack(slots[i]);
            if (!current.isOf(pieces[i])) {
                ItemStack old = current.copy();
                p.equipStack(slots[i], new ItemStack(pieces[i]));
                if (!old.isEmpty()) {
                    p.getInventory().offerOrDrop(old);
                }
                p.sendMessage(Text.literal("True Stone merampas sebuah armor netherite!"), true);
                return;
            }
        }
    }

    private static void syncKills(ServerPlayerEntity p, int kills) {
        var inv = p.getInventory();
        for (int i = 0; i < inv.size(); i++) {
            ItemStack s = inv.getStack(i);
            if (s.isOf(Stones.TRUE_STONE) && s.getOrDefault(KILLS_COMPONENT, 0) != kills) {
                s.set(KILLS_COMPONENT, kills);
            }
        }
    }

    private static void registerCreativeTab() {
        RegistryKey<ItemGroup> key = RegistryKey.of(RegistryKeys.ITEM_GROUP, Identifier.of(MOD_ID, "main"));
        Registry.register(Registries.ITEM_GROUP, key, FabricItemGroup.builder()
                .icon(() -> new ItemStack(Stones.GALAXY_STONE))
                .displayName(Text.translatable("itemGroup.powerstones.main"))
                .entries((context, entries) -> Stones.TAB.forEach(entries::add))
                .build());
    }
}
