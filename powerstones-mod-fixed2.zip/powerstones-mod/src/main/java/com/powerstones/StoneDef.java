package com.powerstones;

import java.util.ArrayList;
import java.util.List;

import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;

/** Deskripsi satu power stone: deskripsi, efek pasif, dan sampai 3 skill (klik kanan / jongkok / offhand). */
public final class StoneDef {

    @FunctionalInterface
    public interface Skill {
        void run(ServerPlayerEntity player, ServerWorld world);
    }

    public enum Use {
        PASSIVE("Pasif"),
        RIGHT("Klik kanan"),
        SNEAK("Jongkok + klik kanan"),
        OFFHAND("Offhand + klik kanan");

        public final String label;

        Use(String label) {
            this.label = label;
        }
    }

    public record Power(Use use, String name, String text, int cooldownSeconds) {}

    public final String id;
    public String description = "";
    public final List<StatusEffectInstance> passives = new ArrayList<>();
    public final List<Power> powers = new ArrayList<>();
    public final Skill[] skills = new Skill[3];   // 0 = klik kanan, 1 = jongkok, 2 = offhand
    public final int[] cooldowns = new int[3];
    public Skill tickSkill;                       // dijalankan tiap 1 detik selama aktif
    public boolean sword;                         // item berperilaku seperti pedang
    public boolean chestplate;                    // item bisa dipakai di slot chestplate
    public ParticleEffect aura = ParticleTypes.ENCHANT;
    public int style;                                   // gaya efek visual skill (0-5)
    public ParticleEffect fx = ParticleTypes.END_ROD;   // partikel kedua untuk efek skill

    public StoneDef(String id) {
        this.id = id;
    }

    public StoneDef desc(String description) {
        this.description = description;
        return this;
    }

    public StoneDef passive(RegistryEntry<StatusEffect> effect, int amplifier) {
        passives.add(new StatusEffectInstance(effect, 100, amplifier, true, false, true));
        return this;
    }

    /** Skill aktif. use harus RIGHT, SNEAK, atau OFFHAND. */
    public StoneDef power(Use use, String name, int cooldownSeconds, String text, Skill skill) {
        int idx = use == Use.RIGHT ? 0 : use == Use.SNEAK ? 1 : 2;
        skills[idx] = skill;
        cooldowns[idx] = cooldownSeconds;
        powers.add(new Power(use, name, text, cooldownSeconds));
        return this;
    }

    /** Baris informasi tanpa skill (misalnya kemampuan pasif khusus). */
    public StoneDef info(Use use, String name, String text) {
        powers.add(new Power(use, name, text, 0));
        return this;
    }

    public StoneDef tick(Skill skill) {
        this.tickSkill = skill;
        return this;
    }

    public StoneDef aura(ParticleEffect aura) {
        this.aura = aura;
        return this;
    }

    public StoneDef style(int style) {
        this.style = style;
        return this;
    }

    public StoneDef fx(ParticleEffect fx) {
        this.fx = fx;
        return this;
    }

    public StoneDef sword() {
        this.sword = true;
        return this;
    }

    public StoneDef chestplate() {
        this.chestplate = true;
        return this;
    }
}
