package com.powerstones;

import java.util.List;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Vec3d;

/** Fungsi bantu yang dipakai banyak skill. */
public final class Fx {

    private Fx() {}

    public static Vec3d eye(ServerPlayerEntity p) {
        return new Vec3d(p.getX(), p.getEyeY(), p.getZ());
    }

    public static void give(LivingEntity e, RegistryEntry<StatusEffect> effect, int seconds, int amplifier) {
        e.addStatusEffect(new StatusEffectInstance(effect, seconds * 20, amplifier));
    }

    /** Makhluk hidup di sekitar pemain (sekutu pemain tidak ikut). */
    public static List<LivingEntity> around(ServerPlayerEntity p, double r, boolean hostileOnly) {
        ServerWorld w = p.getEntityWorld();
        return w.getEntitiesByClass(LivingEntity.class, p.getBoundingBox().expand(r),
                e -> e != p && e.isAlive() && e.squaredDistanceTo(p) <= r * r
                        && !Allies.isAlly(e)
                        && (!hostileOnly || e instanceof HostileEntity));
    }

    /** strength > 0 = tarik mendekat ke pemain, strength < 0 = dorong menjauh. */
    public static void push(LivingEntity e, ServerPlayerEntity p, double strength, double lift) {
        Vec3d away = new Vec3d(e.getX() - p.getX(), 0, e.getZ() - p.getZ());
        if (away.lengthSquared() < 1.0E-4) {
            return;
        }
        Vec3d v = away.normalize().multiply(-strength);
        e.addVelocity(v.x, lift, v.z);
    }

    /** Makhluk yang paling pas dengan arah pandangan pemain. */
    public static LivingEntity target(ServerPlayerEntity p, double range) {
        Vec3d look = p.getRotationVec(1.0F);
        Vec3d eye = eye(p);
        LivingEntity best = null;
        double bestDot = 0.95;
        for (LivingEntity e : around(p, range, false)) {
            Vec3d to = new Vec3d(e.getX() - eye.x, e.getBodyY(0.5) - eye.y, e.getZ() - eye.z).normalize();
            double dot = look.dotProduct(to);
            if (dot > bestDot) {
                bestDot = dot;
                best = e;
            }
        }
        return best;
    }

    /** Efek visual skill. style: 0 cincin, 1 helix, 2 bintang sihir, 3 pilar, 4 pusaran, 5 gelombang kejut. */
    public static void skillFx(ServerWorld w, ServerPlayerEntity p, ParticleEffect main, ParticleEffect second, int style) {
        w.spawnParticles(main, p.getX(), p.getY() + 1.0, p.getZ(), 80, 0.8, 1.0, 0.8, 0.15);
        switch (style) {
            case 1 -> helix(w, p, main, second);
            case 2 -> star(w, p, main, second);
            case 3 -> pillar(w, p, main, second);
            case 4 -> vortex(w, p, main, second);
            case 5 -> shockwave(w, p, main, second);
            default -> rings(w, p, main, second);
        }
    }

    private static void ring(ServerWorld w, ParticleEffect e, double cx, double y, double cz, double r, int n) {
        for (int k = 0; k < n; k++) {
            double a = k * Math.PI * 2 / n;
            w.spawnParticles(e, cx + Math.cos(a) * r, y, cz + Math.sin(a) * r, 1, 0, 0.05, 0, 0.01);
        }
    }

    private static void rings(ServerWorld w, ServerPlayerEntity p, ParticleEffect main, ParticleEffect second) {
        for (int i = 0; i < 7; i++) {
            double r = 1.0 + i * 1.1;
            Scheduler.later(1 + i * 2, () -> ring(w, main, p.getX(), p.getY() + 0.2, p.getZ(), r, 30));
        }
        for (int t = 0; t < 20; t++) {
            int tick = t;
            Scheduler.later(1 + t, () -> {
                for (int arm = 0; arm < 2; arm++) {
                    double a = tick * 0.5 + arm * Math.PI;
                    w.spawnParticles(second, p.getX() + Math.cos(a) * 1.2, p.getY() + tick * 0.1,
                            p.getZ() + Math.sin(a) * 1.2, 2, 0, 0, 0, 0.01);
                }
            });
        }
        w.spawnParticles(second, p.getX(), p.getY() + 2.2, p.getZ(), 50, 0.5, 0.4, 0.5, 0.15);
    }

    private static void helix(ServerWorld w, ServerPlayerEntity p, ParticleEffect main, ParticleEffect second) {
        for (int t = 0; t < 36; t++) {
            int tick = t;
            Scheduler.later(1 + t, () -> {
                double y = p.getY() + tick * 0.09;
                for (int k = 0; k < 3; k++) {
                    double a = tick * 0.45 + k * Math.PI * 2 / 3;
                    w.spawnParticles(main, p.getX() + Math.cos(a) * 1.4, y, p.getZ() + Math.sin(a) * 1.4, 2, 0, 0, 0, 0.0);
                }
                if (tick % 3 == 0) {
                    w.spawnParticles(second, p.getX(), y + 0.3, p.getZ(), 4, 0.2, 0.1, 0.2, 0.03);
                }
            });
        }
        Scheduler.later(37, () -> w.spawnParticles(second, p.getX(), p.getY() + 3.4, p.getZ(), 80, 0.8, 0.5, 0.8, 0.2));
        ring(w, main, p.getX(), p.getY() + 0.2, p.getZ(), 1.6, 24);
    }

    private static void star(ServerWorld w, ServerPlayerEntity p, ParticleEffect main, ParticleEffect second) {
        double cx = p.getX();
        double cz = p.getZ();
        double y = p.getY() + 0.15;
        for (int t = 0; t < 22; t++) {
            int tick = t;
            Scheduler.later(1 + t, () -> {
                double base = tick * 0.12;
                ring(w, main, cx, y, cz, 3.6, 28);
                for (int tri = 0; tri < 2; tri++) {
                    for (int i = 0; i < 3; i++) {
                        double a1 = base + tri * Math.PI / 3 + i * Math.PI * 2 / 3;
                        double a2 = base + tri * Math.PI / 3 + (i + 1) * Math.PI * 2 / 3;
                        for (int k = 0; k <= 8; k++) {
                            double f = k / 8.0;
                            double x = cx + (Math.cos(a1) * (1 - f) + Math.cos(a2) * f) * 3.6;
                            double z = cz + (Math.sin(a1) * (1 - f) + Math.sin(a2) * f) * 3.6;
                            w.spawnParticles(second, x, y, z, 1, 0, 0, 0, 0);
                        }
                    }
                }
            });
        }
        Scheduler.later(18, () -> w.spawnParticles(second, cx, p.getY() + 1.5, cz, 100, 0.4, 1.5, 0.4, 0.15));
    }

    private static void pillar(ServerWorld w, ServerPlayerEntity p, ParticleEffect main, ParticleEffect second) {
        for (int t = 0; t < 14; t++) {
            int tick = t;
            Scheduler.later(1 + t, () -> {
                ring(w, main, p.getX(), p.getY() + tick * 0.5, p.getZ(), 0.9, 14);
                w.spawnParticles(second, p.getX(), p.getY() + tick * 0.5, p.getZ(), 5, 0.15, 0.2, 0.15, 0.05);
                ring(w, main, p.getX(), p.getY() + 0.2, p.getZ(), 0.6 + tick * 0.35, 18);
            });
        }
        Scheduler.later(15, () -> w.spawnParticles(second, p.getX(), p.getY() + 7, p.getZ(), 120, 1.0, 0.6, 1.0, 0.25));
    }

    private static void vortex(ServerWorld w, ServerPlayerEntity p, ParticleEffect main, ParticleEffect second) {
        for (int t = 0; t < 26; t++) {
            int tick = t;
            Scheduler.later(1 + t, () -> {
                double r = 5.0 - tick * 0.18;
                for (int arm = 0; arm < 4; arm++) {
                    double a = tick * 0.6 + arm * Math.PI / 2;
                    w.spawnParticles(main, p.getX() + Math.cos(a) * r, p.getY() + 0.3 + tick * 0.06,
                            p.getZ() + Math.sin(a) * r, 2, 0, 0, 0, 0.0);
                    if (tick % 2 == 0) {
                        w.spawnParticles(second, p.getX() + Math.cos(a + 0.4) * r, p.getY() + 0.3 + tick * 0.06,
                                p.getZ() + Math.sin(a + 0.4) * r, 1, 0, 0, 0, 0.0);
                    }
                }
            });
        }
        Scheduler.later(27, () -> w.spawnParticles(second, p.getX(), p.getY() + 1.2, p.getZ(), 120, 0.6, 0.8, 0.6, 0.3));
    }

    private static void shockwave(ServerWorld w, ServerPlayerEntity p, ParticleEffect main, ParticleEffect second) {
        for (int t = 0; t < 12; t++) {
            int tick = t;
            Scheduler.later(1 + t, () -> {
                double r = 0.8 + tick * 0.75;
                ring(w, main, p.getX(), p.getY() + 0.2, p.getZ(), r, 40);
                if (tick % 3 == 0) {
                    ring(w, second, p.getX(), p.getY() + 0.9, p.getZ(), r * 0.8, 20);
                }
            });
        }
        w.spawnParticles(second, p.getX(), p.getY() + 0.5, p.getZ(), 80, 0.6, 0.2, 0.6, 0.45);
    }

    public static void blink(ServerPlayerEntity p, double distance) {
        Vec3d dir = p.getRotationVec(1.0F);
        HitResult hit = p.raycast(distance, 1.0F, false);
        Vec3d dest = hit.getType() == HitResult.Type.MISS
                ? eye(p).add(dir.multiply(distance))
                : hit.getPos().subtract(dir.multiply(0.6));
        p.requestTeleport(dest.x, dest.y - 1.62, dest.z);
    }
}
