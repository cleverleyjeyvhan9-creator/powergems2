package com.powerstones;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.world.World;

/** Bow lava: klik kanan menembakkan fireball kecil yang jauh lebih sakit. */
public class MagmaStaffItem extends Item {

    public MagmaStaffItem(Settings settings) {
        super(settings);
    }

    @Override
    public ActionResult use(World world, PlayerEntity user, Hand hand) {
        if (world instanceof ServerWorld sw && user instanceof ServerPlayerEntity sp) {
            Skills.magmaFireball(sp, sw);
            user.getItemCooldownManager().set(user.getStackInHand(hand), 6);
        }
        return ActionResult.SUCCESS;
    }
}
