package com.powerstones;

import static com.powerstones.Fx.around;
import static com.powerstones.Fx.blink;
import static com.powerstones.Fx.give;
import static com.powerstones.Fx.push;
import static com.powerstones.Fx.target;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.powerstones.StoneDef.Use;

import net.minecraft.block.Blocks;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.AttributeModifierSlot;
import net.minecraft.component.type.AttributeModifiersComponent;
import net.minecraft.component.type.EquippableComponent;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LightningEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffectCategory;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ToolMaterial;
import net.minecraft.item.equipment.EquipmentAssetKeys;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Identifier;
import net.minecraft.util.Rarity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

/** Daftar semua power stone beserta deskripsi dan kemampuannya. */
public final class Stones {

    public static final Map<String, StoneItem> ITEMS = new LinkedHashMap<>();
    /** Semua item untuk tab kreatif (batu + holder). */
    public static final List<Item> TAB = new ArrayList<>();
    public static StoneItem LAPIS_MIND;
    public static StoneItem TRUE_STONE;
    public static Item TRUE_BLADE;
    public static StoneItem GALAXY_STONE;
    public static StoneItem MAGNET_STONE;
    public static StoneItem GOLD_STONE;
    public static StoneItem OBSIDIAN_VEIL;
    public static StoneItem MAGMA_STONE;
    public static StoneItem ICE_STONE;
    public static StoneItem CORROSIVE_STONE;
    public static Item MAGMA_BOW;
    public static Item ICE_DAGGER;
    public static StoneItem SUMMONER_STONE;
    public static StoneHolderItem HOLDER;

    private Stones() {}

    public static void register() {
        // ---------------------------------------------------------------- 1
        add(new StoneDef("diamond_core").style(2).aura(ParticleTypes.ENCHANTED_HIT).fx(ParticleTypes.CRIT).chestplate()
                .desc("Armor instan. Pakai di slot chestplate.")
                .info(Use.PASSIVE, "Armor Berlian",
                        "Armor +10 di slot chestplate"));

        add(new StoneDef("emerald_pulse").style(1).aura(ParticleTypes.HAPPY_VILLAGER).fx(ParticleTypes.TOTEM_OF_UNDYING)
                .desc("Keberuntungan dan penyembuhan tim.")
                .passive(StatusEffects.LUCK, 1).passive(StatusEffects.HERO_OF_THE_VILLAGE, 0)
                .passive(StatusEffects.SATURATION, 0)
                .power(Use.RIGHT, "Pulse Kemakmuran", 30,
                        "Regen + Speed untuk tim, dapat XP", (p, w) -> {
                    give(p, StatusEffects.REGENERATION, 8, 1);
                    give(p, StatusEffects.SPEED, 8, 0);
                    for (LivingEntity e : around(p, 10, false)) {
                        if (e instanceof PlayerEntity) {
                            give(e, StatusEffects.REGENERATION, 8, 1);
                            give(e, StatusEffects.SPEED, 8, 0);
                        }
                    }
                    p.addExperience(30);
                }));

        add(new StoneDef("netherite_heart").style(5).aura(ParticleTypes.SMOKE).fx(ParticleTypes.FLAME)
                .desc("Tubuh sekuat netherite.")
                .passive(StatusEffects.FIRE_RESISTANCE, 0).passive(StatusEffects.RESISTANCE, 1)
                .passive(StatusEffects.HEALTH_BOOST, 1)
                .power(Use.RIGHT, "Hati Netherite", 45,
                        "Resistance IV + Regeneration III", (p, w) -> {
                    give(p, StatusEffects.RESISTANCE, 6, 3);
                    give(p, StatusEffects.REGENERATION, 6, 2);
                    give(p, StatusEffects.FIRE_RESISTANCE, 20, 0);
                }));

        OBSIDIAN_VEIL = add(new StoneDef("obsidian_veil").style(4).aura(ParticleTypes.REVERSE_PORTAL).fx(ParticleTypes.PORTAL)
                .desc("Tabir obsidian. Darahmu berubah acak.")
                .info(Use.PASSIVE, "Darah Acak", "Tiap dipegang: 20, 15, atau 13 hati, kadang hanya 5 hati")
                .power(Use.RIGHT, "Perisai Obsidian", 120,
                        "Resistance IV selama 20 detik", (p, w) -> {
                    give(p, StatusEffects.RESISTANCE, 20, 3);
                    w.spawnParticles(ParticleTypes.REVERSE_PORTAL, p.getX(), p.getY() + 1, p.getZ(), 100, 0.8, 1, 0.8, 0.3);
                }));

        add(new StoneDef("redstone_spark").style(3).aura(ParticleTypes.CRIT).fx(ParticleTypes.ELECTRIC_SPARK)
                .desc("Kecepatan dan energi.")
                .passive(StatusEffects.SPEED, 3)
                .info(Use.PASSIVE, "Speed IV", "Hanya untuk pemegangnya")
                .power(Use.RIGHT, "Lonjakan Energi", 30,
                        "Haste III + lompat tinggi", (p, w) -> {
                    give(p, StatusEffects.HASTE, 10, 2);
                    give(p, StatusEffects.JUMP_BOOST, 10, 1);
                }));

        LAPIS_MIND = add(new StoneDef("lapis_mind").style(2).aura(ParticleTypes.ENCHANT).fx(ParticleTypes.END_ROD)
                .desc("Drop berlipat dan sihir.")
                .passive(StatusEffects.LUCK, 0).passive(StatusEffects.HASTE, 0)
                .passive(StatusEffects.NIGHT_VISION, 0)
                .info(Use.PASSIVE, "Fortune Surge",
                        "Tiap 4 menit: drop x2 selama 15 detik")
                .power(Use.RIGHT, "Ledakan Pikiran", 60,
                        "Dapat XP + Haste III", (p, w) -> {
                    p.addExperience(60);
                    give(p, StatusEffects.REGENERATION, 10, 0);
                    give(p, StatusEffects.HASTE, 10, 2);
                }));

        GOLD_STONE = add(new StoneDef("gold_stone").style(1).aura(ParticleTypes.TOTEM_OF_UNDYING).fx(ParticleTypes.END_ROD)
                .desc("Kecepatan ekstrem. Piglin tidak menyerangmu.")
                .passive(StatusEffects.SPEED, 1).passive(StatusEffects.JUMP_BOOST, 0)
                .passive(StatusEffects.HASTE, 0)
                .info(Use.PASSIVE, "Teman Piglin", "Piglin tidak akan menyerangmu")
                .power(Use.RIGHT, "Gold Rush", 30,
                        "Speed IV + lompat tinggi + Haste III", (p, w) -> {
                    give(p, StatusEffects.SPEED, 8, 3);
                    give(p, StatusEffects.JUMP_BOOST, 8, 2);
                    give(p, StatusEffects.HASTE, 8, 2);
                }));

        add(new StoneDef("echo_stone").style(4).aura(ParticleTypes.GLOW).fx(ParticleTypes.ENCHANT)
                .desc("Memunculkan bayangan dirimu.")
                .passive(StatusEffects.NIGHT_VISION, 0).passive(StatusEffects.SLOW_FALLING, 0)
                .power(Use.RIGHT, "Dua Echo", 30,
                        "2 bayangan dirimu, menyerang saat kamu menyerang", Skills::echoTwins)
                .power(Use.SNEAK, "Pasukan Echo", 60,
                        "Banyak echo muncul, kamu dan armormu tak terlihat 12 detik", Skills::echoLegion)
                .power(Use.OFFHAND, "Gema Kristal", 15,
                        "Musuh sekitar pusing dan terdorong", (p, w) -> {
                    for (LivingEntity e : around(p, 8, false)) {
                        give(e, StatusEffects.NAUSEA, 8, 0);
                        give(e, StatusEffects.GLOWING, 8, 0);
                        push(e, p, -1.2, 0.3);
                    }
                    give(p, StatusEffects.RESISTANCE, 5, 1);
                    w.playSound(null, p.getBlockPos(), SoundEvents.BLOCK_AMETHYST_BLOCK_CHIME,
                            SoundCategory.PLAYERS, 3.0F, 0.6F);
                }));

        add(new StoneDef("glowstone_beacon").style(3).aura(ParticleTypes.END_ROD).fx(ParticleTypes.TOTEM_OF_UNDYING)
                .desc("Cahaya penyembuh.")
                .passive(StatusEffects.NIGHT_VISION, 0).passive(StatusEffects.REGENERATION, 0)
                .power(Use.RIGHT, "Mercusuar", 20,
                        "Sembuhkan tim, butakan musuh", (p, w) -> {
                    for (LivingEntity e : around(p, 10, false)) {
                        if (e instanceof PlayerEntity) {
                            e.heal(6.0F);
                            give(e, StatusEffects.ABSORPTION, 10, 1);
                        } else if (e instanceof HostileEntity) {
                            give(e, StatusEffects.BLINDNESS, 5, 0);
                            give(e, StatusEffects.GLOWING, 10, 0);
                        }
                    }
                    p.heal(6.0F);
                    give(p, StatusEffects.ABSORPTION, 10, 1);
                }));

        add(new StoneDef("prismarine_tide").style(1).aura(ParticleTypes.NAUTILUS).fx(ParticleTypes.SPLASH)
                .desc("Pasukan laut membantumu.")
                .passive(StatusEffects.DOLPHINS_GRACE, 0).passive(StatusEffects.CONDUIT_POWER, 0)
                .passive(StatusEffects.WATER_BREATHING, 0).passive(StatusEffects.NIGHT_VISION, 0)
                .power(Use.RIGHT, "Panggil Pasukan Laut", 60,
                        "Panggil 6 Drowned + 3 Guardian", (p, w) -> {
                    for (int i = 0; i < 6; i++) {
                        Allies.spawn(w, p, EntityType.DROWNED, 45);
                    }
                    for (int i = 0; i < 3; i++) {
                        Allies.spawn(w, p, EntityType.GUARDIAN, 45);
                    }
                    w.spawnParticles(ParticleTypes.NAUTILUS, p.getX(), p.getY() + 1, p.getZ(), 100, 3, 1, 3, 0.5);
                })
                .power(Use.SNEAK, "Gelombang Pasang", 30,
                        "Dorong musuh + buff Speed", (p, w) -> {
                    for (LivingEntity e : around(p, 8, true)) {
                        give(e, StatusEffects.SLOWNESS, 6, 1);
                        push(e, p, -1.4, 0.2);
                    }
                    give(p, StatusEffects.SPEED, 8, 1);
                    give(p, StatusEffects.REGENERATION, 8, 0);
                }));

        add(new StoneDef("ender_shard").style(4).aura(ParticleTypes.PORTAL).fx(ParticleTypes.REVERSE_PORTAL)
                .desc("Teleport ke koordinat mana pun.")
                .passive(StatusEffects.SLOW_FALLING, 0).passive(StatusEffects.JUMP_BOOST, 0)
                .power(Use.RIGHT, "Teleport Koordinat", 0,
                        "Ketik X Y Z di chat untuk teleport",
                        Skills::enderPrompt));

        // ---------------------------------------------------------------- Summoner Stone
        SUMMONER_STONE = add(new StoneDef("summoner_stone").style(2).aura(ParticleTypes.SOUL).fx(ParticleTypes.SCULK_SOUL)
                .desc("Panggil pasukan undead.")
                .passive(StatusEffects.NIGHT_VISION, 0)
                .power(Use.RIGHT, "Belenggu Arwah", 20,
                        "Perlambat musuh radius 12", (p, w) -> {
                    for (LivingEntity e : around(p, 12, true)) {
                        give(e, StatusEffects.SLOWNESS, 10, 2);
                        give(e, StatusEffects.WEAKNESS, 10, 0);
                    }
                    w.spawnParticles(ParticleTypes.SOUL, p.getX(), p.getY() + 1, p.getZ(), 80, 4, 1, 4, 0.05);
                })
                .power(Use.SNEAK, "Pasukan Undead", 60,
                        "Panggil 10 Zombie + 10 Skeleton", (p, w) -> {
                    for (int i = 0; i < 10; i++) {
                        Allies.spawn(w, p, EntityType.ZOMBIE, 60);
                        Allies.spawn(w, p, EntityType.SKELETON, 60);
                    }
                    w.spawnParticles(ParticleTypes.SOUL, p.getX(), p.getY() + 1, p.getZ(), 150, 4, 1, 4, 0.1);
                })
                .power(Use.OFFHAND, "Arwah Korban", 45,
                        "Bangkitkan mob yang kamu bunuh (maks 15)",
                        Allies::summonKilled));

        MAGMA_STONE = add(new StoneDef("magma_stone").style(5).aura(ParticleTypes.FLAME).fx(ParticleTypes.LAVA)
                .desc("Api lava membakar sekitar.")
                .passive(StatusEffects.FIRE_RESISTANCE, 0).passive(StatusEffects.STRENGTH, 0)
                .info(Use.PASSIVE, "Aura Api", "Saat memegang Magma Bow: musuh radius 7 terbakar dan terluka")
                .power(Use.RIGHT, "Magma Bow", 60,
                        "Muncul bow 45 detik: tembak small fireball 5 hati", Skills::magmaBow)
                .power(Use.SNEAK, "Amarah Magma", 15,
                        "Bakar sekitar + Strength II", (p, w) -> {
                    for (LivingEntity e : around(p, 6, false)) {
                        e.setOnFireFor(8);
                        e.damage(w, w.getDamageSources().inFire(), 6.0F);
                    }
                    give(p, StatusEffects.STRENGTH, 6, 1);
                    give(p, StatusEffects.SPEED, 6, 0);
                    w.spawnParticles(ParticleTypes.LAVA, p.getX(), p.getY() + 1, p.getZ(), 40, 2, 0.5, 2, 0.1);
                    w.playSound(null, p.getBlockPos(), SoundEvents.ENTITY_BLAZE_SHOOT, SoundCategory.PLAYERS, 1.5F, 0.8F);
                }));

        ICE_STONE = add(new StoneDef("ice_stone").style(2).aura(ParticleTypes.SNOWFLAKE).fx(ParticleTypes.END_ROD)
                .desc("Dagger es yang membekukan lawan.")
                .passive(StatusEffects.STRENGTH, 0)
                .info(Use.PASSIVE, "Ice Dagger", "Dagger cepat muncul saat batu di tangan kiri")
                .info(Use.PASSIVE, "Pukulan Beku", "Tiap pukulan: musuh beku dan lambat")
                .power(Use.RIGHT, "Pembekuan", 20,
                        "Bekukan makhluk sekitar", (p, w) -> {
                    for (LivingEntity e : around(p, 8, false)) {
                        give(e, StatusEffects.SLOWNESS, 4, 6);
                        e.setFrozenTicks(200);
                    }
                    give(p, StatusEffects.RESISTANCE, 6, 1);
                    w.spawnParticles(ParticleTypes.SNOWFLAKE, p.getX(), p.getY() + 1, p.getZ(), 60, 3, 1, 3, 0.05);
                }));

        CORROSIVE_STONE = add(new StoneDef("corrosive_stone").style(4).aura(ParticleTypes.HAPPY_VILLAGER).fx(ParticleTypes.WITCH)
                .desc("Batu pengikis: kamu melemah, musuh berkarat.")
                .info(Use.PASSIVE, "Wither Pelan", "Kamu terkena Wither pelan, berhenti di 4 hati (tidak mati)")
                .info(Use.PASSIVE, "Karat", "Tiap pukulan: durability armor/senjata musuh -20")
                .power(Use.RIGHT, "Celah Hampa", 25,
                        "Tarik semua makhluk ke arahmu", (p, w) -> {
                    for (LivingEntity e : around(p, 10, false)) {
                        push(e, p, 1.4, 0.1);
                        give(e, StatusEffects.GLOWING, 8, 0);
                    }
                    w.spawnParticles(ParticleTypes.REVERSE_PORTAL, p.getX(), p.getY() + 1, p.getZ(), 80, 2, 1, 2, 0.2);
                }));

        // ---------------------------------------------------------------- Sculk Sense
        add(new StoneDef("sculk_sense").style(5).aura(ParticleTypes.SCULK_SOUL).fx(ParticleTypes.SOUL)
                .desc("Kekuatan Warden.")
                .passive(StatusEffects.NIGHT_VISION, 0)
                .info(Use.PASSIVE, "Deteksi Getaran", "Makhluk sekitar bersinar")
                .tick((p, w) -> {
                    for (LivingEntity e : around(p, 16, false)) {
                        give(e, StatusEffects.GLOWING, 2, 0);
                    }
                })
                .power(Use.RIGHT, "Double Sonic Boom", 20,
                        "2 Sonic Boom 10 hati + getaran tanah", Skills::doubleSonic)
                .power(Use.SNEAK, "Bayangan Sunyi", 60,
                        "Mob tak bisa melihatmu dan kabur", Skills::stealth)
                .power(Use.OFFHAND, "Darah Warden", 90,
                        "+200 HP, mob ketakutan (30 detik)",
                        Skills::wardenBlood));

        // ---------------------------------------------------------------- Copper Surge (tanpa efek potion)
        add(new StoneDef("copper_surge").style(3).aura(ParticleTypes.ELECTRIC_SPARK).fx(ParticleTypes.CRIT)
                .desc("Petir dahsyat (tanpa efek potion).")
                .power(Use.RIGHT, "Tiga Jalur Petir", 15,
                        "3 jalur petir menyapu ke depan",
                        Skills::copperLines)
                .power(Use.SNEAK, "Cincin Petir", 30,
                        "Petir membentuk lingkaran di sekitarmu", Skills::copperRing)
                .power(Use.OFFHAND, "Petir Penghancur", 60,
                        "Ledakan petir, tanah hancur",
                        Skills::copperMega));

        add(new StoneDef("crying_obsidian_tear").style(4).aura(ParticleTypes.DRIPPING_OBSIDIAN_TEAR).fx(ParticleTypes.PORTAL)
                .desc("Teleport dan lemahkan musuh.")
                .passive(StatusEffects.RESISTANCE, 0).passive(StatusEffects.NIGHT_VISION, 0)
                .power(Use.RIGHT, "Tangisan Portal", 30,
                        "Lemahkan musuh + teleport maju", (p, w) -> {
                    for (LivingEntity e : around(p, 10, true)) {
                        give(e, StatusEffects.WEAKNESS, 10, 1);
                    }
                    blink(p, 25);
                    give(p, StatusEffects.ABSORPTION, 8, 1);
                    give(p, StatusEffects.SPEED, 4, 1);
                }));

        add(new StoneDef("blackstone_ward").style(5).aura(ParticleTypes.ASH).fx(ParticleTypes.LARGE_SMOKE)
                .desc("Penjaga Nether yang kokoh.")
                .passive(StatusEffects.RESISTANCE, 0).passive(StatusEffects.ABSORPTION, 0)
                .power(Use.RIGHT, "Dorongan Batu", 15,
                        "Dorong makhluk di depanmu jauh ke depan", Skills::blackstonePush)
                .power(Use.SNEAK, "Benteng Blackstone", 45,
                        "Kubah batu pelindung 10 detik + Regeneration", Skills::blackstoneDome)
                .power(Use.OFFHAND, "Golem Penjaga", 60,
                        "Panggil 2 Iron Golem sekutu (45 detik)", Skills::blackstoneGolems));

        add(new StoneDef("quartz_radiance").style(1).aura(ParticleTypes.CLOUD).fx(ParticleTypes.END_ROD)
                .desc("Cahaya kemurnian: laser dan penyucian.")
                .passive(StatusEffects.REGENERATION, 0).passive(StatusEffects.HEALTH_BOOST, 0)
                .power(Use.RIGHT, "Sinar Laser", 8,
                        "Laser putih 2 hati damage, tapi kamu bersinar (Glowing)", Skills::laser)
                .power(Use.SNEAK, "Penyucian", 30,
                        "Hapus efek buruk + sembuhkan", (p, w) -> {
                    for (StatusEffectInstance i : new ArrayList<>(p.getStatusEffects())) {
                        if (i.getEffectType().value().getCategory() == StatusEffectCategory.HARMFUL) {
                            p.removeStatusEffect(i.getEffectType());
                        }
                    }
                    p.heal(6.0F);
                    p.getHungerManager().add(6, 0.6F);
                    give(p, StatusEffects.REGENERATION, 6, 1);
                    for (LivingEntity e : around(p, 8, false)) {
                        if (e instanceof PlayerEntity) {
                            e.heal(6.0F);
                        }
                    }
                }));

        // ---------------------------------------------------------------- Galaxy Stone
        GALAXY_STONE = add(new StoneDef("galaxy_stone").style(4).aura(ParticleTypes.END_ROD).fx(ParticleTypes.PORTAL)
                .desc("Terbang dan kuasai gravitasi.")
                .info(Use.PASSIVE, "Terbang", "Terbang bebas seperti creative")
                .power(Use.RIGHT, "Lontar Angkasa", 20,
                        "Lontarkan makhluk ke atas", Skills::galaxyLaunch)
                .power(Use.SNEAK, "Tarikan Gravitasi", 45,
                        "Tarik makhluk dan bekukan 20 detik", Skills::galaxyFreeze)
                .power(Use.OFFHAND, "Lubang Hitam", 120,
                        "Sedot dan hancurkan di titik bidik",
                        Skills::galaxyBlackHole));

        // ---------------------------------------------------------------- True Stone
        TRUE_STONE = add(new StoneDef("true_stone").style(2).aura(ParticleTypes.ENCHANTED_HIT).fx(ParticleTypes.CRIT)
                .desc("Taruh di tangan kiri untuk memunculkan True Blade.")
                .passive(StatusEffects.STRENGTH, 0).passive(StatusEffects.SPEED, 0)
                .info(Use.PASSIVE, "True Blade", "Pedang Sharpness V muncul saat batu di tangan kiri")
                .info(Use.PASSIVE, "25 kill", "Untouchable: kebal 2 detik saat diserang")
                .info(Use.PASSIVE, "100 kill", "Musuh yang kamu bunuh lenyap tanpa drop")
                .info(Use.PASSIVE, "Bunuh pemain", "Dapat 1 armor netherite"));

        Identifier bid = Identifier.of(PowerStones.MOD_ID, "true_blade");
        RegistryKey<Item> bkey = RegistryKey.of(RegistryKeys.ITEM, bid);
        TRUE_BLADE = new Item(new Item.Settings().registryKey(bkey).maxCount(1).rarity(Rarity.EPIC)
                .sword(ToolMaterial.NETHERITE, 3.0F, -2.4F));
        Registry.register(Registries.ITEM, bkey, TRUE_BLADE);

        RegistryKey<Item> mkey = RegistryKey.of(RegistryKeys.ITEM, Identifier.of(PowerStones.MOD_ID, "magma_bow"));
        MAGMA_BOW = new MagmaBowItem(new Item.Settings().registryKey(mkey).maxCount(1).rarity(Rarity.EPIC));
        Registry.register(Registries.ITEM, mkey, MAGMA_BOW);

        RegistryKey<Item> dkey = RegistryKey.of(RegistryKeys.ITEM, Identifier.of(PowerStones.MOD_ID, "ice_dagger"));
        ICE_DAGGER = new Item(new Item.Settings().registryKey(dkey).maxCount(1).rarity(Rarity.EPIC)
                .sword(ToolMaterial.DIAMOND, 1.5F, -1.0F));
        Registry.register(Registries.ITEM, dkey, ICE_DAGGER);

        // ---------------------------------------------------------------- Magnet Stone (baru)
        MAGNET_STONE = add(new StoneDef("magnet_stone").style(3).aura(ParticleTypes.ELECTRIC_SPARK).fx(ParticleTypes.CRIT)
                .desc("Genggam makhluk dari jauh.")
                .power(Use.RIGHT, "Genggam / Lepas", 0,
                        "Genggam makhluk yang kamu lihat",
                        Skills::magnetToggle)
                .power(Use.SNEAK, "Lempar", 3,
                        "Lempar makhluk yang digenggam", Skills::magnetThrow)
                .power(Use.OFFHAND, "Atur Jarak", 0,
                        "Ganti jarak genggam", Skills::magnetDistance));

        // ---------------------------------------------------------------- Control Stone (baru)
        add(new StoneDef("control_stone").style(0).aura(ParticleTypes.PORTAL).fx(ParticleTypes.ELECTRIC_SPARK)
                .desc("Tembakkan projectile pilihanmu.")
                .power(Use.RIGHT, "Tembak", 15,
                        "Tembak 15 projectile cepat", Skills::fireProjectiles)
                .power(Use.SNEAK, "Pilih Projectile", 0,
                        "Ketik nama projectile di chat",
                        Skills::chooseProjectile));

        // ---------------------------------------------------------------- Stone Holder
        Identifier hid = Identifier.of(PowerStones.MOD_ID, "stone_holder");
        RegistryKey<Item> hkey = RegistryKey.of(RegistryKeys.ITEM, hid);
        HOLDER = new StoneHolderItem(new Item.Settings().registryKey(hkey).maxCount(1).rarity(Rarity.EPIC));
        Registry.register(Registries.ITEM, hkey, HOLDER);
        TAB.add(HOLDER);
    }

    private static StoneItem add(StoneDef def) {
        Identifier id = Identifier.of(PowerStones.MOD_ID, def.id);
        RegistryKey<Item> key = RegistryKey.of(RegistryKeys.ITEM, id);
        Item.Settings settings = new Item.Settings().registryKey(key).maxCount(1).rarity(Rarity.EPIC);
        if (def.sword) {
            settings = settings.sword(ToolMaterial.NETHERITE, 3.0F, -2.4F);
        }
        if (def.chestplate) {
            settings = settings
                    .component(DataComponentTypes.EQUIPPABLE, EquippableComponent.builder(EquipmentSlot.CHEST)
                            .model(RegistryKey.of(EquipmentAssetKeys.REGISTRY_KEY, Identifier.of(PowerStones.MOD_ID, def.id)))
                            .build())
                    .attributeModifiers(AttributeModifiersComponent.builder()
                            .add(EntityAttributes.ARMOR,
                                    new EntityAttributeModifier(Identifier.of(PowerStones.MOD_ID, def.id + "_armor"),
                                            10.0, EntityAttributeModifier.Operation.ADD_VALUE),
                                    AttributeModifierSlot.CHEST)
                            .add(EntityAttributes.ARMOR_TOUGHNESS,
                                    new EntityAttributeModifier(Identifier.of(PowerStones.MOD_ID, def.id + "_toughness"),
                                            4.0, EntityAttributeModifier.Operation.ADD_VALUE),
                                    AttributeModifierSlot.CHEST)
                            .build());
        }
        StoneItem item = new StoneItem(settings, def);
        Registry.register(Registries.ITEM, key, item);
        ITEMS.put(def.id, item);
        TAB.add(item);
        return item;
    }
}
