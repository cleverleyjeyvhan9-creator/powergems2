package com.powerstones;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import net.fabricmc.fabric.api.message.v1.ServerMessageEvents;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

/** Input teks lewat chat: pesan chat berikutnya dari pemain ditangkap dan tidak ditampilkan ke orang lain. */
public final class Inputs {

    @FunctionalInterface
    public interface Handler {
        void accept(ServerPlayerEntity player, String text);
    }

    private static final Map<UUID, Handler> PENDING = new HashMap<>();

    private Inputs() {}

    public static void ask(ServerPlayerEntity p, String prompt, Handler handler) {
        PENDING.put(p.getUuid(), handler);
        p.sendMessage(Text.literal(prompt), false);
    }

    public static void register() {
        ServerMessageEvents.ALLOW_CHAT_MESSAGE.register((message, sender, params) -> {
            Handler h = PENDING.remove(sender.getUuid());
            if (h == null) {
                return true;
            }
            String text = message.getSignedContent();
            sender.getEntityWorld().getServer().execute(() -> h.accept(sender, text));
            return false;
        });
    }
}
