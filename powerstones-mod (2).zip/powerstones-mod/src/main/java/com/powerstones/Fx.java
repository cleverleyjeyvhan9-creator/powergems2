package com.powerstones;

import java.util.List;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Vec3d;

/** Fungsi bantu yang dipakai banyak skill. */
public final class Fx {

    private Fx() {}

    public static Vec3d eye(ServerPlayerEntity p) {
        return new Vec3d(p.getX(), p.getEyeY(), p.getZ());
    }

    public static void give(LivingEntity e, RegistryEntry<StatusEffect> effect, int seconds, int amplifier) {
        e.addStatusEffect(new StatusEffectInstance(effect, seconds * 20, amplifier));
    }

    /** Makhluk hidup di sekitar pemain (sekutu pemain tidak ikut). */
    public static List<LivingEntity> around(ServerPlayerEntity p, double r, boolean hostileOnly) {
        ServerWorld w = p.getEntityWorld();
        return w.getEntitiesByClass(LivingEntity.class, p.getBoundingBox().expand(r),
                e -> e != p && e.isAlive() && e.squaredDistanceTo(p) <= r * r
                        && !Allies.isAlly(e)
                        && (!hostileOnly || e instanceof HostileEntity));
    }

    /** strength > 0 = tarik mendekat ke pemain, strength < 0 = dorong menjauh. */
    public static void push(LivingEntity e, ServerPlayerEntity p, double strength, double lift) {
        Vec3d away = new Vec3d(e.getX() - p.getX(), 0, e.getZ() - p.getZ());
        if (away.lengthSquared() < 1.0E-4) {
            return;
        }
        Vec3d v = away.normalize().multiply(-strength);
        e.addVelocity(v.x, lift, v.z);
    }

    /** Makhluk yang paling pas dengan arah pandangan pemain. */
    public static LivingEntity target(ServerPlayerEntity p, double range) {
        Vec3d look = p.getRotationVec(1.0F);
        Vec3d eye = eye(p);
        LivingEntity best = null;
        double bestDot = 0.95;
        for (LivingEntity e : around(p, range, false)) {
            Vec3d to = new Vec3d(e.getX() - eye.x, e.getBodyY(0.5) - eye.y, e.getZ() - eye.z).normalize();
            double dot = look.dotProduct(to);
            if (dot > bestDot) {
                bestDot = dot;
                best = e;
            }
        }
        return best;
    }

    /** Efek visual setiap skill: semburan, cincin melebar, spiral naik, dan percikan di atas kepala. */
    public static void skillFx(ServerWorld w, ServerPlayerEntity p, ParticleEffect main, ParticleEffect second) {
        w.spawnParticles(main, p.getX(), p.getY() + 1.0, p.getZ(), 70, 0.8, 1.0, 0.8, 0.15);
        for (int i = 0; i < 6; i++) {
            double r = 1.0 + i * 1.1;
            Scheduler.later(1 + i * 2, () -> {
                for (int k = 0; k < 28; k++) {
                    double a = k * Math.PI * 2 / 28;
                    w.spawnParticles(main, p.getX() + Math.cos(a) * r, p.getY() + 0.2, p.getZ() + Math.sin(a) * r,
                            1, 0, 0.05, 0, 0.01);
                }
            });
        }
        for (int t = 0; t < 20; t++) {
            int tick = t;
            Scheduler.later(1 + t, () -> {
                for (int arm = 0; arm < 2; arm++) {
                    double a = tick * 0.5 + arm * Math.PI;
                    w.spawnParticles(second, p.getX() + Math.cos(a) * 1.2, p.getY() + tick * 0.1,
                            p.getZ() + Math.sin(a) * 1.2, 2, 0, 0, 0, 0.01);
                }
            });
        }
        w.spawnParticles(second, p.getX(), p.getY() + 2.2, p.getZ(), 40, 0.5, 0.4, 0.5, 0.15);
    }

    public static void blink(ServerPlayerEntity p, double distance) {
        Vec3d dir = p.getRotationVec(1.0F);
        HitResult hit = p.raycast(distance, 1.0F, false);
        Vec3d dest = hit.getType() == HitResult.Type.MISS
                ? eye(p).add(dir.multiply(distance))
                : hit.getPos().subtract(dir.multiply(0.6));
        p.requestTeleport(dest.x, dest.y - 1.62, dest.z);
    }
}
