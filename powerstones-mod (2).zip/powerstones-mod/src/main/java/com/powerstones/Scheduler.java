package com.powerstones;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/** Penjadwal sederhana: jalankan sesuatu N tick lagi di thread server. */
public final class Scheduler {

    private static final class Task {
        int delay;
        final Runnable run;
        Task(int delay, Runnable run) {
            this.delay = delay;
            this.run = run;
        }
    }

    private static final List<Task> TASKS = new ArrayList<>();

    private Scheduler() {}

    public static void later(int ticks, Runnable run) {
        TASKS.add(new Task(Math.max(1, ticks), run));
    }

    public static void tick() {
        if (TASKS.isEmpty()) {
            return;
        }
        List<Runnable> due = new ArrayList<>();
        for (Iterator<Task> it = TASKS.iterator(); it.hasNext();) {
            Task t = it.next();
            t.delay--;
            if (t.delay <= 0) {
                due.add(t.run);
                it.remove();
            }
        }
        for (Runnable r : due) {
            try {
                r.run();
            } catch (Exception ignored) {
                // satu tugas gagal tidak boleh menjatuhkan server
            }
        }
    }
}
