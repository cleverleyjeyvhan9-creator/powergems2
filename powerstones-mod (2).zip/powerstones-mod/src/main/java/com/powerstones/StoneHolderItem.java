package com.powerstones;

import java.util.ArrayList;
import java.util.List;

import net.minecraft.component.DataComponentTypes;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.world.World;

/**
 * Alat penampung 3 batu.
 * Main hand: klik kanan = skill 1 (atau masukkan batu dari offhand), jongkok + klik kanan = ganti batu
 * (sambil menunduk penuh = keluarkan batu). Offhand: klik kanan = skill 2, jongkok + klik kanan = skill 3.
 */
public class StoneHolderItem extends Item {

    public static final int CAPACITY = 3;

    public StoneHolderItem(Settings settings) {
        super(settings);
    }

    public static List<StoneItem> stones(ItemStack holder) {
        List<StoneItem> out = new ArrayList<>();
        String raw = holder.getOrDefault(PowerStones.HOLDER_STONES, "");
        if (raw.isEmpty()) {
            return out;
        }
        for (String id : raw.split(",")) {
            StoneItem s = Stones.ITEMS.get(id);
            if (s != null) {
                out.add(s);
            }
        }
        return out;
    }

    public static int selected(ItemStack holder) {
        return holder.getOrDefault(PowerStones.HOLDER_SEL, 0);
    }

    public static StoneItem selectedStone(ItemStack holder) {
        List<StoneItem> list = stones(holder);
        if (list.isEmpty()) {
            return null;
        }
        int sel = Math.floorMod(selected(holder), list.size());
        return list.get(sel);
    }

    private static void save(ItemStack holder, List<StoneItem> list, int sel) {
        StringBuilder sb = new StringBuilder();
        for (StoneItem s : list) {
            if (sb.length() > 0) {
                sb.append(',');
            }
            sb.append(s.def.id);
        }
        holder.set(PowerStones.HOLDER_STONES, sb.toString());
        holder.set(PowerStones.HOLDER_SEL, list.isEmpty() ? 0 : Math.floorMod(sel, list.size()));
        refreshModel(holder);
    }

    /** Ganti tampilan item sesuai batu yang dipilih. */
    public static void refreshModel(ItemStack holder) {
        StoneItem sel = selectedStone(holder);
        String name = sel == null ? "holder_empty" : "holder_" + sel.def.id;
        Identifier id = Identifier.of(PowerStones.MOD_ID, name);
        if (!id.equals(holder.get(DataComponentTypes.ITEM_MODEL))) {
            holder.set(DataComponentTypes.ITEM_MODEL, id);
        }
    }

    @Override
    public ActionResult use(World world, PlayerEntity user, Hand hand) {
        if (!(world instanceof ServerWorld sw) || !(user instanceof ServerPlayerEntity sp)) {
            return ActionResult.SUCCESS;
        }
        ItemStack self = user.getStackInHand(hand);
        if (hand == Hand.MAIN_HAND) {
            if (user.isSneaking()) {
                if (sp.getPitch() > 80.0F) {
                    eject(sp, self);
                } else {
                    cycle(sp, self);
                }
            } else {
                ItemStack off = user.getOffHandStack();
                if (off.getItem() instanceof StoneItem incoming) {
                    insert(sp, self, off, incoming);
                } else {
                    StoneItem s = selectedStone(self);
                    if (s == null) {
                        sp.sendMessage(Text.literal("Holder kosong. Pegang holder di main hand dan batu di offhand, lalu klik kanan."), true);
                    } else {
                        s.trigger(sp, sw, 0);
                    }
                }
            }
        } else {
            StoneItem s = selectedStone(self);
            if (s != null) {
                s.trigger(sp, sw, user.isSneaking() ? 2 : 1);
            }
        }
        return ActionResult.SUCCESS;
    }

    private static void insert(ServerPlayerEntity p, ItemStack holder, ItemStack offhand, StoneItem incoming) {
        List<StoneItem> list = stones(holder);
        if (list.size() >= CAPACITY) {
            p.sendMessage(Text.literal("Holder penuh (maksimal 3 batu)."), true);
            return;
        }
        if (list.contains(incoming)) {
            p.sendMessage(Text.literal("Batu itu sudah ada di holder."), true);
            return;
        }
        list.add(incoming);
        offhand.decrement(1);
        save(holder, list, list.size() - 1);
        p.sendMessage(Text.translatable(incoming.getTranslationKey()).append(Text.literal(" dimasukkan ke holder")), true);
    }

    private static void cycle(ServerPlayerEntity p, ItemStack holder) {
        List<StoneItem> list = stones(holder);
        if (list.isEmpty()) {
            return;
        }
        int next = (selected(holder) + 1) % list.size();
        save(holder, list, next);
        StoneItem s = list.get(next);
        p.sendMessage(Text.literal("Batu dipilih: ").append(Text.translatable(s.getTranslationKey())), true);
    }

    private static void eject(ServerPlayerEntity p, ItemStack holder) {
        List<StoneItem> list = stones(holder);
        if (list.isEmpty()) {
            return;
        }
        int sel = Math.floorMod(selected(holder), list.size());
        StoneItem out = list.remove(sel);
        save(holder, list, 0);
        p.getInventory().offerOrDrop(new ItemStack(out));
        p.sendMessage(Text.translatable(out.getTranslationKey()).append(Text.literal(" dikeluarkan dari holder")), true);
    }
}
