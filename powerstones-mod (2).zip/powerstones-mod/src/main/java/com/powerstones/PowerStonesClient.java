package com.powerstones;

import java.util.List;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.item.v1.ItemTooltipCallback;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.item.ItemStack;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

public class PowerStonesClient implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
        ItemTooltipCallback.EVENT.register((stack, context, type, lines) -> {
            if (stack.getItem() instanceof StoneItem st) {
                addStoneInfo(st, lines);
                if (stack.isOf(Stones.TRUE_STONE)) {
                    addKills(stack, lines);
                }
            } else if (stack.getItem() instanceof StoneHolderItem) {
                addHolderInfo(stack, lines);
            } else if (stack.isOf(Stones.TRUE_BLADE)) {
                lines.add(Text.literal("Hilang jika True Stone tidak di tangan kiri.").formatted(Formatting.GRAY));
            }
        });
    }

    private static void addStoneInfo(StoneItem st, List<Text> lines) {
        StoneDef def = st.def;
        lines.add(Text.literal(def.description).formatted(Formatting.GRAY));
        if (!def.passives.isEmpty()) {
            MutableText p = Text.literal("Pasif: ").formatted(Formatting.AQUA);
            boolean first = true;
            for (StatusEffectInstance e : def.passives) {
                if (!first) {
                    p.append(Text.literal(", ").formatted(Formatting.GRAY));
                }
                p.append(e.getEffectType().value().getName().copy().formatted(Formatting.GRAY));
                p.append(Text.literal(" " + (e.getAmplifier() + 1)).formatted(Formatting.GRAY));
                first = false;
            }
            lines.add(p);
        }
        for (StoneDef.Power pw : def.powers) {
            if (pw.use() == StoneDef.Use.PASSIVE) {
                lines.add(Text.literal("- " + pw.name() + ": " + pw.text()).formatted(Formatting.AQUA));
                continue;
            }
            MutableText l = Text.literal(pw.use().label + ": ").formatted(Formatting.GOLD);
            l.append(Text.literal(pw.name()).formatted(Formatting.YELLOW));
            l.append(Text.literal(" - " + pw.text()).formatted(Formatting.GRAY));
            if (pw.cooldownSeconds() > 0) {
                l.append(Text.literal(" (" + pw.cooldownSeconds() + "s)").formatted(Formatting.DARK_GRAY));
            }
            lines.add(l);
        }
    }

    private static void addKills(ItemStack stack, List<Text> lines) {
        int kills = stack.getOrDefault(PowerStones.KILLS_COMPONENT, 0);
        lines.add(Text.literal("Kill mob: " + kills).formatted(Formatting.GOLD));
        lines.add(skillLine("Untouchable", PowerStones.SKILL_2_KILLS, kills));
        lines.add(skillLine("Erase Existence", PowerStones.SKILL_3_KILLS, kills));
    }

    private static Text skillLine(String name, int need, int kills) {
        if (kills >= need) {
            return Text.literal(name + ": aktif").formatted(Formatting.GREEN);
        }
        return Text.literal(name + ": " + kills + "/" + need + " kill").formatted(Formatting.DARK_GRAY);
    }

    private static void addHolderInfo(ItemStack holder, List<Text> lines) {
        lines.add(Text.literal("Menampung 3 batu. Efek mengikuti batu terpilih.").formatted(Formatting.GRAY));
        List<StoneItem> list = StoneHolderItem.stones(holder);
        if (list.isEmpty()) {
            lines.add(Text.literal("Kosong: holder di main hand + batu di offhand, klik kanan.")
                    .formatted(Formatting.DARK_GRAY));
        } else {
            int sel = Math.floorMod(StoneHolderItem.selected(holder), list.size());
            for (int i = 0; i < list.size(); i++) {
                boolean chosen = i == sel;
                MutableText l = Text.literal((chosen ? "> " : "  ") + (i + 1) + ". ")
                        .formatted(chosen ? Formatting.GREEN : Formatting.GRAY);
                l.append(Text.translatable(list.get(i).getTranslationKey())
                        .formatted(chosen ? Formatting.GREEN : Formatting.GRAY));
                lines.add(l);
            }
            addStoneInfo(list.get(sel), lines);
        }
        lines.add(Text.literal("Main hand: klik kanan = skill 1, jongkok + klik = ganti batu").formatted(Formatting.DARK_GRAY));
        lines.add(Text.literal("Offhand: klik kanan = skill 2, jongkok + klik = skill 3").formatted(Formatting.DARK_GRAY));
    }
}
