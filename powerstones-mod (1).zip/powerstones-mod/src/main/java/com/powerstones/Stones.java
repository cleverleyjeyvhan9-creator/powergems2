package com.powerstones;

import static com.powerstones.Fx.around;
import static com.powerstones.Fx.blink;
import static com.powerstones.Fx.give;
import static com.powerstones.Fx.push;
import static com.powerstones.Fx.target;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.powerstones.StoneDef.Use;

import net.minecraft.block.Blocks;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.AttributeModifierSlot;
import net.minecraft.component.type.AttributeModifiersComponent;
import net.minecraft.component.type.EquippableComponent;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LightningEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffectCategory;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ToolMaterial;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Identifier;
import net.minecraft.util.Rarity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

/** Daftar semua power stone beserta deskripsi dan kemampuannya. */
public final class Stones {

    public static final Map<String, StoneItem> ITEMS = new LinkedHashMap<>();
    /** Semua item untuk tab kreatif (batu + holder). */
    public static final List<Item> TAB = new ArrayList<>();
    public static StoneItem LAPIS_MIND;
    public static StoneItem TRUE_STONE;
    public static StoneItem GALAXY_STONE;
    public static StoneItem MAGNET_STONE;
    public static StoneItem SUMMONER_STONE;
    public static StoneHolderItem HOLDER;

    private Stones() {}

    public static void register() {
        // ---------------------------------------------------------------- 1
        add(new StoneDef("diamond_core").aura(ParticleTypes.ENCHANTED_HIT).chestplate()
                .desc("Batu pelindung berlian. Harus dipakai di slot chestplate.")
                .info(Use.PASSIVE, "Armor Berlian",
                        "Dipakai di slot chestplate (klik kanan untuk memakai): armor +10 dan toughness +4 langsung."));

        add(new StoneDef("emerald_pulse").aura(ParticleTypes.HAPPY_VILLAGER)
                .desc("Batu keberuntungan dan perdagangan.")
                .passive(StatusEffects.LUCK, 1).passive(StatusEffects.HERO_OF_THE_VILLAGE, 0)
                .passive(StatusEffects.SATURATION, 0)
                .power(Use.RIGHT, "Pulse Kemakmuran", 30,
                        "Regenerasi dan Speed untuk kamu dan pemain sekitar, plus XP.", (p, w) -> {
                    give(p, StatusEffects.REGENERATION, 8, 1);
                    give(p, StatusEffects.SPEED, 8, 0);
                    for (LivingEntity e : around(p, 10, false)) {
                        if (e instanceof PlayerEntity) {
                            give(e, StatusEffects.REGENERATION, 8, 1);
                            give(e, StatusEffects.SPEED, 8, 0);
                        }
                    }
                    p.addExperience(30);
                }));

        add(new StoneDef("netherite_heart").aura(ParticleTypes.SMOKE)
                .desc("Jantung netherite yang hampir tak bisa dihancurkan.")
                .passive(StatusEffects.FIRE_RESISTANCE, 0).passive(StatusEffects.RESISTANCE, 1)
                .passive(StatusEffects.HEALTH_BOOST, 1)
                .power(Use.RIGHT, "Hati Netherite", 45,
                        "Resistance IV, Regeneration III, dan kebal api sesaat.", (p, w) -> {
                    give(p, StatusEffects.RESISTANCE, 6, 3);
                    give(p, StatusEffects.REGENERATION, 6, 2);
                    give(p, StatusEffects.FIRE_RESISTANCE, 20, 0);
                }));

        add(new StoneDef("obsidian_veil").aura(ParticleTypes.REVERSE_PORTAL)
                .desc("Tabir obsidian pelindung gelap.")
                .power(Use.RIGHT, "Perisai Obsidian", 120,
                        "Resistance IV selama 20 detik.", (p, w) -> {
                    give(p, StatusEffects.RESISTANCE, 20, 3);
                    w.spawnParticles(ParticleTypes.REVERSE_PORTAL, p.getX(), p.getY() + 1, p.getZ(), 100, 0.8, 1, 0.8, 0.3);
                }));

        add(new StoneDef("redstone_spark").aura(ParticleTypes.CRIT)
                .desc("Batu energi dan sirkuit.")
                .passive(StatusEffects.HASTE, 0).passive(StatusEffects.SPEED, 0)
                .power(Use.RIGHT, "Lonjakan Energi", 30,
                        "Speed III, Haste III, dan Jump Boost II selama 10 detik.", (p, w) -> {
                    give(p, StatusEffects.SPEED, 10, 2);
                    give(p, StatusEffects.HASTE, 10, 2);
                    give(p, StatusEffects.JUMP_BOOST, 10, 1);
                }));

        LAPIS_MIND = add(new StoneDef("lapis_mind").aura(ParticleTypes.ENCHANT)
                .desc("Batu kebijaksanaan yang memperkuat sihir dan keberuntungan.")
                .passive(StatusEffects.LUCK, 0).passive(StatusEffects.HASTE, 0)
                .passive(StatusEffects.NIGHT_VISION, 0)
                .info(Use.PASSIVE, "Fortune Surge",
                        "Tiap 4 menit selama dipegang: drop digandakan 15 detik, plus Luck III dan Haste II.")
                .power(Use.RIGHT, "Ledakan Pikiran", 60,
                        "Dapat XP, Regeneration, dan Haste III.", (p, w) -> {
                    p.addExperience(60);
                    give(p, StatusEffects.REGENERATION, 10, 0);
                    give(p, StatusEffects.HASTE, 10, 2);
                }));

        add(new StoneDef("gold_rush").aura(ParticleTypes.TOTEM_OF_UNDYING)
                .desc("Batu kemakmuran dan kecepatan.")
                .passive(StatusEffects.SPEED, 1).passive(StatusEffects.JUMP_BOOST, 0)
                .passive(StatusEffects.HASTE, 0)
                .power(Use.RIGHT, "Gold Rush", 30,
                        "Speed IV, Jump Boost III, dan Haste III selama 8 detik.", (p, w) -> {
                    give(p, StatusEffects.SPEED, 8, 3);
                    give(p, StatusEffects.JUMP_BOOST, 8, 2);
                    give(p, StatusEffects.HASTE, 8, 2);
                }));

        add(new StoneDef("amethyst_echo").aura(ParticleTypes.GLOW)
                .desc("Gema kristal yang menggemakan gelombang suara.")
                .passive(StatusEffects.NIGHT_VISION, 0).passive(StatusEffects.SLOW_FALLING, 0)
                .power(Use.RIGHT, "Gema Kristal", 15,
                        "Makhluk radius 8 pusing, bersinar, dan terdorong menjauh.", (p, w) -> {
                    for (LivingEntity e : around(p, 8, false)) {
                        give(e, StatusEffects.NAUSEA, 8, 0);
                        give(e, StatusEffects.GLOWING, 8, 0);
                        push(e, p, -1.2, 0.3);
                    }
                    give(p, StatusEffects.RESISTANCE, 5, 1);
                    w.playSound(null, p.getBlockPos(), SoundEvents.BLOCK_AMETHYST_BLOCK_CHIME,
                            SoundCategory.PLAYERS, 3.0F, 0.6F);
                }));

        add(new StoneDef("glowstone_beacon").aura(ParticleTypes.END_ROD)
                .desc("Cahaya penuntun yang menyembuhkan sekutu.")
                .passive(StatusEffects.NIGHT_VISION, 0).passive(StatusEffects.REGENERATION, 0)
                .power(Use.RIGHT, "Mercusuar", 20,
                        "Sembuhkan pemain radius 10, butakan dan sinari musuh.", (p, w) -> {
                    for (LivingEntity e : around(p, 10, false)) {
                        if (e instanceof PlayerEntity) {
                            e.heal(6.0F);
                            give(e, StatusEffects.ABSORPTION, 10, 1);
                        } else if (e instanceof HostileEntity) {
                            give(e, StatusEffects.BLINDNESS, 5, 0);
                            give(e, StatusEffects.GLOWING, 10, 0);
                        }
                    }
                    p.heal(6.0F);
                    give(p, StatusEffects.ABSORPTION, 10, 1);
                }));

        add(new StoneDef("prismarine_tide").aura(ParticleTypes.NAUTILUS)
                .desc("Kekuatan samudra. Mob laut akan membantumu bertarung.")
                .passive(StatusEffects.DOLPHINS_GRACE, 0).passive(StatusEffects.CONDUIT_POWER, 0)
                .passive(StatusEffects.WATER_BREATHING, 0).passive(StatusEffects.NIGHT_VISION, 0)
                .power(Use.RIGHT, "Panggil Pasukan Laut", 60,
                        "Memanggil 6 Drowned dan 3 Guardian yang menyerang musuhmu (45 detik).", (p, w) -> {
                    for (int i = 0; i < 6; i++) {
                        Allies.spawn(w, p, EntityType.DROWNED, 45);
                    }
                    for (int i = 0; i < 3; i++) {
                        Allies.spawn(w, p, EntityType.GUARDIAN, 45);
                    }
                    w.spawnParticles(ParticleTypes.NAUTILUS, p.getX(), p.getY() + 1, p.getZ(), 100, 3, 1, 3, 0.5);
                })
                .power(Use.SNEAK, "Gelombang Pasang", 30,
                        "Dorong musuh radius 8 dan lambatkan, kamu mendapat Speed dan Regeneration.", (p, w) -> {
                    for (LivingEntity e : around(p, 8, true)) {
                        give(e, StatusEffects.SLOWNESS, 6, 1);
                        push(e, p, -1.4, 0.2);
                    }
                    give(p, StatusEffects.SPEED, 8, 1);
                    give(p, StatusEffects.REGENERATION, 8, 0);
                }));

        add(new StoneDef("ender_shard").aura(ParticleTypes.PORTAL)
                .desc("Ender Stone: teleportasi ke koordinat mana pun.")
                .passive(StatusEffects.SLOW_FALLING, 0).passive(StatusEffects.JUMP_BOOST, 0)
                .power(Use.RIGHT, "Teleport Koordinat", 0,
                        "Ketik X Y Z di chat, lalu kamu langsung teleport ke sana (cooldown 8 detik setelah teleport).",
                        Skills::enderPrompt));

        // ---------------------------------------------------------------- Summoner Stone
        SUMMONER_STONE = add(new StoneDef("summoner_stone").aura(ParticleTypes.SOUL)
                .desc("Batu pemanggil arwah dan pasukan undead.")
                .passive(StatusEffects.NIGHT_VISION, 0)
                .power(Use.RIGHT, "Belenggu Arwah", 20,
                        "Memperlambat dan melemahkan musuh radius 12.", (p, w) -> {
                    for (LivingEntity e : around(p, 12, true)) {
                        give(e, StatusEffects.SLOWNESS, 10, 2);
                        give(e, StatusEffects.WEAKNESS, 10, 0);
                    }
                    w.spawnParticles(ParticleTypes.SOUL, p.getX(), p.getY() + 1, p.getZ(), 80, 4, 1, 4, 0.05);
                })
                .power(Use.SNEAK, "Pasukan Undead", 60,
                        "Memanggil 10 Zombie dan 10 Skeleton yang tidak terbakar matahari (60 detik).", (p, w) -> {
                    for (int i = 0; i < 10; i++) {
                        Allies.spawn(w, p, EntityType.ZOMBIE, 60);
                        Allies.spawn(w, p, EntityType.SKELETON, 60);
                    }
                    w.spawnParticles(ParticleTypes.SOUL, p.getX(), p.getY() + 1, p.getZ(), 150, 4, 1, 4, 0.1);
                })
                .power(Use.OFFHAND, "Arwah Korban", 45,
                        "Membangkitkan mob yang kamu bunuh (maks 15 terakhir) untuk menyerang mob lain.",
                        Allies::summonKilled));

        add(new StoneDef("magma_fury").aura(ParticleTypes.FLAME)
                .desc("Amarah lava dari Nether.")
                .passive(StatusEffects.FIRE_RESISTANCE, 0).passive(StatusEffects.STRENGTH, 0)
                .power(Use.RIGHT, "Amarah Magma", 15,
                        "Membakar makhluk radius 6 dan menambah Strength II sesaat.", (p, w) -> {
                    for (LivingEntity e : around(p, 6, false)) {
                        e.setOnFireFor(8);
                        e.damage(w, w.getDamageSources().inFire(), 6.0F);
                    }
                    give(p, StatusEffects.STRENGTH, 6, 1);
                    give(p, StatusEffects.SPEED, 6, 0);
                    w.spawnParticles(ParticleTypes.LAVA, p.getX(), p.getY() + 1, p.getZ(), 40, 2, 0.5, 2, 0.1);
                    w.playSound(null, p.getBlockPos(), SoundEvents.ENTITY_BLAZE_SHOOT, SoundCategory.PLAYERS, 1.5F, 0.8F);
                }));

        add(new StoneDef("packed_ice_fang").aura(ParticleTypes.SNOWFLAKE)
                .desc("Taring es abadi yang membekukan lawan.")
                .passive(StatusEffects.RESISTANCE, 0).passive(StatusEffects.JUMP_BOOST, 0)
                .power(Use.RIGHT, "Pembekuan", 20,
                        "Membekukan dan memperlambat makhluk radius 8 selama 4 detik.", (p, w) -> {
                    for (LivingEntity e : around(p, 8, false)) {
                        give(e, StatusEffects.SLOWNESS, 4, 6);
                        e.setFrozenTicks(200);
                    }
                    give(p, StatusEffects.RESISTANCE, 6, 1);
                    w.spawnParticles(ParticleTypes.SNOWFLAKE, p.getX(), p.getY() + 1, p.getZ(), 60, 3, 1, 3, 0.05);
                }));

        add(new StoneDef("end_stone_void").aura(ParticleTypes.CLOUD)
                .desc("Kehampaan dimensi End.")
                .passive(StatusEffects.SLOW_FALLING, 0).passive(StatusEffects.JUMP_BOOST, 0)
                .power(Use.RIGHT, "Celah Hampa", 25,
                        "Menarik semua makhluk radius 10 ke arahmu dan membuatnya bersinar.", (p, w) -> {
                    for (LivingEntity e : around(p, 10, false)) {
                        push(e, p, 1.4, 0.1);
                        give(e, StatusEffects.GLOWING, 8, 0);
                    }
                    w.spawnParticles(ParticleTypes.REVERSE_PORTAL, p.getX(), p.getY() + 1, p.getZ(), 80, 2, 1, 2, 0.2);
                }));

        // ---------------------------------------------------------------- Sculk Sense
        add(new StoneDef("sculk_sense").aura(ParticleTypes.SCULK_SOUL)
                .desc("Indra getaran Warden.")
                .passive(StatusEffects.NIGHT_VISION, 0)
                .info(Use.PASSIVE, "Deteksi Getaran", "Makhluk radius 16 bersinar dan terlihat tembus dinding.")
                .tick((p, w) -> {
                    for (LivingEntity e : around(p, 16, false)) {
                        give(e, StatusEffects.GLOWING, 2, 0);
                    }
                })
                .power(Use.RIGHT, "Double Sonic Boom", 20,
                        "Dua Sonic Boom Warden beruntun ke depan, masing-masing 10 hati damage.", Skills::doubleSonic)
                .power(Use.SNEAK, "Bayangan Sunyi", 60,
                        "15 detik: semua mob di sekitar tidak bisa melihatmu dan pergi sendiri.", Skills::stealth)
                .power(Use.OFFHAND, "Darah Warden", 90,
                        "30 detik: darahmu seperti Warden (+200 HP), mob di sekitar ketakutan dan kabur.",
                        Skills::wardenBlood));

        // ---------------------------------------------------------------- Copper Surge (tanpa efek potion)
        add(new StoneDef("copper_surge").aura(ParticleTypes.ELECTRIC_SPARK)
                .desc("Kekuatan petir. Tanpa efek potion, hanya serangan.")
                .power(Use.RIGHT, "Tiga Jalur Petir", 15,
                        "3 jalur petir menyapu 10 block ke depan; petir di belakang lenyap saat gelombang maju.",
                        Skills::copperLines)
                .power(Use.SNEAK, "Cincin Petir", 30,
                        "Petir menyambar membentuk dua lingkaran di sekelilingmu.", Skills::copperRing)
                .power(Use.OFFHAND, "Petir Penghancur", 60,
                        "Badai petir super yang meledak dan menghancurkan tanah di titik yang kamu tuju.",
                        Skills::copperMega));

        add(new StoneDef("crying_obsidian_tear").aura(ParticleTypes.DRIPPING_OBSIDIAN_TEAR)
                .desc("Air mata obsidian yang membuka celah dimensi.")
                .passive(StatusEffects.RESISTANCE, 0).passive(StatusEffects.NIGHT_VISION, 0)
                .power(Use.RIGHT, "Tangisan Portal", 30,
                        "Melemahkan musuh radius 10 lalu teleport 25 block ke depan.", (p, w) -> {
                    for (LivingEntity e : around(p, 10, true)) {
                        give(e, StatusEffects.WEAKNESS, 10, 1);
                    }
                    blink(p, 25);
                    give(p, StatusEffects.ABSORPTION, 8, 1);
                    give(p, StatusEffects.SPEED, 4, 1);
                }));

        add(new StoneDef("blackstone_ward").aura(ParticleTypes.ASH)
                .desc("Penjaga Nether yang menetralkan racun.")
                .passive(StatusEffects.RESISTANCE, 0).passive(StatusEffects.ABSORPTION, 0)
                .power(Use.RIGHT, "Dinding Penjaga", 30,
                        "Hapus Poison dan Wither, Resistance II, dan bangun dinding Blackstone di depanmu.", (p, w) -> {
                    p.removeStatusEffect(StatusEffects.POISON);
                    p.removeStatusEffect(StatusEffects.WITHER);
                    give(p, StatusEffects.RESISTANCE, 8, 1);
                    Direction f = p.getHorizontalFacing();
                    Direction side = f.rotateYClockwise();
                    BlockPos base = p.getBlockPos().offset(f, 2);
                    for (int s = -1; s <= 1; s++) {
                        for (int y = 0; y < 3; y++) {
                            BlockPos bp = base.offset(side, s).up(y);
                            if (w.getBlockState(bp).isAir()) {
                                w.setBlockState(bp, Blocks.BLACKSTONE.getDefaultState());
                            }
                        }
                    }
                }));

        add(new StoneDef("quartz_radiance").aura(ParticleTypes.CLOUD)
                .desc("Cahaya kemurnian yang menyucikan kutukan.")
                .passive(StatusEffects.REGENERATION, 0).passive(StatusEffects.HEALTH_BOOST, 0)
                .power(Use.RIGHT, "Penyucian", 30,
                        "Hapus semua efek buruk, pulihkan HP dan lapar, sembuhkan pemain sekitar.", (p, w) -> {
                    for (StatusEffectInstance i : new ArrayList<>(p.getStatusEffects())) {
                        if (i.getEffectType().value().getCategory() == StatusEffectCategory.HARMFUL) {
                            p.removeStatusEffect(i.getEffectType());
                        }
                    }
                    p.heal(6.0F);
                    p.getHungerManager().add(6, 0.6F);
                    give(p, StatusEffects.REGENERATION, 6, 1);
                    for (LivingEntity e : around(p, 8, false)) {
                        if (e instanceof PlayerEntity) {
                            e.heal(6.0F);
                        }
                    }
                }));

        // ---------------------------------------------------------------- Galaxy Stone
        GALAXY_STONE = add(new StoneDef("galaxy_stone").aura(ParticleTypes.END_ROD)
                .desc("Kekuatan galaksi. Tanpa efek potion, tapi bisa terbang.")
                .info(Use.PASSIVE, "Terbang", "Terbang bebas seperti mode creative selama batu dipegang.")
                .power(Use.RIGHT, "Lontar Angkasa", 20,
                        "Menerbangkan semua makhluk radius 12 ke atas.", Skills::galaxyLaunch)
                .power(Use.SNEAK, "Tarikan Gravitasi", 45,
                        "Menarik makhluk ke depanmu dan membuatnya terdiam selama 20 detik.", Skills::galaxyFreeze)
                .power(Use.OFFHAND, "Lubang Hitam", 120,
                        "Lubang hitam 10 detik di titik yang kamu tuju: menyedot makhluk, melahap blok, melukai.",
                        Skills::galaxyBlackHole));

        // ---------------------------------------------------------------- True Stone
        TRUE_STONE = add(new StoneDef("true_stone").aura(ParticleTypes.ENCHANTED_HIT)
                .desc("Pedang sejati (Fase 2). Skill terbuka dari jumlah kill mob.")
                .passive(StatusEffects.STRENGTH, 0).passive(StatusEffects.SPEED, 0)
                .info(Use.PASSIVE, "True Edge", "Sharpness V (setara Strength I) sejak awal.")
                .info(Use.PASSIVE, "Untouchable (25 kill)", "Otomatis saat diserang: tak bisa disentuh 2 detik (cooldown 20 detik).")
                .info(Use.PASSIVE, "Erase Existence (100 kill)", "Mob yang dibunuh lenyap tanpa drop (cooldown 5 menit).")
                .info(Use.PASSIVE, "Fase 2 - Rampasan", "Membunuh pemain memasang 1 armor netherite di tubuhmu.")
                .sword());

        // ---------------------------------------------------------------- Magnet Stone (baru)
        MAGNET_STONE = add(new StoneDef("magnet_stone").aura(ParticleTypes.ELECTRIC_SPARK)
                .desc("Batu magnet yang menggenggam makhluk dari jauh (radius 15 block).")
                .power(Use.RIGHT, "Genggam / Lepas", 0,
                        "Genggam makhluk yang kamu lihat; ia mengikuti arah pandanganmu. Klik lagi untuk melepas.",
                        Skills::magnetToggle)
                .power(Use.SNEAK, "Lempar", 3,
                        "Melempar makhluk yang sedang digenggam ke arah pandanganmu.", Skills::magnetThrow)
                .power(Use.OFFHAND, "Atur Jarak", 0,
                        "Mengganti jarak genggaman (4, 8, 12, 15 block).", Skills::magnetDistance));

        // ---------------------------------------------------------------- Control Stone (baru)
        add(new StoneDef("control_stone").aura(ParticleTypes.PORTAL)
                .desc("Batu pengendali projectile.")
                .power(Use.RIGHT, "Tembak", 15,
                        "Menembakkan 15 projectile pilihanmu sangat cepat ke depan.", Skills::fireProjectiles)
                .power(Use.SNEAK, "Pilih Projectile", 0,
                        "Ketik nama projectile di chat (arrow, fireball, blue_wither_skull, dll).",
                        Skills::chooseProjectile));

        // ---------------------------------------------------------------- Stone Holder
        Identifier hid = Identifier.of(PowerStones.MOD_ID, "stone_holder");
        RegistryKey<Item> hkey = RegistryKey.of(RegistryKeys.ITEM, hid);
        HOLDER = new StoneHolderItem(new Item.Settings().registryKey(hkey).maxCount(1).rarity(Rarity.EPIC));
        Registry.register(Registries.ITEM, hkey, HOLDER);
        TAB.add(HOLDER);
    }

    private static StoneItem add(StoneDef def) {
        Identifier id = Identifier.of(PowerStones.MOD_ID, def.id);
        RegistryKey<Item> key = RegistryKey.of(RegistryKeys.ITEM, id);
        Item.Settings settings = new Item.Settings().registryKey(key).maxCount(1).rarity(Rarity.EPIC);
        if (def.sword) {
            settings = settings.sword(ToolMaterial.NETHERITE, 3.0F, -2.4F);
        }
        if (def.chestplate) {
            settings = settings
                    .component(DataComponentTypes.EQUIPPABLE, EquippableComponent.builder(EquipmentSlot.CHEST).build())
                    .attributeModifiers(AttributeModifiersComponent.builder()
                            .add(EntityAttributes.ARMOR,
                                    new EntityAttributeModifier(Identifier.of(PowerStones.MOD_ID, def.id + "_armor"),
                                            10.0, EntityAttributeModifier.Operation.ADD_VALUE),
                                    AttributeModifierSlot.CHEST)
                            .add(EntityAttributes.ARMOR_TOUGHNESS,
                                    new EntityAttributeModifier(Identifier.of(PowerStones.MOD_ID, def.id + "_toughness"),
                                            4.0, EntityAttributeModifier.Operation.ADD_VALUE),
                                    AttributeModifierSlot.CHEST)
                            .build());
        }
        StoneItem item = new StoneItem(settings, def);
        Registry.register(Registries.ITEM, key, item);
        ITEMS.put(def.id, item);
        TAB.add(item);
        return item;
    }
}
