package com.powerstones;

import java.util.List;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.item.v1.ItemTooltipCallback;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.item.ItemStack;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

public class PowerStonesClient implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
        ItemTooltipCallback.EVENT.register((stack, context, type, lines) -> {
            if (stack.getItem() instanceof StoneItem st) {
                addStoneInfo(st, lines);
                if (stack.isOf(Stones.TRUE_STONE)) {
                    addKills(stack, lines);
                }
            } else if (stack.getItem() instanceof StoneHolderItem) {
                addHolderInfo(stack, lines);
            }
        });
    }

    private static void addStoneInfo(StoneItem st, List<Text> lines) {
        StoneDef def = st.def;
        lines.add(Text.literal(def.description).formatted(Formatting.GRAY));
        if (!def.passives.isEmpty()) {
            MutableText p = Text.literal("[Pasif] ").formatted(Formatting.AQUA);
            boolean first = true;
            for (StatusEffectInstance e : def.passives) {
                if (!first) {
                    p.append(Text.literal(", ").formatted(Formatting.GRAY));
                }
                p.append(e.getEffectType().value().getName().copy().formatted(Formatting.GRAY));
                p.append(Text.literal(" " + (e.getAmplifier() + 1)).formatted(Formatting.GRAY));
                first = false;
            }
            lines.add(p);
        }
        for (StoneDef.Power pw : def.powers) {
            MutableText l = Text.literal("[" + pw.use().label + "] ").formatted(Formatting.GOLD);
            l.append(Text.literal(pw.name() + ": ").formatted(Formatting.YELLOW));
            String cd = pw.cooldownSeconds() > 0 ? " (cd " + pw.cooldownSeconds() + " dtk)" : "";
            l.append(Text.literal(pw.text() + cd).formatted(Formatting.GRAY));
            lines.add(l);
        }
        lines.add(Text.literal("Efek hanya aktif saat batu dipegang.").formatted(Formatting.DARK_GRAY));
    }

    private static void addKills(ItemStack stack, List<Text> lines) {
        int kills = stack.getOrDefault(PowerStones.KILLS_COMPONENT, 0);
        lines.add(Text.literal("Kill mob: " + kills).formatted(Formatting.GOLD));
        lines.add(skillLine("Skill 2 - Untouchable", PowerStones.SKILL_2_KILLS, kills));
        lines.add(skillLine("Skill 3 - Erase Existence", PowerStones.SKILL_3_KILLS, kills));
    }

    private static Text skillLine(String name, int need, int kills) {
        if (kills >= need) {
            return Text.literal(name + ": aktif").formatted(Formatting.GREEN);
        }
        return Text.literal(name + ": " + kills + "/" + need + " kill").formatted(Formatting.DARK_GRAY);
    }

    private static void addHolderInfo(ItemStack holder, List<Text> lines) {
        lines.add(Text.literal("Menampung sampai 3 batu. Efek mengikuti batu yang dipilih.").formatted(Formatting.GRAY));
        List<StoneItem> list = StoneHolderItem.stones(holder);
        if (list.isEmpty()) {
            lines.add(Text.literal("Kosong - pegang holder (main hand) dan batu (offhand), lalu klik kanan.")
                    .formatted(Formatting.DARK_GRAY));
        } else {
            int sel = Math.floorMod(StoneHolderItem.selected(holder), list.size());
            for (int i = 0; i < list.size(); i++) {
                boolean chosen = i == sel;
                MutableText l = Text.literal((chosen ? "> " : "  ") + (i + 1) + ". ")
                        .formatted(chosen ? Formatting.GREEN : Formatting.GRAY);
                l.append(Text.translatable(list.get(i).getTranslationKey())
                        .formatted(chosen ? Formatting.GREEN : Formatting.GRAY));
                if (chosen) {
                    l.append(Text.literal("  (dipilih)").formatted(Formatting.GREEN));
                }
                lines.add(l);
            }
            StoneItem s = list.get(sel);
            lines.add(Text.literal("-- " + s.def.description).formatted(Formatting.YELLOW));
            addStoneInfo(s, lines);
        }
        lines.add(Text.literal("[Main hand] Klik kanan: skill 1 batu / masukkan batu dari offhand").formatted(Formatting.GOLD));
        lines.add(Text.literal("[Main hand] Jongkok + klik kanan: ganti batu (menunduk penuh: keluarkan batu)").formatted(Formatting.GOLD));
        lines.add(Text.literal("[Offhand] Klik kanan: skill 2, jongkok + klik kanan: skill 3").formatted(Formatting.GOLD));
    }
}
