package com.powerstones;

import java.util.List;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Vec3d;

/** Fungsi bantu yang dipakai banyak skill. */
public final class Fx {

    private Fx() {}

    public static Vec3d eye(ServerPlayerEntity p) {
        return new Vec3d(p.getX(), p.getEyeY(), p.getZ());
    }

    public static void give(LivingEntity e, RegistryEntry<StatusEffect> effect, int seconds, int amplifier) {
        e.addStatusEffect(new StatusEffectInstance(effect, seconds * 20, amplifier));
    }

    /** Makhluk hidup di sekitar pemain (sekutu pemain tidak ikut). */
    public static List<LivingEntity> around(ServerPlayerEntity p, double r, boolean hostileOnly) {
        ServerWorld w = p.getEntityWorld();
        return w.getEntitiesByClass(LivingEntity.class, p.getBoundingBox().expand(r),
                e -> e != p && e.isAlive() && e.squaredDistanceTo(p) <= r * r
                        && !Allies.isAlly(e)
                        && (!hostileOnly || e instanceof HostileEntity));
    }

    /** strength > 0 = tarik mendekat ke pemain, strength < 0 = dorong menjauh. */
    public static void push(LivingEntity e, ServerPlayerEntity p, double strength, double lift) {
        Vec3d away = new Vec3d(e.getX() - p.getX(), 0, e.getZ() - p.getZ());
        if (away.lengthSquared() < 1.0E-4) {
            return;
        }
        Vec3d v = away.normalize().multiply(-strength);
        e.addVelocity(v.x, lift, v.z);
    }

    /** Makhluk yang paling pas dengan arah pandangan pemain. */
    public static LivingEntity target(ServerPlayerEntity p, double range) {
        Vec3d look = p.getRotationVec(1.0F);
        Vec3d eye = eye(p);
        LivingEntity best = null;
        double bestDot = 0.95;
        for (LivingEntity e : around(p, range, false)) {
            Vec3d to = new Vec3d(e.getX() - eye.x, e.getBodyY(0.5) - eye.y, e.getZ() - eye.z).normalize();
            double dot = look.dotProduct(to);
            if (dot > bestDot) {
                bestDot = dot;
                best = e;
            }
        }
        return best;
    }

    public static void blink(ServerPlayerEntity p, double distance) {
        Vec3d dir = p.getRotationVec(1.0F);
        HitResult hit = p.raycast(distance, 1.0F, false);
        Vec3d dest = hit.getType() == HitResult.Type.MISS
                ? eye(p).add(dir.multiply(distance))
                : hit.getPos().subtract(dir.multiply(0.6));
        p.requestTeleport(dest.x, dest.y - 1.62, dest.z);
    }
}
